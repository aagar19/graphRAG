"""This is the variance comparison for unifai."""

from pyspark.sql.functions import first
from pyspark.sql.functions import variance


# Json data with different versions
json_data = {
    "unifai_version_1": {
        "mortality": {
            "orchestration_ids": ["f7cb0307-cc7b-479e-b5a9-01ed75848caa", "f7cb0307-cc7b-479e-b5a9-01ed75848caa"],
            "mean": "mean_value",
            "variance_percentage_range": (0.001, 0.01),
        },
        "fall": {
            "orchestration_ids": ["f7a1fa5a-c026-4937-9b78-fc1fe72b43ae", "f7a1fa5a-c026-4937-9b78-fc1fe72b43ae"],
            "mean": "mean_value",
            "variance_percentage_range": (0.001, 0.01),
        },
    },
    "unifai_version_2": {
        "mortality": {"orchestration_ids": ["55ff23c0-fe6c-46a7-a387-6d7df38f60bc"]},
        "fall": {"orchestration_ids": ["a12d1a81-41b5-49ba-af72-b02f8e75af1d"]},
    },
}


def check_counts(df1, df2):
    """Function to compare the counts of dataframe.

    returns a boolean value.
    """
    return df1.count() == df2.count()


def get_model_param(model_name):
    """Function to get the model defination.

    returns the calculation for the model score.
    """
    if model_name in ["fall", "mortality", "chronicity", "frailty", "er-util", "readmissions"]:
        model_param = f"{model_name}-score"
    elif model_name == "admissions":
        model_param = "admissions_score_acap"
    elif model_name == "pharmacy":
        model_param = "pharmacy-category"
    elif model_name == "future-cost":
        model_param = "cost-score"
    elif model_name in ["ckd-45-progression", "ckd-7-progression-score"]:
        step = model_name.split("-")[1]
        model_param = f"ckd-{step}-progression-score"
    else:
        raise ValueError("the model name is inaccurate")
    return model_param


def modified_output_store(df):
    """Function to modify the model output score dataframe for model and transpose calculation_name.

    fill calculation values based on that,
    modify column names make dataframe ready with MEMBER_ID as primary key.

    Returns: Pyspark Dataframe.
    """
    df = df.withColumnRenamed("data_link_value", "member_id")
    reshaped_df = df.groupby("member_id").pivot("calculation_name").agg(first("calculation_value"))
    reshaped_df.createOrReplaceTempView("reshaped_df")
    reshaped_df = reshaped_df.toDF(*[c.upper() for c in reshaped_df.columns])
    columns_replace = (column.replace("-", "_") for column in reshaped_df.columns)
    reshaped_df = reshaped_df.toDF(*columns_replace)
    return reshaped_df


def get_dataframe(model_param, orchestration_id, schema_name):
    """Function to the get the model output store based on the orchestration_id.

    returns a dataframe.
    """
    run_id = spark.sql(  # noqa: F821
        f"select id from {schema_name}.unifai_core_job_runs where orchestration_id='{orchestration_id}' order by start_time desc"
    ).collect()[0][0]
    if model_param == "severity":
        df_scores = spark.sql(  # noqa: F821
            f"select * from {schema_name}.unifai_core_model_output_store where run_id='{run_id}' and calculation_name like 'severity_level_%' "  # noqa: B950
        )
        return df_scores
    else:
        df_scores = spark.sql(  # noqa: F821
            f"select * from {schema_name}.unifai_core_model_output_store where run_id='{run_id}' and calculation_name='{model_param}' "  # noqa: B950
        )
    return df_scores


def check_schema(df1, df2):
    """Function to check the schema.

    returns a boolean value.
    """
    return df1.columns == df2.columns


def calculate_variance_scores(df, model_param):
    """Function to calculate the variance.

    returns a float.
    """
    model_param = model_param.replace("-", "_")
    compare_dataset = modified_output_store(df)
    variance_df = compare_dataset.agg(*[variance(column).alias(column) for column in compare_dataset.columns])
    variance_value = variance_df.select(model_param.upper()).collect()[0][0]
    return variance_value


def unifai_comparison_run(json_data, schema_name):
    """Function to run the comparison."""
    model_name = list(json_data["unifai_version_1"])[0]
    no_of_runs = len(json_data["unifai_version_1"][model_name]["orchestration_ids"])

    for model_name in list(json_data["unifai_version_1"]):
        print(f"**************************This is the comparison run for {model_name} model**************************")
        orc_id2 = json_data["unifai_version_2"][model_name]["orchestration_ids"][0]
        low_var, high_var = json_data["unifai_version_1"][model_name]["variance_percentage_range"]
        for run_no in range(no_of_runs):
            orc_id1 = json_data["unifai_version_1"][model_name]["orchestration_ids"][run_no]
            if model_name == "severity":
                model_param = "severity"
            else:
                model_param = get_model_param(model_name)
            # get the dataframes for both the runs
            scores1 = get_dataframe(model_param, orc_id1, schema_name)
            scores2 = get_dataframe(model_param, orc_id2, schema_name)
            # run the schema check
            if check_schema(scores1, scores2):
                print(" The Schema matches fine ")
            else:
                print("Error!There is a mismatch in the schema.")
            # check the counts for the scores
            if check_counts(scores1, scores2):
                print("The counts of both the dataframe are exact")
            else:
                print("The counts of both the dataframe are not exact")
            # run the comparison
            variance1 = calculate_variance_scores(scores1, model_param)
            variance2 = calculate_variance_scores(scores2, model_param)
            print(f"This is the variance1 {variance1} for {model_name}")
            print(f"This is the variance2 {variance2} for {model_name}")
            if low_var <= variance1 <= high_var and low_var <= variance2 <= high_var:
                print(f"The Variance of {model_name} is in between the variance_percentage_range")
            else:
                print(f"The Variance of {model_name} is not in between the variance_percentage_range")


unifai_comparison_run(json_data, schema_name="unifai_comp_test")
