# Databricks notebook source

# COMMAND ----------

%pip install datacompy


# COMMAND ----------


import os
# ---- Get Input Variables Begins ---- #
# Get Base Delta Table Name - Previous Version
base_table_name = os.environ['BASE_TABLE_NAME']
base_table_additional_sql_clause = os.environ['BASE_TABLE_ADDITIONAL_SQL_CLAUSE']
# Get New Delta Table Name - New/Upcoming Version
new_table_name = os.environ['NEW_TABLE_NAME']
new_table_additional_sql_clause = os.environ['NEW_TABLE_ADDITIONAL_SQL_CLAUSE']
# Get Common Columns for comparison
common_columns_string = os.environ["COMMON_COLUMNS"]
common_columns = common_columns_string.split(',')
# Get Expected Variance Threshold Percentage
expected_threshold_percentage = os.environ["EXPECTED_THRESHOLD_PERCENTAGE"]
# ---- Get Input Variables Ends ---- #

# Data Compy Comparison
df1 = spark.sql(f"SELECT * FROM {base_table_name} {base_table_additional_sql_clause}")
df2 = spark.sql(f"select * from {new_table_name} {new_table_additional_sql_clause}")

import datacompy as dc


# schema_check - we can also check if we can use datacompy
schema_check = True
df1_minus_df2 = set(df1.schema) - set(df2.schema)
df2_minus_df1 = set(df2.schema) - set(df1.schema)
if(len(df1_minus_df2)>0 or len(df2_minus_df1)>0):
    print("Schema Mismatch. Present in base not in new: ", df1_minus_df2)
    print("Schema Mismatch. Present in new not in base: ", df2_minus_df1)
    schema_check = False

assert schema_check == True, 'ERROR: Code cannot be merged. Possible Schema mismatch issues - Details in the notebook log. Please debug and fix.'

comparison = dc.SparkCompare(spark, base_df=df1, compare_df=df2, join_columns=common_columns, match_rates=True)

actual_difference_percentage = (comparison.rows_both_mismatch.count()/df1.count())*100
comparison_check = (actual_difference_percentage <= float(expected_threshold_percentage))

if(comparison_check == False):
    print("Actual Difference Percentage: ", actual_difference_percentage)
    print("Expected Difference Percentage: ", expected_threshold_percentage)
    print("\n****** Data Comparison Report ******")
    display(comparison.report())

assert comparison_check == True, 'ERROR: Code cannot be merged. Possible Data Comparison issues - Details in the notebook log. Please debug and fix.'

