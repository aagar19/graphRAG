# UnifAI Templatizer

## Introduction

The UnifAI Templatizer automates the creation of project structures for AI/ML models. It generates a defined project
structure on a GitHub feature branch, as well as Airflow DAGs
for prospective and retrospective AI/ML pipelines, facilitating the integration of AI/ML models into UnifAI environments
for testing
and production.

```
<model_name>_model/
├── README.md
├── application.yaml
├── dags
│   ├── <model_name>_prospective.py
│   └── <model_name>_retrospective.py
├── jobs
│   ├── <model_job_1_defintiion>.yaml
│   ├── <model_job_2_defintiion>.yaml
│   ├── ...
│   └── <model_job_n_defintiion>.yaml
├── schema
│   ├── <schema_1_defintiion>.yaml
│   ├── <schema_2_defintiion>.yaml
│   ├── ...
│   └── <schema_n_defintiion>.yaml
│   └── <schema>.md
└── src
    ├── <model_job_1_script>.py
    ├── <model_job_1_script>.py
    ├── ...
    └── <model_job_n_script>.py

```

### Detailed Components

- **README.md**: Provides essential information and guidance for using and understanding the model.
- **application.yaml**: Contains the application's configuration, setting up the environment and variables needed for
  operation.
- **dags/**: Contains Directed Acyclic Graphs (DAGs) for Airflow, orchestrating the model's workflow.
- **jobs/**: Contains YAML definitions for each job within the model's lifecycle, outlining the execution environment,
  inputs, and outputs.
- **schema/**: For now these are place holders for where the schema of the the tables/data needed will live. The UnifAI team will work to
  automatically create these schemas in the future.
- **src/**: Contains the Python scripts implementing the logic of each job defined in the `jobs/` directory.

## How to Use the UnifAI Templatizer

To get started with the UnifAI Templatizer, you'll need to prepare a YAML definition for your AI/ML model using the
UnifAI template. This process involves defining your application's configuration, job definitions, and orchestration
needs.

To generate a template for your AI/ML model, you can run the following UnifAI command:

```shell
unifai-admin template create-template --file-name <model_name>
```

This will by default create the template file `<model_name>.yaml` in the directory where you ran the command. To
specify where you wish the file to be created, use the `--destination` flag.

The following sections will guide you through completing the templated YAML for your AI/ML model.
If you already have a template defined, you can skip to
the [Generating UnifAI Application from YAML template](#create-app-from-template).

### Step 1: Define `application.yaml`

The `application.yaml` is crucial for configuring your application's environment, variables, and overall setup. Here's
how you define it:

#### Template Structure:

```YAML
# Application Configuration
# The `application` section describes your AI/ML application within the Databricks environment.
# It includes general information about the application, environment settings, and application-specific variables.
application:
  overview:
    # model_name: Unique name of the model. Avoid spaces and special characters.
    # model_suffix: A suffix to distinguish different versions or aspects of the model.
    # run_type: Defines the frequency of model execution (e.g., daily, monthly).
    # description: A brief description of what the model does.
    model_name:
    model_suffix:
    run_type:
    description:
  application_variables:
    # Define any application-specific variables here. For example, paths to data files or model parameters.
    # These variables can be referenced throughout the configuration.
    MAPPING_FILES_DIR:
  environment:
    # databricks_runtime_version: Specify the Databricks runtime version for the cluster.
    # node_type: The type of node to use for the Databricks cluster.
    # min_workers: Minimum number of worker nodes for the cluster.
    # max_workers: Maximum number of worker nodes for the cluster.
    databricks_runtime_version:
    node_type:
    min_workers:
    max_workers:
```

#### Example Configuration:

```YAML
application:
  overview:
    model_name: falls_templated
    model_suffix: model
    run_type: monthly
    description: Predicts risk of future Falls events.
  application_variables:
    MAPPING_FILES_DIR: /mnt/azureblobshare/data/resources/mapping_files/falls
  environment:
    databricks_runtime_version: 10.4.x-cpu-ml-scala2.12
    node_type: Standard_DS5_v2
    min_workers: 4
    max_workers: 4
```

This configuration outlines the basic settings for your model, including the environment it will run in and any
application-specific variables. It will generate
the following `application.yaml` file in your project structure:

```YAML
name: falls_templated_model
description: Predicts risk of future Falls events.
configuration:
  MAPPING_FILES_DIR: /mnt/azureblobshare/data/resources/mapping_files/falls
cluster:
  create_cluster: false
  databricks_runtime_version: 10.4.x-cpu-ml-scala2.12
  node_type: Standard_DS5_v2
  min_workers: 4
  max_workers: 4
```

### Step 2: Define Jobs

Define each job within your model's lifecycle, specifying the environment, inputs, outputs, and the code to be executed.

#### Template Structure:

```yaml
# Jobs Configuration
# The `jobs` section defines individual jobs that will run on Databricks job clusters.
# Each job can have its own environment settings, source code, and data inputs/outputs.
jobs:
  # Example job for cohort creation
  - name:
    environment:
      # Job-specific environment settings (similar to the application environment settings)
      node_type:
      min_workers:
      max_workers:
    user_inputs:
      # Define any user inputs required by the job. Specify type, whether it's required, and a default value.
      cdo_list:
        type:
        required:
        default:
      lookback_months:
        type:
        required:
        default:
    source_code:
      # Specify the source code classes and import paths for the job logic.
      - class:
        import_path:
        returns:
    variable_aliases:
      # Define any aliases for variables used in the job. Helps with readability and maintainability.
      anchor_date:
    data:
      inputs:
        # Define data inputs with source details. Can specify tables, custom scripts, etc.
        - variable:
          table:
      outputs:
        # Define outputs of the job, including intermediate paths or tables for storing results.
        - variable:
          intermediates_path:
  # Additional jobs (e.g., feature_creation, scoring, labels) follow the same structure.
  # Refer to the provided example for setting up different types of jobs.
```

#### Example Configuration:

```YAML
jobs:
  - name: cohort_creation
    environment:
      node_type: Standard_DS5_v2
      min_workers: 2
      max_workers: 2
    user_inputs:
      cdo_list:
        type: list
        required: false
        default: [ ]
      lookback_months:
        type: int
        required: false
        default: 12
    source_code:
      - class: CreateCohort
        import_path: ml_pipeline.src.falls.cohort_creation
        returns: cohort
    variable_aliases:
      anchor_date: run_as_of
    data:
      inputs:
        - variable: elig_risk
          table: "{input_schema}.eods_elig_risk"
      outputs:
        - variable: cohort
          intermediates_path: falls_cohort
  - name: feature_creation
    environment:
      node_type: Standard_DS5_v2
      min_workers: 8
      max_workers: 8
    user_inputs:
      cdo_list:
        type: list
        required: false
        default: [ ]
      lookback_months:
        type: int
        required: false
        default: 12
    source_code:
      - class: CreateFeatures
        import_path: ml_pipeline.src.falls.feature_creation
        returns: features
    variable_aliases:
      anchor_date: run_as_of
    imports:
      - import pandas as pd
    data:
      inputs:
        - variable: cohort
          intermediates_path: falls_cohort
        - variable: cdf_codes
          table: "{input_schema}.cdf_codes"
        - variable: cdf_members
          table: "{input_schema}.cdf_members"
        - variable: falls_icd_definitions
          custom: pd.read_csv(f"{self.get('MAPPING_FILES_DIR')}/falls_definitions.csv")
        - variable: falls_feature_definitions
          custom: pd.read_csv(f"{self.get('MAPPING_FILES_DIR')}/falls_feats_definitions.csv")
        - variable: ndc_gpi_xwalk
          custom: pd.read_csv(f"{self.get('MAPPING_FILES_DIR')}/ndc_gpi_crosswalk.csv")
      outputs:
        - variable: features
          intermediates_path: falls_features
  - name: scoring
    environment:
      node_type: Standard_DS5_v2
      min_workers: 2
      max_workers: 2
      pip_dependencies:
        - "xgboost==0.90"
        - "scikit-learn==0.23.1"
    user_inputs: { }
    source_code:
      - class: Scoring
        import_path: ml_pipeline.src.falls.scoring
        returns: predictions
    imports:
      - import pickle
    data:
      inputs:
        - variable: features
          intermediates_path: falls_features
        - variable: model_obj
          pickle: "f'{self.repo_path}/ml_pipeline/src/falls/model_files/falls_xgb.pkl'"
      outputs:
        - variable: predictions
          intermediates_path: falls_predictions
          output_store:
            column_mappings: { fall-score: FALL_SCORE, fall-risk: FALL_RISK }
            data_link_columns: [ UNIQ_MBR_ID, ENTY_ID ]
  - name: labels
    environment:
      node_type: Standard_DS5_v2
      min_workers: 6
      max_workers: 6
    user_inputs:
      orchestration_ids:
        type: list
        required: false
        default: ~
      parent_ids:
        type: list
        required: false
        default: ~
    source_code:
      - class: Labels
        import_path: ml_pipeline.src.falls.labels
        returns: labels
    data:
      inputs: { }
      outputs:
        - variable: labels
          output_store:
            column_mappings: { fall-label: label, predicted-positive: IS_FALLS_HIGH }
            data_link_columns: [ UNIQ_MBR_ID, ENTY_ID ]
```

This section of your YAML file will generate individual YAML files and definitions for your jobs which will look like
this,
for the first job in the above example:

```yaml
cohort_creation:
  class: CohortCreationUnifaiJob
  sys_paths:
    - "{REPO_PATH}"
  inputs:
    cdo_list:
      type: list
      required: false
      default: []
    lookback_months:
      type: int
      required: false
      default: 12
    run_as_of:
      type: string
      required: false
      default: "{SYS_TODAY}"
    run_type:
      type: string
      required: false
      default: MONTHLY
    input_schema:
      type: string
      required: false
      default: "{SCHEMA}"
  cluster:
    runtime_version: 10.4.x-cpu-ml-scala2.12
    node_type: Standard_DS5_v2
    min_workers: 2
    max_workers: 2
```

### Step 3: Define Orchestration

This step focuses on setting up the `dags` directory as outlined below, facilitating orchestration within the project
structure:

#### Template Structure:

```yaml
# Orchestration Configuration
# The `orchestration` section defines settings for automating the workflow, particularly for Airflow.
# It includes repository information for version control, DAG configurations, and job execution order.
orchestration:
  git:
    # repo_url: URL of the git repository containing the model and pipeline code.
    # default_model_version: Specifies the branch, tag, or commit to use by default.
    repo_url:
    default_model_version:
      branch:
  dag:
    # owner: The owner of the Airflow DAG.
    # tags: Tags for categorizing and filtering DAGs within Airflow.
    # email: Configuration for email notifications on job failures or retries.
    # retries: Number of times to retry a failed task before marking it as failed.
    # default_connection_id: Specifies the Airflow connection ID to use for tasks.
    owner:
    tags:
      -
    email:
      address_list:
      email_on_retry:
      email_on_failure:
    retries:
    default_connection_id:
  job_order:
    # Define the order in which jobs should be executed. Important for managing dependencies between jobs.
    -
```

#### Example Configuration:

```yaml
orchestration:
  git:
    repo_url: https://github.com/uhg-private/unifai-eods
    default_model_version:
      branch: main
  dag:
    owner: oh_admin
    tags:
      - monthly
      - unifai
    email:
      address_list: ["patrick.prunty@optum.com"]
      email_on_retry: false
      email_on_failure: true
    retries: 0
    default_connection_id: unifai-dev
  job_order:
    - cohort_creation
    - feature_creation
    - scoring
    - labels # Required for retrospectives
```

This configuration specifies the job sequence for UnifAI applications, leading to the automatic creation of two Airflow
DAGs, prospective and retrospective. We have put the sample output DAGs code at the bottom of this document
to account for continuity. In short, the two DAG files created will be what is executed by Airflow. When the UnifAI app
is deployed, one step of that deployment is to upload those DAGs to the configured Airflow instance.

## Create App from Template

Once you have your template defined, you can run the following CLI command to create your UnifAI application for your
AI/ML model:

```shell
unifai-admin template create-app --source <model_name>.yaml --destination . --git-branch <branch_name> --git-push --airflow-publish
```

The following command will create a UnifAI project structure for your AI/ML model, create a github branch and push your
changes (with your new UnifAI AI/ML application directory) to GitHub and publish the respective prospective and
retrospective DAGs to Airflow.

## Sample DAGs Output

#### Prospective Pipeline:

```python
"""
TODO: Add DAG-level docstring.
"""


from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.operators.python import BranchPythonOperator, PythonOperator
from airflow.utils.trigger_rule import TriggerRule
from airflow.models.baseoperator import chain
from airflow.utils.task_group import TaskGroup

from datetime import datetime
from uuid import uuid4

from unifai_helper import UnifaiAppPublishOperator
from unifai_helper import UnifaiJobRunOperator

with DAG(
        dag_id="unifai-falls-templated-model-prospective",
        description="UnifAI Falls Templated prospective run.",
        render_template_as_native_obj=True,
        dagrun_timeout=None,
        default_args={
            "owner": "oh_admin",
            "depends_on_past": False,
            "email": ['jose.mendes@optum.com'],
            "email_on_failure": True,
            "email_on_retry": False,
            "retries": 0,
        },
        catchup=False,
        schedule_interval=None,
        start_date=datetime(2024, 3, 11),
        tags=['monthly', 'unifai'],
        params={
            "connection_id": "unifai-dev",
            "skip_publish": False,
            "skip_data_quality": True,
            "use_shared_cluster": False,
            "model_version": "--branch main",
            "parent_id": None,
            "run_as_of": f"{datetime.today().date()}",
            "run_type": "MONTHLY",
            "input_schema": None,
            "cdo_list": [],
            "lookback_months": 12,
        }
) as dag:
    MODEL = "falls_templated_model"
APP_PATH = f"unifai_{MODEL}"
MODEL_VERSION = "{{ params.model_version }}"
CONNECTION_ID = "{{ params.connection_id }}"
USE_SHARED_CLUSTER = "{{ params.use_shared_cluster }}"

RUN_AS_OF = "{{ ti.xcom_pull('setup')['run_as_of'] }}"
RUN_TYPE = "{{ params.run_type }}"
ORCHESTRATION_ID = "{{ ti.xcom_pull('setup')['orchestration_id'] }}"
PARENT_ID = "{{ ti.xcom_pull('setup')['parent_id'] }}"
INPUT_SCHEMA = "{{ params.input_schema }}"

JOBS = ['cohort_creation', 'feature_creation', 'scoring']
JOB_INPUTS = {
    "cdo_list": '{{ params.cdo_list }}',
    "lookback_months": '{{ params.lookback_months }}',
}


# Shared job functions
def do_data_quality_fn(dag_run, **kwargs):
    # Skip Data Quality based on parameter
    if dag_run.conf.get("skip_data_quality", True):
        return ["end"]
    return ["data-quality"]


def do_publish_fn(dag_run, **kwargs):
    # Skip publish if DAG is called from a parent
    if dag_run.conf.get("parent_id") and str(dag_run.conf.get("skip_publish", False)).lower() == "true":
        return ["model"]
    return ["unifai-apps-publish"]


def setup_fn(dag_run, params, **kwargs):
    def fill_default(key, default=None):
        value = dag_run.conf.get(key)
        if str(value).lower() in ["", "none"]:
            value = default or params.get(key)
        return value

    return {
        "orchestration_id": str(uuid4()),
        "parent_id": fill_default("parent_id"),
        "run_as_of": fill_default("run_as_of", dag_run.logical_date.strftime("%Y-%m-%d")),
    }


# DAG Tasks
setup = PythonOperator(
    task_id="setup",
    do_xcom_push=True,
    python_callable=setup_fn
)

do_publish = BranchPythonOperator(
    task_id="do-publish",
    python_callable=do_publish_fn,
    provide_context=True,
)

publish = UnifaiAppPublishOperator(
    app_path=f"unifai_{MODEL}",
    github_url="https://github.com/uhg-private/unifai-eods",
    github_version=MODEL_VERSION,
    conn_id=CONNECTION_ID,
    orchestration_id=ORCHESTRATION_ID,
    parent_id=PARENT_ID,
    retries=3,  # Increase number of retries for use in any composite DAG
)

# Build model-specific jobs
with TaskGroup(group_id="falls-templated-model-tasks") as model:
    job_tasks = []
    for job in JOBS:
        job_tasks.append(
            UnifaiJobRunOperator(
                task_id=job,
                job_name=f"{MODEL}.{job}",
                conn_id=CONNECTION_ID,
                orchestration_id=ORCHESTRATION_ID,
                parent_id=PARENT_ID,
                run_as_of=RUN_AS_OF,
                run_type=RUN_TYPE,
                trigger_rule=TriggerRule.NONE_FAILED,
                use_shared_cluster=USE_SHARED_CLUSTER,
                debug=True,
                input_schema=INPUT_SCHEMA,
                **JOB_INPUTS
            )
        )
    chain(*job_tasks)

do_data_quality = BranchPythonOperator(
    task_id="do-data-quality",
    python_callable=do_data_quality_fn,
    provide_context=True,
)

data_quality = EmptyOperator(
    task_id="data-quality")  # UnifaiTriggerDagRunOperator()  # Engg. TODO: Add support for Data Quality

end = EmptyOperator(task_id="end")

# DAG Sequence
do_publish >> model
do_data_quality >> end
setup >> do_publish >> publish >> model >> do_data_quality >> data_quality >> end
```

#### Retrospective Pipeline:

```python

  """
TODO: Add DAG-level docstring.
"""

    from airflow import DAG
    from airflow.decorators import task
    from airflow.operators.empty import EmptyOperator
    from airflow.operators.python import BranchPythonOperator, PythonOperator
    from airflow.utils.trigger_rule import TriggerRule

    from uuid import uuid4
    from datetime import datetime
    from dateutil.relativedelta import relativedelta

    from unifai_helper import UnifaiAppPublishOperator
    from unifai_helper import UnifaiJobRunOperator
    from trigger_dag_run_operator import UnifaiTriggerDagRunOperator

  # TODO: confirm no overlap with existing DAG file


    with DAG(
    dag_id="unifai-{MODEL_NAME_LOWER_HYPHEN}-{MODEL_SUFFIX_LOWER}-retrospective",
    description="UnifAI {MODEL_NAME_CAPITALIZE} retrospective run.",
    render_template_as_native_obj=True,
    dagrun_timeout=None,
    default_args={
                "owner": "{DAG_OWNER}",
                "depends_on_past": False,
                "email": { EMAIL_ADDRESSES },
                "email_on_failure": { EMAIL_ON_FAILURE },
                "email_on_retry": { EMAIL_ON_RETRY },
                "retries": { RETRIES },
              },
  catchup=False,
  schedule_interval=None,
  start_date={TODAY},
  tags={TAGS},
  params={
          "connection_id": "{DEFAULT_CONNECTION_ID}",
          "model_version": "{DEFAULT_MODEL_VERSION}",
          "parent_id": str(uuid4()),
          "last_retro_date": f"{datetime.today().date().replace(day=1)}",
          "n_retro_months": 24,
          "input_schema": None,
          "cdo_list": [],
          "lookback_months": 12,
      }
) as dag:
  MODEL = "{MODEL_NAME_LOWER}_{MODEL_SUFFIX_LOWER}"
  APP_PATH = "unifai_{MODEL}"
  MODEL_REPO = "{MODEL_REPO}"
  MODEL_VERSION = "{{ params.model_version }}"
  CONNECTION_ID = "{{ params.connection_id }}"
  RETRO_RUN_DATE = "{{ ti.xcom_pull('setup')['last_retro_date'] }}"

  PARENT_ID = "{{ ti.xcom_pull('setup')['parent_id'] }}"

  RUN_AS_OF = "{{ ti.xcom_pull('setup')['run_as_of'] }}"
  INPUT_SCHEMA = "{{ params.input_schema }}"

  PROSPECTIVE_DAG_ID = "unifai-{MODEL_NAME_LOWER}-{MODEL_SUFFIX_LOWER}-prospective"

  __ADD_JOBS_AND_INPUTS__

  # ---------- Setup ----------
  def setup_fn(dag_run, params, **kwargs):
    def fill_default(key, default = None):
      value = dag_run.conf.get(key)
      if str(value).lower() in ["", "none"]:
        value = default or params.get(key)
      return value
    return {
    "parent_id": str(uuid4()),
    "run_as_of": fill_default("run_as_of", dag_run.logical_date.strftime("%Y-%m-%d")),
    "last_retro_date": fill_default("retro_run_date", dag_run.logical_date.strftime("%Y-%m-%d"))
}

  setup = PythonOperator(
  task_id = "setup",
  do_xcom_push = True,
  python_callable = setup_fn
  )
  publish = UnifaiAppPublishOperator(
  app_path = f"unifai_{MODEL}",
  github_url = "{MODEL_REPO}",
  github_version = MODEL_VERSION,
  conn_id = CONNECTION_ID,
  parent_id = PARENT_ID
  )

  # ---------- Prospective Months ----------
  @task
def prospective_lookback_months(**context):
  # Create dynamic params for each downstream DAG. Here we use retro_months (N) to create a list of N params
  # to be passed to the downstream DAG. For example, if retro_months = 3. This function returns [0,1,2]
  retro_months = context["dag_run"].conf["n_retro_months"]
  print(f"Number of lookback months for retro run from build configuration: { retro_months }")
        return [idx for idx in range(0, retro_months)]


    @task(max_active_tis_per_dag=6)
    def trigger_prospectives(retro_date: str, retro_month: int, **context):
        # Static configuration to pass to downstream DAG includes all params passed to retro dag (connection_id,
        # model_version, retro_run_date, run_type, input_schema and parent_id) + whatever else is static and computed at
        # run time such as the retro_run_date which is fixed as the first day of the month in this example
        retro_date = datetime.strptime(retro_date, "%Y-%m-%d").date().replace(day=1)
  # retro_run_date is used to adjust run_as_of for every retro month
  config = {
  "connection_id": CONNECTION_ID,
  "model_version": MODEL_VERSION,
  "parent_id": context['ti'].xcom_pull('setup')['parent_id'],
  "run_as_of": f"{retro_date- relativedelta(months=retro_month)}",
  "run_type": "RETROSPECTIVE",
  "input_schema": INPUT_SCHEMA
  'skip_publish': True,
  'skip_data_quality': True,
  "wait_for_dq_completion": True,
  "config_type": "default"
}

  print(
  f" ------ Triggering prospective DAG '{PROSPECTIVE_DAG_ID}' ----- \n"
f" ------ config: { config } ------ \n")

  trigger_dag_operator = UnifaiTriggerDagRunOperator(
  task_id=f"Month_{retro_month}",
  trigger_dag_id=PROSPECTIVE_DAG_ID,
  conf=config,
  wait_for_completion=True
  )

  trigger_dag_operator.execute(context=context)

  # ---------- Labels ----------
  labels = UnifaiJobRunOperator(
  task_id = f"labels",
  job_name = "{MODEL}.labels",
  conn_id = CONNECTION_ID,
  parent_id = PARENT_ID,
  run_type = "RETROSPECTIVE",
  trigger_rule = TriggerRule.NONE_FAILED,
  use_shared_cluster = False,
  debug = True,
  **JOB_INPUTS
  )

  # ---------- DAG ----------
  setup >> publish >> \
  trigger_prospectives.partial(retro_date=RETRO_RUN_DATE).expand(retro_month=prospective_lookback_months()) >> \
  labels >> \
  EmptyOperator(task_id = "end")

```
