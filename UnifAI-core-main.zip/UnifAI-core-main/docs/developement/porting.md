# How to 'UnifAI' a model

This section outlines the steps for integrating UnifAI with an existing model. By leveraging UnifAI, users can benefit from its bookkeeping capabilities, which include tracking runs, code versions, parameters etc. Even if a model already runs using its config and pipelines, UnifAI can still be wrapped around the model to run it as a UnifAI job.

To wrap the model for UnifAI, the core code responsible for transforming data, loading, and writing data is placed inside a main function. The initial setup required for running the model is placed inside the `if __name__ == 'main'` block. This setup is executed first when the script is called directly, allowing the model to be run in a non-UnifAI way. When the model is run as a UnifAI job, the required configurations and setup are done within the UnifAI app created for the model.

This approach provides users with the flexibility to run the model both in the UnifAI and non-UnifAI ways. The following sections detail the steps for UnifAI-ing a model.

### A brief overview of all the components <a name = "overview"></a>

This section pictorially represents the flow for the unifai app publish and model scoring. For more details about each step highlighted please refer to next section.

**App Publish**

![App Publish](../images/app_publish.png)

**Model Scoring**

![Model Scoring](../images/model_scoring.png)

### Core Code Changes

UnifAI makes use of a data wrapper DataIO to read/write either read from file paths or use UnifAI functionality. It plays a very important role in enabling unifai job runs. There could be two scenarios for core code changes:

1. **There exists a process to run a model and UnifAI capability must be added**

Assuming [this](https://github.com/optum-labs/UnifAI-core/commit/66871988fe70ad632244f6f68d2ba3b62720948d#diff-c1dd7a1a11fba49474e6d5f631cda5161fd98fc9acbe60d4406cbeb716e671bb) is the code that needs to be ported to make use of UnifAI, these are the steps that need to be taken:

- Separate the code into `main()` function and `if __name__ == "main"`:

  To integrate UnifAI with an existing model, the core code logic should be moved into the main function with an argument called `configs`. Any other utility functions defined within the code can be left as is.

  Under `if __name__ == "main"`, all the configuration loads and `sys.path` initializations should be placed. This allows the model to be run outside of UnifAI.

  As a next step, certain library imports that are only referenced within this block should be moved into the `if __name__ == "main"` block. This ensures that these libraries are only loaded when necessary, which can help optimize the performance of the model.

  [This](https://github.com/optum-labs/UnifAI-core/commit/b479a5171f987f7188e46d3ec79cc09ee01ef9f3) is what the example code would look like after this step

- Add dataio references within main function:

  To further integrate UnifAI with an existing model, an additional argument called `dataio` should be added to the main function: `main(configs, dataio)`.

  Next, all references to Spark/Pandas read/write objects should be found and replaced with `dataio`. This ensures that all data input/output is done through `dataio`, making the model compatible with UnifAI's bookkeeping capabilities.

  If there are any pickle files to be loaded, they should be replaced with `dataio.model.load_pickle`. This ensures that all model data is loaded through `dataio`, making the model compatible with UnifAI's bookkeeping capabilities

  [This](https://github.com/optum-labs/UnifAI-core/commit/1d312c7b82df9e9312f3aafcf1dcc462b276b569) is the example code after adding dataio reference.

- Add dataio to `if __name__ == "main"`:

  It is important to note that the `dataio` parameter is now mandatory for the main function. Therefore, when running non-UnifAI jobs, a reference to `dataio` must be added within `if __name__ == "main"` to ensure that models can still run.

  This can be accomplished by referencing a dataio library that is designed to overload the Spark and Pandas read/write methods. These methods work as expected for the user and read/write from filepaths as specified within the non-UnifAI config files. After importing this library, the main function can be called with the non-UnifAI config file and `dataio` object.

  By following these steps, users can seamlessly run their models both within and outside of the UnifAI environment.

  [This](https://github.com/optum-labs/UnifAI-core/commit/d9b065173df2e3589d5909584c7ce57b91c841a4) code highlights the library import and initialization of dataio object.

- Add the dataio class for non-unifai runs into repository:

  To support the import of the UnifAI DataIO module in the previous step, a folder named `common` should be created within the same folder where all the models exist and add [this](https://github.com/uhg-private/unifai-eods/blob/prod/ml_pipeline/src/common/dataio.py) code to support the import in the previous step.

  This code mimics the UnifAI DataIO module, but without the UnifAI capabilities. It allows models to be run outside of UnifAI while still using the same input/output methods.

- To fully integrate the UnifAI DataIO module with existing models, an `else` section should be added to the `if __name__ == "main"` block. This section should include any library imports required for the core code to run and that are defined only within `if __name__ == "main"`.

  For UnifAI runs, the `sys` paths can be added within the job-specific yaml as described in a later section. However, the libraries still need to be imported, and this can be done within the `else` section.

  [This](https://github.com/optum-labs/UnifAI-core/commit/0f5d8f47ba3369f7184a552c271e05558f6408f7) code snippet highlights the addition of else section along with the required library import.

- As a final step in the integration process, it's important to make note of all the configs used within the core code. This information will be useful for making any UnifAI-related changes that will be made as described in the next section.

  By keeping this information handy, users can quickly and easily make any necessary updates to their models to ensure full compatibility with UnifAI, even as their code and configurations change over time.

2. **Using only UnifAI to run the model on databricks**

In this scenario, the implementation differs in that the `if __name__ == "main"` block is not required, as UnifAI has all the necessary setup ready to call the main function. However, the remaining steps of creating a main function to wrap the model code with the DataIO wrapper are still required.

The library imports required for the core code can be left as is, along with all other library declarations.

### UnifAI Changes

For creating a UnifAI x Model app we create the following folder structure within the main folder:

```
unifai_<model_name>_model
├── README.md
├── application.yaml
├── configs
│   ├── config_template.yaml
│   └── path_to_table_mapping.yaml
├── dags
│   ├── <model_name>_model.py
│   └── <model_name>_retro.py
├── jobs
│   └── cohort_builder.yaml
│   └── feature_creation.yaml
│   └── model_scoring.yaml
├── schema
│   ├── table1.yaml
│   ├── table2.yaml
│   ├── table3.yaml
│   ├── table4.yaml
└── src
    ├── __init__.py
    └── cohort_builder.py
    └── feature_creation.py
    └── model_scoring.py
```

#### configs

1. **config_template.yaml**:

The `config_template.yaml` file holds all the configurations that will be required to run a model. File paths, flags, input values, and other necessary parameters are set in this file.

The following conventions are used within the UnifAI app for referencing file paths:

- {REPO_PATH} : When we want to reference a file stored within the code repository
- {APP_PATH} : This would point to the unifai app folder.
- `"/tmp/__UNIFAI_APP__/"` : This notation is used as a default value or when we want to use a delta lake table mapping instead of a filepath.

If the key-value generally doesn’t change then it can be hardcoded else the value can be represented in the following way : `{PARAM}`. If there is a training flag present in the config it is always set to False for a unifai job.

**Example:**

```yaml
cdo_list: "{CDO_LIST}"
run_date: "{RUN_DATE}"

scoring_configs:
  skip_logging: true
  training: false

fpaths:
  subdir:
    table1: /tmp/__UNIFAI_APP__/
    table2: /tmp/__UNIFAI_APP__/
    table3: /tmp/__UNIFAI_APP__/
  pipeline:
    root: /tmp/__UNIFAI_APP__/
    data_dump: /tmp/__UNIFAI_APP__/
    scoring_files: /tmp/__UNIFAI_APP__/
    mapping_files: "/dbfs/mnt/azureblobshare/<path_to_mapping_files>"
    model_path: "{REPO_PATH}/ml_pipeline/src/<path_to_model>"
```

Here is a [link](https://github.com/uhg-private/unifai-eods/blob/prod/unifai_chronicity_model/configs/config_template.yaml) to an existing config_template.yaml file currently used for production runs.

2.**path_to_table_mapping.yaml**:

The `path_to_table_mapping.yaml` file holds the file path to Delta Lake table mappings, associated with their corresponding Delta Lake tables. If the files are dynamic, they can be represented using Unix shell-style wildcards.

If the schema from which the table has to be read or written is different from the current job schema, add a `schema` key with the value `{INPUT_SCHEMA}`.

If the file acts as a final output/scoring file, in that case, an output store mapping should be added along with the data link and column mappings. UnifAI stores the final results in a table called `unifai_core_model_output_store` and it expects two specifications before it can write data into this table.

1. data_link_columns : This is a list of columns to concatenate from the dataframe before we write into the output store and will be stored in the column data_link_type of table `unifai_core_model_output_store` . The corresponding values of this combination will be stored in the column data_link_value.

2. calc_column_mapping: This could be the unique score/risk/category values being generated by the model. These values are used to pivot the entries based on this column into a corresponding column called calculation_name in the `unifai_core_model_output_store`. The corresponding value of these columns are stored in calculation_value column. The convention followed here will be <name_of_calculation_type_in_output_store>: <name_of_column_in_final_output_dataframe>

The first entry will define what the name of the calculation should be within the output store and the second corresponding entry is the name of the column from the final output dataframe which holds this value.

For example: Based on the below example for every unique combination of ["ID", "DOB"] there will be a corresponding unique entry of model_score and model_category.

Based on the mapping sampleapp-score holds the value of model_score column and sampleapp-category holds model_category column values from the final output dataframe which would have been used to write into the final results csv file.

```
| calculation_name     | calculation_value | data_link_type | data_link_value   |
|----------------------|-------------------|----------------|-------------------|
| sampleapp-score      | 0.75              | ID|DOB         | 1234|20120817     |
| sampleapp-category   | HIGH              | ID|DOB         | 1234|20120817     |

```

Here's an example of what the updated `path_to_table_mapping.yaml` file might look like:

**Example**

```yaml
# Shared tables
table1:
  table: unifai_table1
  schema: "{INPUT_SCHEMA}"
table2:
  table: unifai_table2
  schema: "{INPUT_SCHEMA}"
table3:
  table: temp_table3

# Job-specific tables
model_scoring:
  "*_scoring.csv":
    table: ~
    output_store_mapping:
      calc_column_mappings:
        sampleapp-score: model_score
        sampleapp-category: model_category
      data_link_columns: ["ID", "DOB"]
```

Here is a [link](https://github.com/uhg-private/unifai-eods/blob/prod/unifai_chronicity_model/configs/path_to_table_mapping.yaml) to an existing yaml file currently used for production runs.

By following these conventions, users can ensure that their Delta Lake tables and associated file paths are properly mapped and can be read and written to by their models.

#### dags

  <!-- Add link to custom API on Airflow when available -->

The `dags` folder contains the DAG code to run the model. This DAG can be deployed to Airflow via the `unifai-admin dags publish` command or using an API. (Find out more about the custom API deployed on Airflow for unifAI support [here]()).These DAGs make use of Airflow plugins such as `UnifaiBootstrapOperator`, `UnifaiPublishOperator` and `UnifaiJobRunOperator`. Find more details about these plugins [here](https://unifai-docs.optum.com/usage/airflow.html).

There can be multiple DAGs within this folder, each serving different purposes of the model run. These DAGs can be customized to suit the specific needs of the user, such as scheduling and dependencies.

Here is an example of what a prospective run DAG would look like:

  <!-- NOTE:  We should add UnifaiDataQualityOperator and UnifaiTriggerDagRunOperator in airflow.md -->

**Example**

  <!-- TODO : Update this DAG example to latest version -->

```python
from datetime import datetime
from airflow import DAG
from unifai_helper import UnifaiAppPublishOperator
from unifai_helper import UnifaiJobRunOperator

with DAG(
        dag_id="sample_app",
        description="Sample App",
        dagrun_timeout=None,
        render_template_as_native_obj=True,
        default_args={
            "owner": "oh_admin",
            "depends_on_past": False,
            "email": EMAIL_ADDRESSES,
            "email_on_failure": True,
            "email_on_retry": False,
            "email_on_success": False,
            "max_active_runs": 1,
            "retries": 0,
        },
        catchup=False,
        schedule_interval=None,
        start_date=datetime(2023, 1, 1),
        tags=["sample", "app"],
        params={
            "connection_id": "unifai_prod_connection",
            "model_version": "--branch prod",
            "run_as_of": f"{datetime.today().date()}",
            "input_schema": None,
        }
) as dag:
    CONNECTION_ID = '{{dag_run.conf.get("connection_id")}}'
    RUN_AS_OF = '{{dag_run.conf.get("run_date")}}'
    INPUT_SCHEMA = '{{ dag_run.conf.get("input_schema")}}'

    # DAG Tasks
    model_publish = UnifaiAppPublishOperator(
        conn_id = CONNECTION_ID,
        dag = dag,
        task_id = "publish",
        app_path = "sample_app",
        github_url = "https://github.com/repo/dummy_repo",
        github_version = '{{dag_run.conf.get("model_version")}}'
    )

    model_scoring = UnifaiJobRunOperator(
        conn_id = CONNECTION_ID,
        dag = dag,
        task_id = "scoring",
        job_name = "sample_app.scoring",
        use_shared_cluster = True,
        wait = True,
        # Job Specific Configuration
        run_as_of = RUN_AS_OF,
        input_schema = INPUT_SCHEMA,
    )

    # DAG Sequence
    model_publish >> model_scoring
```

Here is a [link](https://github.com/uhg-private/unifai-eods/blob/prod/unifai_chronicity_model/dags/chronicity_model.py) to an existing DAG created for triggering the entire model workflow.

#### data_quality

All the content_check and ai_check rules are placed here. To learn more about data_quality rules creation please check [here](../data_quallity/rules.md).
If the model does not require any data_quality check then this folder can be left empty.

<!-- TODO : add link to data quality rules documentation here -->

#### jobs

The `jobs` folder holds the job configurations required to run each section of the model. Within the YAML file, users can specify the inputs required by the model, their data type, and default values. Any package dependencies required by the model can also be specified here along with job cluster configurations.

Additionally, users can set the `sys` paths here, which can be used for importing different sections of code. This allows for greater flexibility in how the model is run and what dependencies are required.

**Example**

```yaml
model_scoring:
  class: SampleAppScoringJob

  sys_paths:
    - "{REPO_PATH}/src"

  dependencies:
    - "xgboost==0.90"

  inputs:
    run_as_of:
      type: STRING
      required: true
      default: "{SYS_TODAY}"
    input_schema:
      type: STRING
      required: false

  cluster:
    runtime_version: "10.4.x-cpu-ml-scala2.12"
    node_type: "Standard_DS5_v2"
    use_photon: false
    max_workers: 8
    min_workers: 4
```

Here is a [link](https://github.com/uhg-private/unifai-eods/blob/prod/unifai_chronicity_model/jobs/model_scoring.yaml) to an existing job definition currently being used in production.

#### schema

The `schemas` folder holds the schema definitions of the intermediate tables that will be required for running the model. UnifAI holds all intermediate data in Delta Lake, so users will have to define their schemas in YAML files within this folder.

As a prerequisite for creating the schemas, users should include the following UnifAI-specific columns as part of schema definition: `orchestration_id`, `run_id`, `run_as_of`, and `run_type`. It is also recommended to partition these tables by `orchestration_id`.

**Example**

```yaml
sample_table:
  type: delta
  partitioned_by:
    - orchestration_id
  columns:
    column_1: STRING
    column_2: DOUBLE
    column_3: DOUBLE
    orchestration_id: STRING
    run_id: STRING
    run_as_of: DATE
    run_type: STRING
```

#### src

  <!--TODO: add DataIO doc link when available -->

The `src` folder holds the JobClass definitions, which hold the execute methods to run the models. These JobClasses are responsible for initializing the `DataIO` object, which holds the configurations and path to table mappings required to successfully run the model.

**Example**

```python
from typing import Optional

from sampleapp_scoring import main
from unifai_core.jobs.legacy_adapter import UnifaiLegacyAdapterJob


class SampleAppScoringJob(UnifaiLegacyAdapterJob):
    """Sample App Scoring Job."""

    def execute(self, spark, run_as_of: str, input_schema: Optional[str], **kwargs):
        """Main entry method where the job execution begins."""
        # Load config to match legacy-pipeline config; specify {placeholder}={value} for config placeholders
        config = self.pipeline_config(
            run_date=run_as_of,
        )

        # Build data adapter instance; specify {placeholder}={schema} for schema placeholders
        dataio = self.data_adapter(
            input_schema=input_schema or spark.catalog.currentDatabase()
        )

        # Run scoring
        main(dataio, config, run_writer=self.stub_class())
```

Click [here](#overview) to understand how everything is connected

#### application.yaml

The `application.yaml` file describes the cluster requirements to run the jobs on Databricks. If the model is making use of UnifAI-supported data-quality checks, then the folder path for the `content_check` and `ai_check` rules should be configured here.

**Example**

```yaml
name: <model_name>
description: "Port of <model_name> to unifai app"

# configuration:
#   TBC: "add config as required"

data_quality:
  default:
    content_check: "data_quality/content_check"
    ai_check: "data_quality/ai_check"

cluster:
  create_cluster: false
  runtime_version: "10.4.x-cpu-ml-scala2.12"
  node_type: "Standard_D3_v2"
  use_photon: false
  max_workers: 8
  min_workers: 4

env_variables:
  DUMMY_VARIABLE: remove_this__used_for_iqs_pypi_hotfix

spark_config:
  "spark.databricks.delta.preview.enabled": "true"
  "spark.driver.maxResultSize": "8g"
# init_script: |
#   #!/bin/bash
#   source {FILE_STORE_PATH}/scripts/default-init.sh
#   echo "-- application init starts here ---"
```

Here is a [link](https://github.com/uhg-private/unifai-eods/blob/prod/unifai_chronicity_model/application.yaml) to an existing application.yaml file being used for production runs

#### README.md

This markdown file can contain any model specific documentation along witha guide to users detailing how to publish and run the model using unifai-admin commands. This markdown is not a pre-requisite but more of a good to have documentation.
