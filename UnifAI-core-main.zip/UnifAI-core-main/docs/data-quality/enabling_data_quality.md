# Enabling Data Quality with UnifAI

DataQuality is a powerful feature integrated within UnifAI core, enabling seamless integration with any existing application. It can create significant impact by running checks on the incoming Data to eliminate quality related issues that can pop up due to non-compliant records.

## Artifacts management

DataQuality is the spark driven job which requires various jar files and other dependencies. These dependencies are readily available on the [artifactory](https://repo1.uhc.com/artifactory/) server. The required dependencies are described in the application.yaml file of the [unifai_core_app](https://github.com/optum-labs/UnifAI-core/blob/main/src/unifai_core_app/application.yaml) folder under `dependencies` as shown below:

```
dependencies:
  - config: DATA_QUALITY_DEP_CHIMERA
    source: https://repo1.uhc.com/artifactory/maven-repo/com/optum/reuse/chimera/3.6.2/chimera-3.6.2.jar
    target: chimera_3_6_2.jar
    version: 3.6.2
  - config: DATA_QUALITY_DEP_DVP
    source: https://repo1.uhc.com/artifactory/UHG-Releases/com/optum/oap/aggregation-enrichment-engine/5.8.1/aggregation-enrichment-engine-5.8.1.jar
    target: dvp_5_8_1.jar
    version: 5.8.1
  - config: DATA_QUALITY_DEP_DVP_ZIP
    source: https://repo1.uhc.com/artifactory/UHG-Releases/com/optum/oap/evaluation/5.8.1/evaluation-5.8.1.zip
    target: DataQuality/binaries/master/119/build # target needs to be updated if DVP ZIP version is modified(as the unzipped file structure is different)
    version: 5.8.1
```

In case of any new version release, user can modify the dependencies version and source as requried above.
These dependencies are downloaded during UnifAI-core bootstrap run. User can manage the artifactory upload by providing additional option:
`unifai-admin bootstrap --skip-upload`.
In case we provide `--skip-upload False`, these above dependencies get downloaded to the terminal and uploaded back to the databricks filestore path `{FILE_STORE_PATH/dependencies}` which are then referred during the spark-submit job run of DataQuality.

## Data Validation Checks

UnifAI-Core offers two robust Data Quality checks:

1. **AI-CHECK**
2. **CONTENT-CHECK**

### AI-CHECK

AI-CHECK also termed as trend analysis is a spark-powered data-quality suite which helps us to perform multiple analytical functionalities like Rate Analysis, Timeseries Forecast Analysis & Frequency distribution analysis over the dataset leveraging various M/L algoithms.
Some of the commonly used analysis are mentioned [here](../data-quality/overview.md#ai-check-algorithms)

AI-CHECK contains multiple layers of executions as **measure**, **metric**, **evaluation** and then **reporting**. Each layer requires certain configurations in order to execute rules and generate final report.

- #### Input files required for ai-check

  These pipeline-connectors configuration files are:

  - `providers.yaml` - defines the data provider such as aws, azure or databricks.
  - `sources.yaml` - defines the data sources such as databases and/or files.
  - `dataset.yaml` - defines views on top of the sources to create a flexible dataset.
  - `sinks.yaml` - defines the target destinations to where the results have to be written to.
  - `env.yaml` - key/value pairs that provides context and are used as inputs to replace any placeholders in the config files

  For more details about these connector files, please refer [Pipeline-connectors](../data-quality/overview.md#pipeline-connectors-configuraiton-files)

### CONTENT-CHECK

Content-check provides row level data validations with Spark. These validations are driven by the required configuration files created by users to describe the checks to be performed on the datasets or views.
Content-check helps to enforce structural requirements and validates every row of the input dataset for compliance.

- #### Input files required for content-check

  content-check requires the following config files as input to perform validations:

  - `providers.yaml` - defines the data provider such as aws, azure or databricks.
  - `sources.yaml` - defines the data sources such as databases and/or files.
  - `dataset.yaml` - defines views on top of the sources to create a flexible dataset.
  - `checks.yaml` - defines the actual validation rules to be verified on each of the rows in the input dataset. To know more about various checks, [refer](rules.md)
  - `sinks.yaml` - defines the target destinations to where the results have to be written to.
  - `app.yaml` - defines app level control settings to handle failures based on validation results.
  - `env.yaml` - key/value pairs that provides context and are used as inputs to replace any placeholders in the config files

  For more details on these configuration files, kindly refer [Content-check configurations](../data-quality/overview.md#configuration-files)

## Data-Quality multi-configurability of an Application

Users can configure the same application to run multiple rules and checks on different dataset views.To achieve multi-configurability, UnifAI allows users to create sub-directory under data-quality [folder](#folder-structure) to specify different rules and modify pipeline connectors.
User also needs to modify the data-quality path configured in Application.yaml file under the application folder to capture all the different _config-type_.
User can pass _config_type_ as a parameter while running DQ job and specify which rules and configurations to execute as shown in [command below](#unifai-commands-for-data-quality)

## Assumptions Before Integration

Before integrating Data Quality (DQ) into any application, please ensure the following assumptions are met:

- An application already exists under the UnifAI ecosystem.
- Rules and Config files are generated using the grammar rulebook following DSL guidelines and are available under the required folder structure. You can access the Rule Grammar [here](rules.md).

## Folder Structure

![Folder Structure](../images/data_quality/UnifAI_DQ_Folder_Structure_Template.png)

To set up the necessary folder structure, follow these steps:

1. Under the Application folder, create a structure for the `data_quality` folder, as demonstrated above.
2. Within the _data_quality_ folder, specify the _config_type_ for DQ if you have multiple configurations to run under the same application, e.g., `data_quality/default/ai_check` (here 'default' is the config_type) or `data_quality/ai_check`.
3. Inside the `ai_check/content_check` directory, place your Rules and configurations created using the rulebook grammar and relative configuration files for both **ai_check** and **content_check**.
4. Under the UnifAI application folder, Update the `application.yaml` file with the required DQ path configuration. Kindly refer the `sample-app` configuration for both:

   > **Application.yaml**

   ```
   data_quality:
       default:
           content_check: "data_quality/default/content_check"
           ai_check: "data_quality/default/ai_check"
   ```

   Please ensure that the path mentioned under _check-type_ exists within the _data-quality_ folder. please refer to [configurability](#data-quality-multi-configurability-of-an-application) for more details on DQ multi-configurations on same application.

## UnifAI Commands for Data Quality

We provide the following UnifAI commands to manage Data Quality effectively:

1. To generate the Rules file from [rules.txt](../data-quality/rules.md) and configuration files required for **ai-check** using the UnifAI CLI:

   - Run the following command:
     ` unifai-admin run generate-dvp-rule -r {TXT_RULE_DIRECTORY} -c {CONFIG_FOLDER}`

   `{TXT_RULE_DIRECTORY}` : It specifies the path of the Rules directory containing rule text file.
   `{CONFIG_FOLDER}` : It specifies the path of the parameter file created by user to describe the rule_type(classdistanalysis, rateanalysis etc), rule metadata and other specifications.

2. After generating the Rules and configurations for your application, commit them and publish the application onto UnifAI.

3. To run both _ai_check_ and _content_check_, use the following command format:

   - Run the following command:
     `unifai-admin data-quality run sample-app -c {CHECK_TYPE} {OTHER_ARGS}`

     for example: `unifai-admin data-quality run sample-app -c ai-check client='unifai' version='202208' level='eods'`

     - Ensure that `CHECK_TYPE` is passed as either _ai-check_ or _content-check_, and you can specify `OTHER_ARGS` in the _{key}={value}_ format.

   - `OTHER_ARGS` that can be provided while the run can be configurable through parameters are:

     - **AI-CHECK**

       Some of the arguments are used to build report path as passed in sinks.yaml:

       | OTHER_ARGS  |                      Default Value                      |
       | :---------- | :-----------------------------------------------------: |
       | version     |                         202208                          |
       | level       | unifai(value should match with the Rules sub-directory) |
       | env         |                           dev                           |
       | dataversion |                            1                            |
       | {\*}\_PATH  |  `dbfs:/mnt/azureblobshare/output/{schema}/{name}/{*}`  |

       Arguments specific to the application and Rules applied:

       | OTHER_ARGS       | Default Value |
       | :--------------- | :-----------: |
       | CALCULATION_NAME |      NaN      |
       | APP_NAME         |      NaN      |
       | ORCHESTRATION_ID |      NaN      |
       | config_type      |    default    |

     - **CONTENT-CHECK** :

       | OTHER_ARGS  |                                                    Default Value                                                    |
       | :---------- | :-----------------------------------------------------------------------------------------------------------------: |
       | OUTPUT_PATH | `dbfs:/mnt/azureblobshare/output/{schema}/{name}/{orchestration_id}/f"/{datetime.now().strftime('%Y%m%d_%H%M%S')}"` |

## Common DAG for DataQuality

There are common DAGs created for each AI-Check and Content-Check as a wrpper on top of the CLI command which takes similar parameter and executes the tasks on airflow. These DAGs are integrated with other models to allow users to run the DQ jobs during scoring.
![DQ Sample DAG](../images/data_quality/DQ_DAG.png)
Similarly, we have another DAG for AI-check.
Below Parameter can be provided to the DAG:

```
{
    "app_name": "unifai_readmissions_model",
    "connection_id": "unifai_prod_connection",
    "email": "",
    "orchestration_id": "",
    "parent_id": ""
}
```

Note: multiple email addresses can be specified as email params separated with comma.

## Managing Metadata

After a successful run, users can view the details of the run and the output of the checks applied under UnifAI Data Quality tables.
Common DQ tables are:

- `unifai_core_data_quality_runs` : Specifies the orchestration related details of any DQ job triggered.
- `unifai_core_data_quality_results` : Specifies the run status of the DQ execution for each layer and views. The same detailed file is shared as an attachement in the alert mail. [File](../data-quality/DQ%20sample%20outputs/unifai_core_data_quality_results.csv)

* AI-CHECK specific Tables -
  - `unifai_core_data_quality_ai_check_summary` : Contains summarized details specific to ai-check run like : No. of checks ran, passed, failed, fail percentage etc
  - `unifai_core_data_quality_ai_check_failed_check` : Contains details like confidence score, entity type etc of the checks which failed
* CONTENT-CHECK specific Tables -
  - `unifai_core_data_quality_content_check_summary` : Contains summarized details specific to content-check run like : check name, actual_rows, bad rows, eligible_rows clean rows etc. The same detailed file is shared as an attachement in the alert mail. [File](../data-quality/DQ%20sample%20outputs/unifai_core_data_quality_content_check_summary.csv)
  - `unifai_core_data_quality_content_check_bad_records` : Describes the error code, failer resons, severity of the checks failed.
  - `unifai_core_data_quality_content_check_dataset_summary` : Contains summarized details specific to content-check run like : view name, status, bad rows percentage etc. The detailed file is shared as an attachment in the alert mail. [File](../data-quality//DQ%20sample%20outputs/unifai_core_data_quality_content_check_dataset_summary.csv)

## Notification Alerts

A separate email component has been integrated with the DataQuality DAG where users can provide their email address to receive the status of the run. The email body contains description of the run including the configuration and orchestration id of the run. It also has attachemets that contains detailed informations of checks run, status and error reasons.
![email alert](../images/data_quality/DQ_email_alert.png)

## New Connection in Airflow

When a new connection is added in Airflow to trigger data quality, please add http_path to the Extra args of the Airflow connection properties. This is required to query data quality metadata and results from delta tables and send out summary report email.

`http_path value can be found under Databricks warehouse - Connection details.`

## Historical Measure Results for Trend Check Rules

For few Trend Check rules like ClassDist or Timeseries, at least one historical Data Quality measure result is required as a comparison data to find the trend or pattern.

For those types of rules, the first run of Data Quality Trend Check would fail in metrics layer just producing measure results with the ERROR- NO COMPARISON DATA. The second run would use first run's measure results and calculates the required metrics.

## References

For additional information, please refer to the following resources:

- **Content Checks**: [Chimera](https://dataatscale.optum.com/capability/chimera/what-is-chimera/)
- **DVP**: [DVP Documentation](https://dvpdocs.optum.com)
- **AI Trend Checks**: [AI-Check Types](https://dvpdocs.optum.com/capability/ai_trendchecks/AI_trendchecks.html)
