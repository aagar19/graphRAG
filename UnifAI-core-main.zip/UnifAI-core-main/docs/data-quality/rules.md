# Adding Data Quality Rules to UnifAI app

## Overview:

There are 2 kind of rules which can be created within unifai-core app.

1. Content Check Rules - These are logical rules written in simple SQL-like DSL which could be run on given data version which objectively evaluate conditions to true or false. This helps in checking data compatibility, data formats, integrity checks, aggregations, simple conditional checks and user-defined checks. For more details, refer to Chimera checks documentation here -

- [Chimera Checks](https://dataatscale.optum.com/capability/chimera/how-to-guides/checks/)
- [Chimera DSL](https://dataatscale.optum.com/capability/chimera/how-to-guides/dsl/)

2. AI Check/Trend Check Rules - These are trend analysis checks which could help in figuring out any deviation in trend across different versions of data. There are different algorithms run to validate the trend and if there's any deviation those rules will be shown as anamoly in the results. For more details, refer to DVP documentation here -

- [DVP Rule Generator](https://github.com/OptumInsight-Analytics/dvp_rule_generator)

> Note: Both content check and AI check rules use
> [pipeline-connectors](https://github.com/optuminsight-payer/pipeline-connectors),
> an internal tool to connect to different data sources like blob, s3,
> delta, jdbc and other file systems. In addition to checks files, we
> require pipeline-connectors configuration files for fetching data in
> both content check and AI check.

## AI Check Rules:

AI Check rules are different from content check rules and the process include:

1. Writing Rule Grammar for the business case
2. Generating Rules from Grammar using unifai-core command
3. Pushing them to the app repo.

In addition to Rule Grammar, one can configure different values for partitions, temp_table, computed_column, user_defined_functions, rule_descriptions, report_filter, and core_rules.

### Writing Rule Grammar for the business case:

There are different algorithms to check trends and anomalies in DVP.

1. Rate Analysis
2. Frequency Distribution
3. Time series Distribution
4. Numerical Distribution

One need to know how to fit the business case with the DVP algorithm. Here's high-level detail on each algorithm with example and grammar.

![Alt text](../images/data_quality/dvp_rules.png)

1. Rate Analysis Grammar:

```
Grammar:

{RULE_NAME}: ASSERT fraction TO BE {STABLE | NOT_HIGH | NOT_LOW} on  {NUMERATOR_MEASUSRE} over {DENOMINATOR_MEASUSRE}

Example:

RATE_DS_PATIENT_ID of INACTIVE_FLAG: ASSERT fraction TO BE STABLE on COUNT_NOT_NULL  of  PATIENT_SUMMARY where  INACTIVE_FLAG = ‘Y’  over COUNT_NOT_NULL  of PATIENT_SUMMARY
```

2. Frequency Distribution Grammar:

```
Grammar:

{RULE_NAME}: ASSERT {classdist | largedist} TO BE {STABLE | NOT_HIGH | NOT_LOW} on  {NUMERATOR_MEASUSRE} over {DENOMINATOR_MEASUSRE}

Example:

LARGEDIST of ClaimPOS: ASSERT largedist TO BE STABLE on COUNT_NOT_NULL  of  CLAIM  segment by POS over COUNT_NOT_NULL  of CLAIM
```

3. Time-series Distribution Grammar:

```
Grammar:

{RULE_NAME}: ASSERT {timeseries_distribution | mad_qreg} TO BE {STABLE} on  {TIMESERIES_MEASURE}

Example:

INT_TIME_SERIES of INSURANCE_v2: ASSERT timeseries_distribution TO BE STABLE ON  COUNT_NOT_NULL of INSURANCE  where  ENROLLSTARTDT is not null monthly timeseries by INSURANCE.ENROLLSTARTDT with endcolumn  INSURANCE.ENROLLENDDT
```

4. Numerical Distribution:

```
Grammar:

{RULE_NAME}: ASSERT {numdist} TO BE {STABLE} on  {NUMERIC_MEASURE}

Example:

Numdist of L2_II_QL_CONF.PAC_RSNF_READM_DAYS: ASSERT numdist TO BE STABLE ON  PERCENTILE of L2_II_QL_CONF. PAC_RSNF_READM_DAYS where  PAC_RSNF_READMIT=true
```

Note: For more details refer -

- [DVP Grammar](https://github.com/OptumInsight-Analytics/dvp_rule_generator#domain-specific-language--dvp-grammar)

- [AI Trend Checks](https://dvpdocs.optum.com/capability/ai_trendchecks/AI_trendchecks.html)

### Rule Generation in UnifAI:

Once we have the rule grammar created as above, we need to add [configuration files](https://github.com/optum-labs/UnifAI-core/tree/main/sample-app/data_quality/default/ai_check/DVP_Rules/Config) and [Rule expression files with rule](https://github.com/optum-labs/UnifAI-core/tree/main/sample-app/data_quality/default/ai_check/DVP_Rules/Rules/sample_app) in this convention -

    /app_folder/data_quality/<config_type>/ai_check/DVP_Rules/Rules/<level>

Rule Expression files (.expr) can be empty {} except for the partition_column.expr and can be configured with different values as required. For partition_column, we expect the table_name with partition_columns, which could be an empty list. Refer to the above folders in hyperlinks. For instance,

#### partition_column.expr:

```
{
  "ADMITS": []
}
```

Here,

- **config_type** could be default, cohort, or feature where we could have different rules and configurations for each stage.

- **level** could be pipeline name. For instance eods, datapipeline, dailypipeline.

In UnifAI, we have integrated this rule generation and also created CLI command to generate them. Add the required files under the model/app in the above folder convention and run the below command.

#### UnifAI CLI command to generate DVP rules:

Run the following command:

`unifai-admin run generate-dvp-rule -r {TXT_RULE_DIRECTORY} -c {CONFIG_FOLDER} `

`{TXT_RULE_DIRECTORY}` : It specifies the path of the Rules directory containing rule text file.

`{CONFIG_FOLDER}` : It specifies the path of the parameter file created by user to describe the rule_type(classdistanalysis, rateanalysis etc), rule metadata and other specifications.

Example:

```
unifai-admin data-quality generate-dvp-rule \
-r /unifai_data_pipeline/data_quality/monthly/ai_check/DVP_Rules/Rules/ \
-c /unifai-oh-data-pipeline/unifai_data_pipeline/data_quality/monthly/ai_check/DVP_Rules/Config
```

Once the above command run gets completed, you would see output folders created under Rules folder - DVP_Rules like this

    /app_folder/data_quality/<config_type>/ai_check/DVP_Rules/output/<level>/default

**Add these rules files and push them to the app repo**.

> Note: Refer to the [Data Quality documentation](../data-quality/overview.md) for more details on running Data Quality CLI commands to run the Data Quality Jobs in UnifAI.
