# UnifAI Retrospectives

### Overview

"Retrospectives" is a workflow type in which a prospective model runs for _N_ months on a given data set; true-outcomes for machine learning models can also be calculated.

Retrospectives simulate scoring outputs (e.g., Risk Band load) and enable model performance evaluation over _N_ months. Suitable for evaluating new models or code changes, on-boarding new entities, or obtaining updated historical data.

### Approach

Airflow v2.4.3's dynamic tasks trigger N prospective model runs, eliminating the need for a separate pipeline. Configuration parameters are classified as either static or dynamic.

#### Example:

For a 3-month retrospective starting from `retro_run_date=2023-10-05`, three instances of the "admissions" pipeline initiate, each with a dynamically set `run_as_of` parameter:

- Month 1: `run_as_of = 2023-08-05`
- Month 2: `run_as_of = 2023-09-05`
- Month 3: `run_as_of = 2023-10-05`

Configuration management occurs via a `retro_months` input parameter in the DAG, enabling on-demand retrospective runs spanning multiple months (3, 6, 12, 24 months).

```{admonition} Note
Note: For many UnifAI models, the retro_run_date is anchored to be the first day of the current month.
```

#### Unique runs in UnifAI

Each run in UnifAI uses an orchestration_id to identify a unique run for that model. Therefore, a 1-1 relationship exists between orchestration_id and the month being run in retrospectives.

#### Data Partition Table

Each retrospective pipeline uses a parent_id to link all orchestration_ids associated with the N prospective runs. This relationship is elaborated in the following table:

| parent_id                            | orchestration_id                     | run_as_of  | run_type      | application_name |
| ------------------------------------ | ------------------------------------ | ---------- | ------------- | ---------------- |
| 4baf8a29-ccc4-4787-a475-4981e7b45a74 | 8dcca691-a918-4475-a3e6-df8bb5cdd5fd | 2023-08-05 | RETROSPECTIVE | admissions       |
| 4baf8a29-ccc4-4787-a475-4981e7b45a74 | 7bc40e88-f492-4ea2-8ec8-c3f1e7b28d37 | 2023-09-05 | RETROSPECTIVE | admissions       |
| 4baf8a29-ccc4-4787-a475-4981e7b45a74 | 3946e50f-9f78-457d-9a4e-9a35d4844fca | 2023-10-05 | RETROSPECTIVE | admissions       |

To query the data in the `unifai_core_model_output_store` after a successful run, retrieve the `orchestration_id` (parent orchestration_id) for
your retrospective run. This id is automatically generated when you click to build the pipeline with configuration:

![retro](../images/retro.png)

```{admonition} Note
For composite DAGs, such as the unifai-scheduled-monthly AND UnifAI retro DAGs which in their pipeline trigger downstream DAGs, the `orchestration_id` parameter in the Airflow Build Configuration is the `orchestration_id` for that run, and the `**parent_id**` for all downstream DAGs.
```

### Code Walk-through

The DAG utilizes dynamic task creation and reads a retro_months parameter to dynamically generate prospective run dates. These are used to configure the downstream prospective runs.

```python
# Setup and common tasks here, omitted for brevity
def prospective_run_dates(**context):
    # Generate run dates based on retro_months input and retro_run_data anchor input
    return retro_months_list

@task(max_active_tis_per_dag=6)
def trigger_prospectives(run_date: str, **context):
    # Define static configuration parameters
    static_conf = {
        'connection_id': context['dag_run'].conf['connection_id'],
        'model_version': context['dag_run'].conf['model_version'],
        'parent_id': context['dag_run'].conf['orchestration_id'],
        'run_type': context['dag_run'].conf['run_type'],
        'input_schema': context['dag_run'].conf['input_schema'],
        'skip_publish': True  # Downstream DAG specific static params
    }

    # Define dynamic configuration parameters
    dynamic_conf = {
        "run_as_of": run_date,
    }

    # Merge static and dynamic configurations
    conf = {**static_conf, **dynamic_conf}

    # Trigger the prospective run
    trigger_dag_operator = TriggerDagRunOperator(
        task_id=f"Month_{run_date.replace('-', '_')}",
        trigger_dag_id=PROSPECTIVE_DAG_ID,
        conf=conf,
        wait_for_completion=True)

    trigger_dag_operator.execute(context=context)

# Linking tasks
setup >> publish >> trigger_prospectives.expand(run_date=prospective_run_dates())

```

This DAG allows users to run an N month retrospective on-demand by leveraging Airflow dynamic tasks. The **_N_** downstream prospective instances will run in parallel on Databricks on **job clusters**.

```{admonition} Note
The `trigger_prospectives` task is annotated with `@task(max_active_tis_per_dag=6)`. This implies that if a 12-month retro is run, only 6 downstream DAG trigger tasks may be active at once.
```

### Data Partitioning for Prospective Runs

Data is partitioned using an orchestration_id, allowing for parallel execution of N prospective model runs. Since read and write operations are isolated to the specific orchestration_id, conflicts are avoided.

### Querying Retrospective Output

To query retrospective data, use the `parent_id` to retrieve all the data in the `unifai_core_model_output_store` table associated with that retrospective run. The following query can be executed:

```sql
SELECT * FROM <your_databricks_schema>.unifai_core_model_output_store
WHERE orchestration_id IN (SELECT id FROM <your_databricks_schema>.unifai_core_orchestration WHERE parent_id = '4bdbed0a-aa30-4992-8401-71b7f51d9115');
```

Alternatively, the `pyspark` library can be used:

```python
# Load DataFrames
output_df = spark.read.table("<your_databricks_schema>.unifai_core_model_output_store")
orchestration_df = spark.read.table("<your_databricks_schema>.unifai_core_orchestration")

# Filter and join
result_df = output_df.join(
    orchestration_df.filter(orchestration_df.parent_id == '4bdbed0a-aa30-4992-8401-71b7f51d9115').select("id"),
    output_df.orchestration_id == orchestration_df.id
)
# Show result
result_df.show()
```

## Common Retro DAG

A common retrospective DAG has been set up that is designed to initiate retrospectives for various models. This particular DAG takes into account a range of input parameters, which are all boolean in nature. These parameters include options to enable or disable certain features or functionalities, such as the ability to trigger specific models or to filter results based on certain criteria. By leveraging this DAG, it is possible to streamline the process of conducting retrospectives across multiple models, while also ensuring consistency and accuracy in the results obtained.

```python
# from unifai-common-retro DAG
# retro run flags for models
"run_model1": True,
"run_model2": True,
"run_model3": True,
"run_model4": True,
"run_model5": True,
"run_model6": True,
"run_model7": True,
"run_model8": True,
"run_model9": True,
"run_model10": True
```

The existing DAG can be easily customized to add or remove models, providing flexibility to run any combination of models for retrospective analysis. To achieve this, a `MODEL_MAPPING` dictionary is maintained for all the models with relevant configurations such as DAG ID and other dynamic configurations. The common Retro DAG accesses this dictionary and determines whether a retrospective analysis needs to be triggered or not based on the `run_{model_name}` parameter from the DAG. This approach provides a scalable and efficient way to manage retrospective analysis for multiple models.

```{admonition} Note
To ensure that a retrospective is successfully triggered, it is important to follow a specific naming convention for the parameter name in the DAG. The convention is to use "run_{model_name}" format, where {model_name} is the name of the model. Additionally, the MODEL_MAPPING dictionary must contain a corresponding key with the same {model_name}. By following this convention and ensuring that the dictionary is properly configured, user can successfully trigger a retrospective.
```

```python
# from unifai-common-retro DAG
MODEL_MAPPING = { "model1" : { "dag_id" : "model1_retro_dag"},
                  "model2" : { "dag_id" : "model2_retro_dag"},
                  "model3" : { "dag_id" : "model3_retro_dag"},
                  "model4" : { "dag_id" : "model4_retro_dag"},
                  "model5" : { "dag_id" : "model5_retro_dag", "disease": "hf"},
                  "model6" : { "dag_id" : "model6_retro_dag", "disease": "copd"},
                  "model7" : { "dag_id" : "model7_retro_dag"},
                  "model8" : { "dag_id" : "model8_retro_dag"},
                  "model9" : { "dag_id" : "model9_retro_dag"},
                  "model10" : { "dag_id" : "model10_retro_dag"}}
def should_retro_run(**context):
        # get list of model names for which retro has to be triggered based off of run_{model_name} boolean values
        dag_run = context["dag_run"]
        retro_model_list = []
        for model in MODEL_MAPPING.keys():
            if str(dag_run.conf.get(f"run_{model}", False)).lower() == "true":
                retro_model_list.append(model)
        return retro_model_list
```

The function mentioned above is responsible for generating a list of models that require retrospective triggering. This list is then used to create dynamic tasks that are based on an approach that is similar to the one outlined in the code walk-through that can be found [here](#code-walk-through). To achieve the goal of triggering the downstream retrospective DAG dynamically, the DAG leverages the expand function on the `retro_model_list` that is generated by the above function. The DAG would be triggered in the following order:

```python
# from unifai-common-retro DAG
 # DAG Sequence
    setup >> start_email >> create_model_task_group.expand(
        retro_model_to_trigger=RETRO_MODEL_LIST) >> scoring_aggregator >> finish_email >> end
```

#### Scoring aggregator

During the retrospective process, it is crucial to aggregate all retrospective scores written into the output store. This is where the common Retrospective DAG comes in handy. It not only gathers all the scores but also writes them into Snowflake for further analysis. To ensure the Retrospective aggregator DAG works effectively, it requires specific inputs as described below.

```python
# from unifai-retro-aggregator DAG
params={
            "connection_id": "unifai_prod_connection",
            "model_version": "--branch common_retro_aggregator",
            "retro_run_date": f"{datetime.today().date()}",
            "run_type": "RETROSPECTIVE",
            # retro run flags for models
            "retro_model_list": [],
            # commercial retro flag
            "run_commercial": False,
            # "lob_list": [],
            # "cdo_list": [],
            # other job parameters
            "skip_data_quality": True,
            "skip_publish": False,
            "unifai_table_name": "oea_retro_scores_batch",
            "environment": "prd",
            "snowflake_table_name": "MONTHLY_MODEL_RETRO_SCORES_DELIVERY_UAIS",
            "write_snowflake": False,
        }
```

It obtains the `retro_model_list` from the common retro DAG in the following manner:

```python
# from unifai-common-retro DAG
RETRO_MODEL_LIST = should_retro_run()

    MODEL_CONFIG = {
            "connection_id": "{{ ti.xcom_pull('setup')['connection_id'] }}",
            "parent_id": "{{ ti.xcom_pull('setup')['orchestration_id'] }}",
            "retro_run_date": "{{ ti.xcom_pull('setup')['retro_run_date'] }}",
            "run_type": "{{ ti.xcom_pull('setup')['run_type'] }}",
            "model_version": "--branch common_retro_aggregator",
            "input_schema": "{{ ti.xcom_pull('setup')['input_schema'] }}",
            "snowflake_schema_name": "{{ ti.xcom_pull('setup')['snowflake_schema_name'] }}",
            "config_type": "{{ ti.xcom_pull('setup')['config_type'] }}",
            "retro_model_list": RETRO_MODEL_LIST,
            # commercial retro flag
            "run_commercial": "{{ ti.xcom_pull('setup')['run_commercial'] }}",
    }
    scoring_aggregator_conf = {
        **MODEL_CONFIG,
        **{
            "dag_id": "unifai-retro-aggregator",
            "environment": "{{ ti.xcom_pull('setup')['environment'] }}",
            "input_schema": "{{ ti.xcom_pull('setup')['input_schema'] }}",
            "write_snowflake": "{{ ti.xcom_pull('setup')['write_snowflake'] }}",
            "unifai_table_name": "{{ ti.xcom_pull('setup')['unifai_table_name'] }}",
            "snowflake_table_name": "{{ ti.xcom_pull('setup')['snowflake_table_name'] }}",
        }
    }
    scoring_aggregator = create_trigger_operator("unifai-retro-aggregator", scoring_aggregator_conf)
```

One of the key components of this DAG is the parent ID that it passes downstream to the retrospective DAG and eventually the prospective DAG. This parent ID serves as a reference for data aggregation, which is done through an aggregator step. During this step, the `retro_model_list` is looped over to extract data from the output store, which is then aggregated into a common Spark dataframe.

Once the loop execution is complete, the aggregated retrospective data of the chosen models is written back into a Delta Lake table, which is specified by the parameter `unifai_table_name`. It is worth noting that the `unifai_table_name` follows a fixed schema. Therefore, when writing data into it, an important parameter called `update_to_match_schema=True` is used. This parameter ensures that NULL values are embedded for the models that were not run by the common retrospective DAG.

```python
# SCORE_COLUMNS is a dictionary that holds the scoring column mapping for all models
SCORE_COLUMNS = { "model1_model" : {"model1_score" : "MODEL1_SCORE",
                                    "model1_category": "MODEL1_CATEGORY"}}

EXTRA_COLS = {
    'ANCHOR_MOYR': 'CAST(DATE_FORMAT(run_as_of, "yyyyMM") AS STRING)',
}
aggregate_df = None
for model_name in retro_model_list:
    model_name = model_name.strip()
    print(f"Model name: '{model_name}'")
    # Load data from output store based on the parent_id for that model
    output_df = self.load_from_output_store(calc_column_mappings=SCORE_COLUMNS[f"{model_name}_model"],
                                            unifai_extra_col_exprs=EXTRA_COLS)
    # Join retro data
    print(f"Joining retro results for model: '{model_name}' to oea_retro_scores_batch aggregate dataframe.")
    if aggregate_df is not None:
        aggregate_df = aggregate_df.join(output_df, ["UNIQ_MBR_ID", "ENTY_ID", "ANCHOR_MOYR"], "fullouter")
    else:
        aggregate_df = output_df

print(f"----- Final output schema: -----")
aggregate_df.printSchema()
# Write retro data to corresponding model retro delta table
print("----- Writing final file to delta table -----")
self.write_table(spark, aggregate_df, unifai_table_name, update_to_match_schema=True)
print("\n--- Completed writing file to delta table ----\n")
```

If the `write_snowflake` parameter is set to True in the common retrospective DAG, then the data will be published into Snowflake. To determine which table to write the data into, it makes use of the `snowflake_table_name` parameter. Additionally, the `environment` parameter is used to determine which Snowflake environment to write the data into.

After determining where to write the data, the next step is to read the data written in the previous step. This is done by first reading it into `unifai_table_name` and then into `snowflake_table_name`. This ensures that the data is properly transferred from the previous step to the Snowflake database.

The retro aggregator would execute the DAG in the following sequence:

```python
 setup >> do_publish >> publish >> retro_aggregator >> do_write_to_snowflake >> write_to_snowflake >> end
```
