# Releases

## Introduction

This document provides release notes and a checklist for developers releasing a new version of UnifAI-core. Upgrading UnifAI-core is required to enable new features and fixes in Databricks environments or CLI commands. Instructions for local and Airflow upgrades are provided.

UnifAI-core requires version upgrades for two main scenarios:

1. To enable new features in Databricks (e.g., updated schemas, workflows, bug fixes).
2. To enable new CLI features, either locally via [homebrew-UnifAI-core](https://github.com/optum-labs/homebrew-UnifAI-core) or on the Airflow server via [unifai-oea-airflow]().

## Release Workflow

Follow this outline for a full UnifAI-core release:

![workflow](../images/workflow.png)

```{admonition} Note
- Use the `main` branch and Airflow sandbox as a staging environment for testing.
- Upon successful deployment, update the homebrew-UnifAI-core tag version and notify the development team.
```

## Release Checklist

When creating a [pull request](https://github.com/optum-labs/UnifAI-core/pulls) into the [main](https://github.com/optum-labs/UnifAI-core) branch, follow these steps:

#### Step 1: Merge into `main`

- Base your branch off the [main](https://github.com/optum-labs/UnifAI-core) branch and create a PR for merging.
- Merge upon approval.

#### Step 2: Test on Airflow Sandbox

- Notify the team and [trigger Jenkins](https://iqs-collections-jenkins.optum.com/view/all/job/OptumHealth/job/engineering/job/Airflow/job/sandbox/) for redeployment.
- Test and patch if necessary.

```{admonition} Note
Testing the new UnifAI-core version on the Airflow server should include:
1. Validating unifai-bootstrap DAG works as expected if changes to UnifAI-core code impacts the bootstrap logic
2. Validating UnifAI publish DAG operations
3. Validating UnifAI job run DAG operations (for example, trigger unifai-admissions-model and unifai-admissions-retro
and validate end-to-end success
```

#### Step 3: Create Release Tag

- If you haven't already, make sure to update the `version` field in the [pyproject.toml](../pyproject.toml) file to
  the appropriate version tag you plan to release in the next step.
- Create and [tag a release](https://github.com/optum-labs/UnifAI-core/releases/new).
- Add notes following [previous conventions](https://github.com/optum-labs/UnifAI-core/releases).

#### Step 4: Deploy to Airflow Production

- Create a PR on [unifai-oea-airflow](https://github.com/optum-labs/unifai-oea-airflow) and update the tagged version [here](https://github.com/optum-labs/unifai-oea-airflow/blob/master/Jenkinsfile#L53).
- Notify the team and merge upon approval, automatically triggering [this Jenkins job](https://iqs-collections-jenkins.optum.com/view/all/job/OptumHealth/job/engineering/job/Airflow/job/master/).
- Merge at these times to avoid blocking scheduled production runs:
  - IST/GMT+1: 11:00
  - IST: 16:30
  - ET: 06:00
  - CT: 05:00

#### Step 5: Upgrade homebrew-UnifAI-core

- Create and merge a PR on [homebrew-UnifAI-core](https://github.com/optum-labs/homebrew-UnifAI-core/blob/main/) repository
  which will update the tagged version of UnifAI-core.
  - If a major version upgrade has taken place (i.e ` 0.4.0 > 0.3.11`) then a new file `unifai-admin@0.4.rb`
    should be created.
  - If it is a minor upgrade, then the current major version file's UNIFAI_VERSION variable should be updated.
    This can be done [here](https://github.com/optum-labs/homebrew-UnifAI-core/blob/main/unifai-admin%400.3.rb#L6) for example.

#### Step 6: Email Confirmation

- Email the team about the upgrade on sandbox and production servers, as well as homebrew upgrade.

## Upgrade UnifAI Databricks environment

Upgrade an existing Databricks UnifAI environment using:

1. The unifai-bootstrap DAG on both Airflow production and sandbox servers.
2. The UnifAI-CLI.

```{admonition} Note
One should endeavour to keep their UnifAI CLI version synced with the version of UnifAI-core running on their Databricks
UnifAI environment
```

### Using the unifai-bootstrap DAG (recommended for sandbox and production upgrades)

Assuming Step 4 in the release checklist is complete, the UnifAI CLI on both the sandbox and production servers
should be the latest. This in all likelihood means the version of your Databricks UnifAI environment is out of date.
For example, the UnifAI CLI on both servers could be v0.3.1 and your UnifAI Databricks environment could be v0.3.0.

To keep your UnifAI Databricks environment version in sync with your UnifAI CLI version on both Airflow server, the
following DAG on both servers should be triggered.

1. [unifai-bootstrap](http://oea-airflow-sandbox.optum.com:8080/dags/unifai-bootstrap/grid) DAG on the Airflow sandbox server
2. [unifai-bootstrap](http://oea-airflow.optum.com:8080/home/dags/unifai-bootstrap/grid) DAG on the Airflow production server

These DAGs will, by default, use the `unifai_bootstrap_config` Airflow variable. This variable is manually configured
on both sandbox and production Airflow servers to look like this:

- DEV/SANDBOX - unifai_bootstrap_config

```json
{
  "connection_id": "unifai_sandbox_connection",
  "email": ["<email_list_member_1>@optum.com", "<email_list_member_1>@optum.com", ...],
  "owner": "oh_admin",
  "schedule_interval": null,
  "timezone": "America/Chicago"
}
```

where `unifai_sandbox_connection` is configured by default on Airflow sandbox like so:

![unifai_sandbox_connection on Airflow sandbox server](../images/unifai_dev_bootstrap_config.png)

- PRODUCTION - unifai_bootstrap_config

```json
{
  "connection_id": "unifai_prod_connection",
  "email": ["<email_list_member_1>@optum.com", "<email_list_member_1>@optum.com", ...],
  "owner": "oh_admin",
  "schedule_interval": null,
  "timezone": "America/Chicago"
}
```

where `unifai_prod_connection` is configured by default on Airflow production like so:

![unifai_sandbox_connection on Airflow sandbox server](../images/unifai_prod_bootstrap_config.png)

The `connection_id` is a configurable parameter within the DAG and you can configure it to use your Airflow
Databricks connection_id in order to upgrade your existing UnifAI Databricks environment. The connection_id must follow
the same structure as shown in above screenshots.

```{admonition} Note
You will need Airflow admin access to update the unifai_bootstrap_config variable
```

### Using the CLI

Optionally, you can update an existing UnifAI Databricks environment through the UnifAI CLI.

````{admonition} Note
The ```unifai-bootstrap``` DAG is simply a wrapper around the ```unifai-admin bootstrap``` CLI command
````

Before updating an existing UnifAI Databricks environment through the CLI, you will need to update the version of
UnifAI-core CLI on your local machine. Assuming Step. 5 in the release checklist has been completed, you can do this
through the following commands:

```shell
brew tap optum-labs/unifai-core
brew install unifai-admin@<version_tag>
```

Where `<version_tag>` is the tagged version of UnifAI you wish to install. If a minor upgrade from
`0.3.0 -> 0.3.1` has taken place for example, `<version_tag> = 0.3`. If a major upgrade from `0.3.0 -> 0.4.0`
has taken place for example, `<version_tag> = 0.4`.

After upgrading your local version of the UnifAI CLI, you can configure your default UnifAI environment to target the
UnifAI Databricks environment you wish to target for upgrade through the following command:

```shell
unifai-admin configure
```

You will be prompted for the following parameters:

```shell
Databricks Host (should begin with https://)  []:
Databricks Token :
Schema Name  []:
Shared Cluster  []:
Airflow Host (should begin with http://)  ]:
Airflow User  []:
Airflow Token :
```

These parameters should be configured to target the Databricks environment you wish to upgrade:

Databricks hosts:

1. [DEV](https://adb-3258050529844363.3.azuredatabricks.net/?o=3258050529844363#)
2. [PROD](https://adb-3883715272605643.3.azuredatabricks.net/?o=3883715272605643#)

Airflow hosts:

1. [DEV/Sandbox](http://oea-airflow-sandbox.optum.com:8080/home)
2. [PROD](http://oea-airflow.optum.com:8080/home)

Where the `schema` parameter should be the name of the UnifAI schema for the UnifAI environment you wish to upgrade,
and `cluster` should be the target cluster to run UnifAI jobs against.

You can then run the following `unifai-admin` command to upgrade your existing UnifAI Databricks environment:

```shell
unifai-admin bootstrap <STORAGE_FOLDER> --restart
```

where `<STORAGE_FOLDER>` is the name of your storage location, or repo, in Databricks.
