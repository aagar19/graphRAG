# Testing

Testing unifai-core is made more complicated due to the need to support multiple versions of the
pyspark API (the unifai-core utilized databricks-connect to interface with a databricks cluster and
the [databricks-connect
documentation](https://docs.microsoft.com/en-us/azure/databricks/dev-tools/databricks-connect#requirements)
notes that users need to install a databricks specific version of the pyspark library and this
library varies based on the versions of the pyspark cluster.) To support this functionality,
unifai-core installs the appropriate version of pyspark and manipulates `sys.path` to ensure its
use.

While it is typical to treat each `pytest` function (i.e. test case) as if it's an independent,
starting with a clean environment, we need to be careful to manage `sys.path` and the creation of
expensive resources such as the installation libraries and databricks clusters.

Unifai-core provides a set of test fixtures to support resource reuse and to ensure that `sys.path`
is correct for any given test.

Include the fixture {func}`tests.conftest.setup_db_10_4` for tests that requires access to a version
10.4 databricks cluster.

## Testing Configuration

Tests that require access a databricks environment require the following environment variables:

```
CI_CD_DATABRICKS_HOST - host to use for test
CI_CD_DATABRICKS_CLUSTER - token for test environment
```

If you are using the {func}`tests.conftest.setup_db_10_4` fixture, this will be handled
automatically. If not, include the `monkeypatch` fixture and the following lines in your test case:

```
monkeypatch.setenv("DATABRICKS_HOST", os.environ["CI_CD_DATABRICKS_HOST"])
monkeypatch.setenv("DATABRICKS_TOKEN", os.environ["CI_CD_DATABRICKS_TOKEN"])
```

## Test Fixtures

```{eval-rst}
.. automodule:: tests.conftest
   :members: base_unifai_home, monkeypatch_session, original_sys_path, setup_db_10_4
```
