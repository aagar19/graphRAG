# Contributor Guide

Here is a list of important resources for contributors:

- [Source Code]
- [Documentation]

[source code]: https://github.com/optum-labs/unifai-core
[documentation]: https://unifai-docs.optum.com/

## How to set up your development environment

You need Python 3.8 or 3.9 (currently only supports these versions due to databricks constraints)
and the following tools:

- [Poetry]
- [Nox]
- [nox-poetry]

Install the package with development requirements:

```console
$ poetry install
```

You can now run an interactive Python session,
or the command-line interface:

```console
$ poetry run python
$ poetry run ipython
$ poetry run unifai-core
```

[poetry]: https://python-poetry.org/
[nox]: https://nox.thea.codes/
[nox-poetry]: https://nox-poetry.readthedocs.io/

## How to test the project

Run the full test suite:

```console
$ nox
```

List the available Nox sessions:

```console
$ nox --list-sessions
```

You can also run a specific Nox session.
For example, invoke the unit test suite like this:

```console
$ nox --session=tests
```

Unit tests are located in the _tests_ directory,
and are written using the [pytest] testing framework.

[pytest]: https://pytest.readthedocs.io/

## How to build static docs site

Run the following to build static html content:

```bash
$ nox -s docs-build
```

Then, to open the static docs-site on your browser:

```bash
cd docs/_build && open index.html
```

## How to submit changes

Open a [pull request] to submit changes to this project.

Your pull request needs to meet the following guidelines for acceptance:

- The Nox test suite must pass without errors and warnings.
- Include unit tests. This project maintains 80% code coverage.
- If your changes add functionality, update the documentation accordingly.

Feel free to submit early, though—we can always iterate on this.

To run linting and code formatting checks before committing your change, you can install
pre-commit as a Git hook by running the following command:

```console
$ nox --session=pre-commit -- install
```

[pull request]: https://github.com/optum-labs/unifai-core/pulls

<!-- github-only -->

[code of conduct]: codeofconduct
