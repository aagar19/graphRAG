# Command Line Interface (CLI)

CLI usage details ...

```{eval-rst}
.. click:: unifai_core.__main__:main
   :prog: unifai-admin
   :nested: full
```
