# Airflow (UI)

To enable the use of UnifAI-core in Airflow, plugins were created which wrap UnifAI-core
CLI commands in Airflow operators. UnifAI engineering team currently supports the development of
the `UnifaiBootstrapOperator`, `UnifaiPublishOperator` and `UnifaiJobRunOperator`. All of these operators can be
used inside Airflow DAGs as individual tasks. These operators "wrap" UnifAI-core CLI commands through extending
Airflow's
[`BashOperator`](https://airflow.apache.org/docs/apache-airflow/stable/howto/operator/bash.html).

Using the above operators we can build DAGs to do, for example:

- On-demand creation/upgrade of a Databricks UnifAI environment.
- Model versioning and publishing across all monthly model in our Databricks UnifAI environment.
- Job execution in Databricks for a published model using input configuration.
- Different combinations of all the above.

## UnifAI/Databricks Airflow connection

To utilize these operators, a connection in Airflow to the Databricks host needs creation.

Creation of connections occurs inside the Airflow UI. Example UnifAI connections should resemble the following:

![retro](../images/connections.png)

```{admonition} Note
Administrator access is necessary for creating Airflow connections. Contact the administrator for new connection creation.
```

Required fields for setting up this Airflow connection are:

```json
{
  "Connection ID": "<connection_name>",
  "Connection Type": "Databricks",
  "Host": "<databricks_host_url>",
  "Schema": "<unifai_schema_name",
  "Login": "",
  "Password": "",
  "Extra": {
    "token": "<databricks_token>",
    "cluster name": "<databricks_cluster_name>",
    "storage folder": "<databricks_storage_folder>"
  }
}
```

Executing the following CLI command locally achieves the same setup:

```bash
$ unifai-admin configure
```

## UnifaiBootstrapOperator

The `UnifaiBootstrapOperator` wraps the following CLI command in an Airflow operator:

```bash
$ unifai-admin bootstrap <starage_folder>
```

The following is the definition for the `UnifaiBootstrapOperator`:

```python
UnifaiBootstrapOperator(
    task_id='unifai-bootstrap',
    conn_id=CONNECTION_ID,
)
```

deliberately omits the git version as a parameter, ensuring UnifAI-core backwards compatibility between the Airflow server and targeted UnifAI Databricks environment. Compatibility does not extend forwards, implying the Airflow server version should match or exceed that of the targeted UnifAI Databricks environment.

## UnifaiPublishOperator

The `UnifaiPublishOperator` wraps the following CLI command in an Airflow operator:

```bash
$ unifai-admin apps publish <github_url> <app_path> --branch <your_branch_name>
```

The following is the definition for the `UnifaiPublishOperator`:

```python
UnifaiAppPublishOperator(
    app_path="unifai_admissions_model",
    github_url="https://github.com/uhg-private/unifai-eods",
    github_version="{{ ti.xcom_pull('setup')['model_version'] }}",
    conn_id=CONNECTION_ID,
    orchestration_id=ORCHESTRATION_ID,
    parent_id=PARENT_ID,
    retries=3
)
```

## UnifaiJobRunOperator

The `UnifaiJobRunOperator` wraps the following CLI command in an Airflow operator:

```bash
$ unifai-admin jobs run <model_name>.<job_name> param1=val1 param2=val2 param3=val3
```

The following is the definition for the `UnifaiPublishOperator`:

```python
UnifaiJobRunOperator(
    task_id="model-scoring",
    job_name="<model_name>.<job_name>",
    conn_id=CONNECTION_ID,
    orchestration_id=ORCHESTRATION_ID,
    parent_id=PARENT_ID,
    run_as_of=RUN_AS_OF,
    run_type=RUN_TYPE,
    trigger_rule=TriggerRule.NONE_FAILED,
    use_shared_cluster=False,
    debug=True,
    # Job Specific Arguments
    param1="{{ ti.xcom_pull('setup')['param1'] }}",
    param2="{{ ti.xcom_pull('setup')['param2'] }}",
    param3="{{ ti.xcom_pull('setup')['param3'] }}",
)
```
