# Running IdentifAI in production

The UnifAI runbook was created to enable the HCE team to trigger UnifAI data, daily, monthly and standalone pipelines. It can be found [here](https://uhgazure.sharepoint.com/:w:/r/teams/UnifAI-EngineeringInternal/Shared%20Documents/Engineering%20%5BInternal%5D/3.%20Team%20documents/Runbook%20for%20IdentifAI%20Production.docx?d=wc4fce261f6794bbf910fd1fbac370e90&csf=1&web=1&e=XbnB6c).
