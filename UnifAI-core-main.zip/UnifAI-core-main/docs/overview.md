# Overview

UnifAI is a Python framework which unifies data science tools such as Databricks, Airflow and MLFlow. This centralized
solution empowers data scientists to deploy, train, version, parameterize and reproduce their AI/ML models seamlessly
through UnifAI CLI commands and the Airflow UI.

The UnifAI framework, through capturing metadata associated with model runs, enables insights in cost reduction in
running and training AI/ML models on Databricks clusters, enhances reporting capabilities through an abstracted and
centralized model output store and improves the speed of development for data scientists creating new AI/ML models.

## Orchestration

Orchestration documentation TBA..

## Computation

Computation documentation TBA..
