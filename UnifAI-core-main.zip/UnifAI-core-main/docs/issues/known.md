# Known non-UnifAI-core Issues

This document addresses known issues encountered by UnifAI users. These issues are unrelated to the UnifAI core and may arise due to infrastructure or data issues. The document is expected to expand over time.

The issues are categorized based on their use-cases and implementations.

## Airflow Job Run

### Application Porting Issues

Airflow DAGs may fail due to the absence of job definitions and configurations. This error generally occurs due to development error during porting the model. Please refer to the guideline for model porting [here](../development/porting.md#how-to-unifai-a-model).

#### Incorrect file issue

The files defined under UnifAI applications are expected to follow a template where job file name and the source file name are same. This helps in loading the configuration for each job respectively.

**Error message:**

```python
RuntimeError: Error: ModuleNotFoundError: No module named 'model_scoring'
```

The DAG triggers all the jobs defined as a task. For the given DAG, an error can occur as stated above if filename defined for the job is not matching with the respective file name in src directory of the given application. Please make sure to follow the defined template while porting the model and creating files.

#### Application publish issue

Once the application is published, the jobs defined under the application are saved with their respective configurations. In the absence of these configurations and job definition under given schema, the execution may fail.

**Error message:**

```python
IndexError: list index out of range
```

The above error can occur due to following reasons:

1. Application is not published successfully in the given workspace.
2. Job does not exist in the published application.

Make sure to follow the guideline while porting the application and publishing.

#### Incorrect Class Definition

Every job YAML file is mapped with the jobClass which holds the execute method to run the model. The name of the jobClass mentioned in the .yaml file should be available in the src folder.

**Error message:**

```python
RuntimeError: Error: AttributeError: module {jobName} has no attribute {Classname}
```

For the given DAG, an error can occur as stated above if job defined in the application tries to import the a class that does not exist in the respective source. Please make sure to use the same classname defined in the source code of given application.

### Connection ID

Airflow DAG uses connection id to connect with other services like Databricks and executes jobs on the selected workspace. There may occur some errors if the `connection id` passed as a parameter in the DAG run does not exist in the given airflow server.

**Error message:**

```python
airflow.exceptions.AirflowNotFoundException: The conn_id 'unifai_prod_commercial2' isn't defined
```

This error can be fixed by creating the connection id under the given airflow server. For detailed troubleshooting, please refer [here](../troubleshooting.md#airflow).

## Databricks Job Run

### Table Not Found

Databricks job run may fail because of the missing source tables in the given workspace.

**Error message:**

```python
RuntimeError: Error: AnalysisException: Table or view not found: {schema Name}.{Table_name}; 'UnresolvedRelation [{schema Name}, {Table_name}], [], false
```

This error may occur at any stage of the model run. Please find the steps to troubleshoot the missing tables failure [here](../troubleshooting.md#table-not-found).

### Column Not Found

Databricks job may fail because of the missing columns.

**Error message:**

```python
RuntimeError: Error: RuntimeError: Unable to process query with error: Column 'ENTY_ID' does not exist.
```

This error may be caused by the missing column in the table schema definition. Please find the steps to troubleshoot [here](../troubleshooting.md#schema-mismatch).

### Column Type Mismatch

Databricks job may fail due to the mismatch in the column format type for the given tables.

**Error message:**

```python
RuntimeError: Error: RuntimeError: Unable to process query with error: Failed to merge fields 'true_label' and 'true_label'. Failed to merge incompatible data types IntegerType and LongType
```

This error can occur for any given table if the column datatype mentioned in the schema.yaml for any application is not correct. Please find the steps to troubleshoot the schema mismatch issues [here](../troubleshooting.md#schema-mismatch).

## Infrastructure

### Library Not Found

Databricks job run may fail because of the failure while installing the required libraries.

**Error message:**

```python
run failed with error message Library installation failed for library due to user error for pypi {package: "xgboost==1.7"}
```

This error occurs when a pinned dependency version is not available in the current runtime. Please find the troubleshoot related to library installation failure [here](../troubleshooting.md#library-installation).

### Mapping Files Missing

There are certain mapping files required to run a model that might not be available in the given workspace or given blobshare path.

**Error message:**

```python
FileNotFoundError: [Errno 2] No such file or directory: {path of the missing mapping file}
```

This error may occur when a given model is missing the required mapping files in the given workspace. The user can manually upload the missing files in the required location.

### Missing Artifacts

There are certain artifacts required for running various applications and features. Users may get errors executing certain jobs if these artifacts are missing in the infrastructure.

**Error message:**

```python
FileNotFoundError: [Errno 2] No such file or directory: {blobshare path of the missing artifacts}
```

This error may occur if artifacts are not downloaded from the server. Please find the troubleshoot step [here](../troubleshooting.md#artifacts) related to missing artifacts in the given workspace.

## Resources

Find the more relevant and updated spreadsheet [here](https://uhgazure.sharepoint.com/:x:/r/teams/UnifAI-EngineeringInternal/Shared%20Documents/Engineering%20%5BInternal%5D/3.%20Team%20documents/UnifAI_non_core_issues-1.xlsx?d=wf7d6cd41c86349bd93237b23fa528877&csf=1&web=1&e=ytgVFc).
