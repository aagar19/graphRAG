# UnifAI Profiles

Unifai-core supports both multiple databricks (and eventually Spark) environments and multiple
versions of (API level) of the environments. To accomplish this, users are required to configure
a _profile_ for the environment before use.

### Configuring a default profile

Users may configure a default profile for UnifAI-core using the following command:

```
$ unifai-admin configure
```

This command will step the user through adding the required information (Databricks HOST and TOKEN, and Airflow server
details) and store the result as the default environment.

The details for the UnifAI-core profile will be stored in the `~/.unifai/unifai-config.json` file:

```{code-block} json
{
  "default" : {
    "DATABRICKS_HOST": "<databricks workspace URL>",
    "DATABRICKS_TOKEN": "<environment access token>",
    "SCHEMA_NAME": "<name of schema to use>",
    "DEFAULT_CLUSTER": "<cluster name>",
    "AIRFLOW_HOST": <airflow host for databricks workspace>,
    "AIRFLOW_USER": <airflow user username>,
    "AIRFLOW_TOKEN": <airflow custom api token key>
  }
}
```

The file automatically generates upon the first configuration of a default UnifAI-core profile.

### Configuring custom profiles

Users may configure a multiple custom profiles for UnifAI-core, by adding either the `-p` or `--profile` flag
to the configure command:

```
$ unifai-admin -p <profile_name> configure
```

This allows users to create multiple profiles for UnifAI-core. This is useful, for example, if one uses different Databricks
and Airflow hosts for development and production environments. By configuring multiple environments, a users profile
may look like this:

```{code-block} json
{
  "default" : {
    "DATABRICKS_HOST": "<databricks workspace URL>",
    "DATABRICKS_TOKEN": "<environment access token>",
    "SCHEMA_NAME": "<name of schema to use>",
    "DEFAULT_CLUSTER": "<cluster name>",
    "AIRFLOW_HOST": <airflow host for databricks workspace>,
    "AIRFLOW_USER": <airflow user username>,
    "AIRFLOW_TOKEN": <airflow custom api token key>
  },
  "prod" : {
    "DATABRICKS_HOST": "<databricks workspace URL>",
    "DATABRICKS_TOKEN": "<environment access token>",
    "SCHEMA_NAME": "<name of schema to use>",
    "DEFAULT_CLUSTER": "<cluster name>",
    "AIRFLOW_HOST": <airflow host for databricks workspace>,
    "AIRFLOW_USER": <airflow user username>,
    "AIRFLOW_TOKEN": <airflow custom api token key>
  },
  "dev" : {
    "DATABRICKS_HOST": "<databricks workspace URL>",
    "DATABRICKS_TOKEN": "<environment access token>",
    "SCHEMA_NAME": "<name of schema to use>",
    "DEFAULT_CLUSTER": "<cluster name>",
    "AIRFLOW_HOST": <airflow host for databricks workspace>,
    "AIRFLOW_USER": <airflow user username>,
    "AIRFLOW_TOKEN": <airflow custom api token key>
  }
}
```

The user may now use this profile whenever they run UnifAI CLI commands by appending the `-p` or `--profile`
flag before the subsequent command. For example, if a user wishes to run a model job in a dev environment, they may
run:

```
$ unifai-admin -p dev jobs run chronicity_model.model_scoring
```

Or, bootstrap a UnifAI environment in the production Databricks workspace:

```
$ unifai-admin -p prod bootstrap john.doe@optum.com
```
