"""Module to provide scoring functionality."""

import pickle  # noqa: S403
from pprint import pprint

from pyspark.sql import SparkSession


# Create Spark session
spark = SparkSession.builder.appName("sample-app").getOrCreate()


def main(configs, dataio):
    """Main function to perform scoring based on the provided configurations and dataio object."""
    data_path = configs["fpaths"]["subdir"]
    # Load data from file paths
    data_path1 = data_path["table1"]
    data_path2 = data_path["table2"]
    data_path3 = data_path["table3"]
    df1 = dataio.read.csv(data_path1)
    df2 = dataio.read.csv(data_path2)
    df3 = dataio.read.csv(data_path3)

    # Perform transformations on each dataframe
    df1_transformed = df1.select("column1", "column2")
    df2_transformed = df2.select("column3", "column4")
    df3_transformed = df3.select("column5", "column6")

    # Combine the dataframes
    combined_df = df1_transformed.join(df2_transformed, on="join_column", how="inner")
    combined_df = combined_df.join(df3_transformed, on="join_column", how="inner")

    training_flag = configs["training"]
    if training_flag:
        # Perform training process
        trained_model = train_model(combined_df)
        # Save the trained model
        with open(f'{configs["fpaths"]["pipeline"]["model_path"]}/model.pkl', "wb") as file:
            pickle.dump(trained_model, file)
    else:
        # Load the pre-trained model
        with open(f'{configs["fpaths"]["pipeline"]["model_path"]}/model.pkl', "rb") as file:
            model = dataio.model.load_pickle(file)

        # Score the combined data
        result = model.predict(combined_df)

        # Write the output to another location
        output_path = configs["fpaths"]["pipeline"]["scoring_files"]
        dataio(result).to_csv(output_path + "scores.csv", mode="overwrite", header=True)


if __name__ == "main":
    import argparse
    import os
    import sys

    import yaml
    from deepmerge import always_merger

    def parse_arguments():
        """Read arguments from the command line."""
        parser = argparse.ArgumentParser(description="Mortality Args")
        parser.add_argument(
            "-p",
            "--pipeline_path",
            default="/mnt/azureblobshare/projects/code/test/src/",
            help="Path for pipeline config file",
        )
        args, _ = parser.parse_known_args()
        return args

    args = parse_arguments()

    with open(f"{args.pipeline_path}configs/updated_pipeline_configs.yaml") as f:
        pipeline_configs = yaml.load(f, Loader=yaml.SafeLoader)
        project_configs = pipeline_configs["mortality_configs"]
        configs = always_merger.merge(pipeline_configs, project_configs)
    pprint(configs)

    sys.path.append(os.path.realpath(os.path.join(configs["fpaths"]["pipeline"]["root"], "src")))
    # Set up DataIO
    from common.dataio import DataIO
    from sample_app import train_model

    dataio = DataIO(spark)

    main(configs, dataio)
else:
    from sample_app import train_model
