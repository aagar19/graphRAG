# Frequently Asked Questions (FAQ)

Here are a list of frequently asked questions concerning UnifAI.

###### [How do I get started?](https://unifai-docs.optum.com/)

To get started, please follow the quickstart documentation [here](https://unifai-docs.optum.com/).

###### [What is this project about?](https://unifai-docs.optum.com/overview.html)

To get an overview of what the UnifAI-core project is about, you can review the overview documentation [here](https://unifai-docs.optum.com/overview.html).

###### [How do I 'UnifAI' a model?](https://unifai-docs.optum.com/developement/porting.html)

To get details on how to UnifAI an existing model, please follow the UnifAI how-to documentation [here](https://unifai-docs.optum.com/developement/porting.html).

###### [How does UnifAI run model retrospectives?](https://unifai-docs.optum.com/reference/retros.html)

To get details on how UnifAI-core run retrospectives, please follow the UnifAI retrospective documentation [here](https://unifai-docs.optum.com/reference/retros.html).

###### [What are some known issues with UnifAI?](https://unifai-docs.optum.com/issues.html)

Some known issues of UnifAI-core are detailed [here](https://unifai-docs.optum.com/issues.html).

###### [How do I troubleshoot failures within UnifAI?](https://unifai-docs.optum.com/troubleshooting.html)

To troubleshoot failures in UnifAI-core, please follow the troubleshooting documentation detailed [here](https://unifai-docs.optum.com/troubleshooting.html).

###### [Is there a runbook for running IdentifAI data, daily and monthly models in production?](https://unifai-docs.optum.com/runbook.html)

The runbook for running UnifAI data, daily and monthly models can be found [here](https://unifai-docs.optum.com/runbook.html).

###### [How do I enable data quality for my UnifAI model application?](https://unifai-docs.optum.com/data-quality/overview.html)

To enable data quality in UnifAI-core, please follow the UnifAI Data Quality documentation detailed [here](https://unifai-docs.optum.com/data-quality/overview.html).

###### [How do I add rules for data quality?](https://unifai-docs.optum.com/data-quality/rules.html)

To add new data quality rules to your UnifAI model, please follow the UnifAI Data Quality how-to documentation detailed [here](https://unifai-docs.optum.com/data-quality/rules.html).

###### [How can I contribute to UnifAI-core?](https://unifai-docs.optum.com/contributing.html)

To add contribute to UnifAI-core, please follow the UnifAI contributor guide detailed [here](https://unifai-docs.optum.com/contributing.html).

###### [How do I run tests for UnifAI-core?](https://unifai-docs.optum.com/reference/testing.html)

To run UnifAI-core tests, please follow the UnifAI testing guide detailed [here](https://unifai-docs.optum.com/reference/testing.html).

If you have a question which is not covered above, please reach out to the UnifAI engineering team to have your
question answered and subsequently added to the FAQ section of the docs.
