"""Sphinx configuration."""

import os
import sys


project = "Unifai Core"
author = "Andrew Mosson"
copyright = "2022, Andrew Mosson"
extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx_click",
    "myst_parser",
]
autodoc_typehints = "description"
html_theme = "furo"

# Ensure that system path includes the virtual Environment
# Currently assumes python 3.9
# TODO adjust when we support additional versions of python
try:
    sys.path.insert(0, os.environ["VIRTUAL_ENV"] + "/lib/python3.9/site-packages")
except Exception:
    print("No virtualenv set")

print(sys.path)
