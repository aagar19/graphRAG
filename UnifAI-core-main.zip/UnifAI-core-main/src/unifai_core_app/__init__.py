"""App to store core tables for UnifAI Core."""
