"""Module for unifai-admin CLI."""
