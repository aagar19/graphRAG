"""Main for unifai-admin cli."""

import sys

from click import echo

from unifai_core.__main__ import main


@main.command()
def print_python_path() -> None:
    """Prints Python Path for environment."""
    echo(sys.path)
