"""Misc things for the UnifAI CLI."""

import json
import logging
import os
import re
from subprocess import run  # noqa: S404
from typing import Optional
from typing import Tuple
from uuid import uuid4

from unifai_core.app.conf import ApplicationConfiguration
from unifai_core.app.utils import clean_path
from unifai_core.app.utils import retry_spark_sql
from unifai_core.cli.types import Settings
from unifai_core.utils.merge import deep_merge


REDACTED_STR = "******** (redacted)"

DEFAULT_DATABRICKS_PORT = 15001

JOB_CLUSTER_JSON = """
{{
    "job_cluster_key": "{APP_NAME}-{JOB_NAME}",
    "spark_version": "{CLUSTER_RUNTIME_VERSION}",
    "node_type_id": "{WORKER_NODE_TYPE}",
    "driver_node_type_id": "{CLUSTER_NODE_TYPE}",
    "runtime_engine": "{CLUSTER_RUN_ENGINE}",
    "autoscale": {{
        "min_workers": {CLUSTER_MIN_WORKERS},
        "max_workers": {CLUSTER_MAX_WORKERS}
    }},
    "azure_attributes": {{
        "first_on_demand": 1,
        "availability": "ON_DEMAND_AZURE",
        "spot_bid_max_price": -1
    }},
    "custom_tags": {{
        "UnifAI-Version": "{VERSION}",
        "UnifAI-Application": "{APP_NAME}",
        "UnifAI-Job": "{JOB_NAME}",
        "UnifAI-Git-Hash": "{GIT_HASH}"
    }},
    "spark_conf": {{
        "spark.databricks.delta.preview.enabled": "true",
        "spark.driver.maxResultSize": "16g"
    }}
}}
"""

SHARED_CLUSTER_JSON = """
{{
    "cluster_name": "{CLUSTER_NAME}",
    "spark_version": "{CLUSTER_RUNTIME_VERSION}",
    "node_type_id": "{WORKER_NODE_TYPE}",
    "driver_node_type_id": "{CLUSTER_NODE_TYPE}",
    "runtime_engine": "{CLUSTER_RUN_ENGINE}",
    "autotermination_minutes": 60,
    "data_security_mode": "NONE",
    "autoscale": {{
        "min_workers": {CLUSTER_MIN_WORKERS},
        "max_workers": {CLUSTER_MAX_WORKERS},
        "target_workers": {CLUSTER_MIN_WORKERS}
    }},
    "azure_attributes": {{
        "first_on_demand": 1,
        "availability": "ON_DEMAND_AZURE",
        "spot_bid_max_price": -1
    }},
    "cluster_log_conf": {{
        "dbfs": {{
            "destination": "{FILE_STORE_PATH}"
        }}
    }},
    "custom_tags": {{
        "UnifAI-Version": "{VERSION}"
    }},
    "spark_conf": {{
        "spark.databricks.delta.preview.enabled": "true",
        "spark.driver.maxResultSize": "16g"
    }}
}}
"""


def init_settings(profile: Optional[str] = None) -> Settings:
    """Initializes a 'empty' settings object - with defaults set."""
    profile = "default" if not profile else profile.lower()
    schema_name = f"unifai_{re.sub('[^A-Za-z0-9]+', '_', profile)}"
    settings: Settings = {
        "AIRFLOW_HOST": None,
        "AIRFLOW_USER": None,
        "AIRFLOW_TOKEN": None,
        "DATABRICKS_HOST": None,
        "DATABRICKS_ORG_ID": None,
        "DATABRICKS_PORT": None,
        "DATABRICKS_CLUSTER_ID": None,
        "UNIFAI_HOME": None,
        "DATABRICKS_TOKEN": None,
        "SCHEMA_NAME": schema_name,
        "CLUSTER_NAME": f"{schema_name}_cluster",
        "profile": profile,
        "databricks": True,
        "cluster_config": None,
        "version": None,
    }
    return settings


def get_unifai_home(settings: Settings) -> str:
    """Returns the UNIFAI_HOME directory based on the precedence rules.

    1) UNIFAI_HOME environment variable
    2) User home directory (i.e ~ on POSIX or USERPROFILE or HOMEPATH/HOMEDRIVE on Windows +  .unifai
    3) Current working directory + .unifai
    """
    if settings["UNIFAI_HOME"] is not None:
        return settings["UNIFAI_HOME"]

    try:
        settings["UNIFAI_HOME"] = os.environ["UNIFAI_HOME"]
    except KeyError:
        # try use local unifai config
        path = f"{os.getcwd()}/.unifai"
        if not os.path.exists(path):
            # use global unifai config
            path = f"{os.path.expanduser('~')}/.unifai"
            os.makedirs(path, exist_ok=True)
        # Update and return
        settings["UNIFAI_HOME"] = path
    return f"{settings['UNIFAI_HOME']}"


def get_unifai_config(settings: Settings) -> dict:
    """Returns config for current unifai environment from UNIFAI_HOME/.unifai-config, empyt dict if none.

    Supports the following json format for config file::
        {
            "default": {
                "DATABRICKS_HOST": "https://url.goes.here",
                "DATABRICKS_TOKEN": "token goes here",
                ...
            },
            "another-profile": {
                "DATABRICKS_HOST": "https://url.goes.here",
                "DATABRICKS_TOKEN": "token goes here",
                ...
            }
        }

    Args:
        settings: Settings dictionary

    Returns:
        dict: contains DATABRICKS_HOST and DATABRICKS_TOKEN keys
    """
    path = f"{get_unifai_home(settings)}/unifai-config"
    try:
        with open(path) as f:
            return json.load(f).get(settings["profile"], {})
    except FileNotFoundError:
        logging.debug(f"{path} not found")
    except json.JSONDecodeError:
        logging.debug(f"{path} exists but is not a valid json file")
    return {}


def validate_cluster(
    settings: Settings,
    application: Optional[ApplicationConfiguration] = None,
    restart: bool = False,
) -> dict:
    """Validates the cluster name and returns the cluster ID if valid.

    Args:
        settings: job settings
        application: optional application configuration used (if needed) to create new cluster
        restart: optional force cluster restart

    Returns:
        Returns the cluster dictionary returned by the databricks API.  None if not valid

    Raises:
        ValueError: when cluster not found or is not supported
    """
    # Get or Update Cluster settings based on configuration
    cluster, update_cluster = _get_cluster_details(settings, application)
    cluster_name = settings["CLUSTER_NAME"]
    if application and update_cluster:
        cluster = _update_cluster_details(settings, application, cluster, restart)
    if not cluster:
        raise ValueError(f"Cluster {cluster_name!r} does not exist or couldn't get created/updated successfully")
    elif cluster.get("state") != "RUNNING":
        print(
            f"""
                ***************************  Please Note  ***************************
                    The following steps will take longer to run as the respective
                    Databricks cluster needs to be (re)started:
                        -> {cluster_name}
                *********************************************************************\n"""
        )
    # verify cluster version support
    dbricks_vers = cluster["spark_version"]
    if dbricks_vers.startswith("10.4"):
        settings["version"] = "10.4"
    elif dbricks_vers.startswith("11.3"):
        settings["version"] = "11.3"
    elif dbricks_vers.startswith("12.2"):
        settings["version"] = "12.2"
    else:
        raise ValueError(f"Cluster: {cluster_name!r} with version: {dbricks_vers!r} is not supported")

    settings["cluster_config"] = cluster
    return cluster


def setup_all(profile: Optional[str] = None, upgrade: bool = False) -> Settings:
    """Sets up environment and creates virtual envs if required.

    Deals with environment variable name difference for databricks-connect and databricks-cli
    """
    settings = init_settings(profile)
    get_unifai_home(settings)

    _set_databricks_env(settings)
    if settings["DATABRICKS_HOST"]:
        os.environ["DATABRICKS_HOST"] = settings["DATABRICKS_HOST"]
    else:
        raise KeyError("No DATABRICKS_HOST found")
    if settings["DATABRICKS_TOKEN"]:
        os.environ["DATABRICKS_TOKEN"] = settings["DATABRICKS_TOKEN"]
    else:
        raise KeyError("No DATABRICKS_TOKEN found")
    return settings


def ensure_schema(settings: Settings, create_schema: bool = False) -> str:
    """Ensures that a the appropriate schema is setup."""
    validate_cluster(settings)
    setup_spark_env(settings)
    _ensure_spark_session(settings, create_schema)

    return settings["SCHEMA_NAME"]


def print_success(run_name: str) -> None:
    """Simple logger to report run success."""
    print(f"----- Completed {run_name}: Successfully -----\n")


def setup_spark_env(settings: Settings) -> None:
    """Sets up required config for spark with."""
    org_id_pattern = re.compile(r"adb-(\d+)\.")
    if dbh := settings["DATABRICKS_HOST"]:
        org_id = org_id_pattern.search(dbh)
        if org_id:
            settings["DATABRICKS_ORG_ID"] = org_id[1]
        else:
            raise KeyError(f"Can't find the org_id in {dbh}")
    try:
        if (cc := settings["cluster_config"]) is not None:
            settings["DATABRICKS_CLUSTER_ID"] = cc["cluster_id"]
            settings["DATABRICKS_PORT"] = int(cc["spark_conf"]["spark.databricks.service.port"])
    except KeyError:
        settings["DATABRICKS_PORT"] = DEFAULT_DATABRICKS_PORT


def _ensure_databrick_connect_config() -> None:
    """Ensures ~/.databricks-connect exists - creates and empty JSON file if not found."""
    p = f"{os.path.expanduser('~')}/.databricks-connect"
    try:
        with open(p) as f:
            _ = json.load(f)
    except FileNotFoundError:
        with open(p, "w") as f:
            f.write("{}\n")


def _ensure_spark_session(settings: Settings, create_schema: bool = False) -> None:
    """Ensures the SparkSession is created and configured."""
    assert settings["DATABRICKS_HOST"] is not None  # noqa: S101
    assert settings["DATABRICKS_TOKEN"] is not None  # noqa: S101
    assert settings["DATABRICKS_PORT"] is not None  # noqa: S101
    assert settings["DATABRICKS_CLUSTER_ID"] is not None  # noqa: S101
    assert settings["DATABRICKS_ORG_ID"] is not None  # noqa: S101

    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    spark.conf.set("spark.databricks.service.address", settings["DATABRICKS_HOST"])
    spark.conf.set("spark.databricks.service.token", settings["DATABRICKS_TOKEN"])
    spark.conf.set("spark.databricks.service.clusterId", settings["DATABRICKS_CLUSTER_ID"])
    spark.conf.set("spark.databricks.service.orgId", settings["DATABRICKS_ORG_ID"])
    spark.conf.set("spark.databricks.service.port", str(settings["DATABRICKS_PORT"]))
    spark.conf.set("unifai_core.schema_name", str(settings["SCHEMA_NAME"]))

    try:
        spark.sql(f"USE {settings['SCHEMA_NAME']}")
    except Exception:
        spark.sql(f"CREATE SCHEMA IF NOT EXISTS {settings['SCHEMA_NAME']}")
        spark.sql(f"USE {settings['SCHEMA_NAME']}")


def _get_cluster_details(
    settings: Settings,
    application: Optional[ApplicationConfiguration] = None,
) -> Tuple[Optional[dict], bool]:
    """Get Cluster detaisl from Databricks based on name provided."""
    # Use application cluster name if specified
    cluster_name = settings["CLUSTER_NAME"]
    update_cluster = False
    if application:
        if application.name == "default":
            update_cluster = True
        elif application.use_app_cluster:
            update_cluster = True
            cluster_name = f"{settings['SCHEMA_NAME']}_{re.sub('[^A-Za-z0-9]+', '_', application.name)}_cluster"
    if not cluster_name:
        raise ValueError("No Cluster has not been defined in the settings")
    cmd_out = run(  # noqa: S607,S603
        ["databricks", "clusters", "get", "--cluster-name", cluster_name],
        capture_output=True,
    )
    # Return cluter details
    if cmd_out.returncode == 0:
        settings["CLUSTER_NAME"] = cluster_name
        return json.loads(cmd_out.stdout.decode("utf-8")), update_cluster
    # Cluster not found
    return None, True


def _update_cluster_details(
    settings: Settings, application: ApplicationConfiguration, cluster: Optional[dict] = None, restart: bool = False
) -> Optional[dict]:
    """Update Databricks cluster based on the application configuration."""
    unifai_config = application.get_config()
    upd_cluster = json.loads(
        application.parse_with_config(
            SHARED_CLUSTER_JSON,
            {
                **settings,
                **{
                    "BLOB_STORE_PATH": clean_path(unifai_config["BLOB_STORE_PATH"], "dbfs:"),
                    "FILE_STORE_PATH": clean_path(unifai_config["FILE_STORE_PATH"], "dbfs:"),
                },
            },
        )
    )
    # Merge with existing cluster if applicable
    upd_cluster = upd_cluster if not cluster else deep_merge(cluster, upd_cluster)
    # Add application name tag
    if application.name != "default":
        upd_cluster["custom_tags"]["UnifAI-Application"] = application.name
    # Update INIT script
    if application.script_path:
        upd_cluster["init_scripts"] = [{"workspace": {"destination": clean_path(application.script_path)}}]
    else:
        upd_cluster["init_scripts"] = []
    # Update ENV variables
    if application.env_variables:
        upd_cluster["spark_env_vars"] = application.env_variables
    else:
        upd_cluster["spark_env_vars"] = {}
    # Update SPARK config
    if application.spark_config:
        upd_cluster["spark_conf"] = {**upd_cluster.get("spark_conf", {}), **application.spark_config}
    # Compare JSON to see if ipdate is needed
    if restart or cluster != upd_cluster:
        action = (
            "Creating/Starting" if not cluster else ("Updating/Restarting" if cluster != upd_cluster else "Restarting")
        )
        print(f"{action} Cluster ({upd_cluster['cluster_name']}).\n")
        # Push changes to Databricks
        cmd_out = run(  # noqa: S607,S603
            ["databricks", "clusters", ("edit" if cluster else "create"), "--json", json.dumps(upd_cluster)],
            capture_output=True,
        )
        # Return none if failed to update cluster
        if cmd_out.returncode != 0:
            return None
        # Return updated cluster details
        return _get_cluster_details(settings)[0]
    # No change return loaded cluster
    else:
        return cluster


def _set_databricks_env(settings: Settings) -> None:
    """Calculates the setting that will be used based on the various confurations present."""
    _ensure_databrick_connect_config()
    if settings["DATABRICKS_HOST"] is None or settings["DATABRICKS_TOKEN"] is None:
        unifai_conifg = get_unifai_config(settings)
        _update_databricks_host(settings, unifai_conifg)
        _update_databricks_token(settings, unifai_conifg)
        _update_databricks_schema(settings, unifai_conifg)
        _update_databricks_cluster(settings, unifai_conifg)
        _update_airflow(settings, unifai_conifg)


def _update_airflow(settings: Settings, unifai_conifg: dict) -> None:
    """Update Airflow Settings."""
    if (airflow_host := unifai_conifg.get("AIRFLOW_HOST")) is not None:
        settings["AIRFLOW_HOST"] = airflow_host
    else:
        settings["AIRFLOW_HOST"] = None
    if (airflow_user := unifai_conifg.get("AIRFLOW_USER")) is not None:
        settings["AIRFLOW_USER"] = airflow_user
    else:
        settings["AIRFLOW_USER"] = None
    if (airflow_token := unifai_conifg.get("AIRFLOW_TOKEN")) is not None:
        settings["AIRFLOW_TOKEN"] = airflow_token
    else:
        settings["AIRFLOW_TOKEN"] = None


def _update_databricks_host(settings: Settings, unifai_conifg: dict) -> None:
    """Update Databricks Host."""
    if (env_databricks_host := os.environ.get("DATABRICKS_HOST")) is not None:
        settings["DATABRICKS_HOST"] = env_databricks_host
    elif (config_host := unifai_conifg.get("DATABRICKS_HOST")) is not None:
        settings["DATABRICKS_HOST"] = config_host
    else:
        settings["DATABRICKS_HOST"] = None


def _update_databricks_token(settings: Settings, unifai_conifg: dict) -> None:
    """Update Databricks Token."""
    if (env_databricks_token := os.environ.get("DATABRICKS_TOKEN")) is not None:
        settings["DATABRICKS_TOKEN"] = env_databricks_token
    elif (config_host := unifai_conifg.get("DATABRICKS_TOKEN")) is not None:
        settings["DATABRICKS_TOKEN"] = config_host
    else:
        settings["DATABRICKS_TOKEN"] = None


def _update_databricks_schema(settings: Settings, unifai_conifg: dict) -> None:
    """Update Databricks Schema."""
    if (env_schema_name := os.environ.get("SCHEMA_NAME")) is not None:
        settings["SCHEMA_NAME"] = env_schema_name
    elif (config_schema_name := unifai_conifg.get("SCHEMA_NAME")) is not None:
        settings["SCHEMA_NAME"] = config_schema_name


def _update_databricks_cluster(settings: Settings, unifai_conifg: dict) -> None:
    """Update Databricks Cluster."""
    if (env_cluster_name := os.environ.get("CLUSTER_NAME")) is not None:
        settings["CLUSTER_NAME"] = env_cluster_name
    elif (config_cluster_name := unifai_conifg.get("CLUSTER_NAME")) is not None:
        settings["CLUSTER_NAME"] = config_cluster_name


def _prepare_orchestration_data(
    orchestration_id: Optional[str], orchestration_data: Optional[str]
) -> Tuple[str, Optional[dict]]:
    """Prepare Orchestration Metadata."""
    try:
        orch_data = json.loads(str(orchestration_data))
    except Exception:
        orch_data = None
    orch_id = orchestration_id if isinstance(orchestration_id, str) else str(uuid4())
    return orch_id, orch_data


def insert_into_job_runs(message, app_id=None, job_id=None, config=None, orchestration_id=None, databricks_id=None):
    """Inserts pre-job run errors in the job_run table."""
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    id = str(uuid4())
    if app_id is None:
        app_id = "default"
    if job_id is None:
        job_id = "default"
    if orchestration_id is None:
        orchestration_id = "default"
    if config is None:
        config = {}

    message = str(message).replace("'", "")

    retry_spark_sql(
        spark,
        f"""
            INSERT INTO unifai_core_job_runs (
                id, application_id, job_id, databricks_id, orchestration_id, start_time,
                end_time, run_as_of, run_type, run_user_id, configuration, status, status_message,
                job_hash, unifai_hash, notification_list
            )
            VALUES (
                '{id}', '{app_id}', '{job_id}', '{databricks_id}', '{orchestration_id}', current_timestamp(), current_timestamp(),
                 current_timestamp(), NULL, '{config.get('SYS_USER', '-unknown-')}', '{json.dumps(config)}', 1, '{message}',
                '{config.get('GIT_HASH','NULL')}', '{config.get('VERSION','NULL')}', NULL
            )
            """,
    )
    return id


def get_job_stdout(run_id, metadata=False, error_trace=False):
    """Prints logs/errors/metadata given job run id of the job."""
    try:
        cmd_out = run(  # noqa: S607,S603
            ["databricks", "runs", "get-output", "--version", "2.1", "--run-id", run_id],
            capture_output=True,
        )
        if cmd_out.returncode == 0:
            json_out = json.loads(cmd_out.stdout)
            job_id = json_out.get("metadata", {}).get("job_id", json_out.get("job_id"))
            print("-- JOB ID -- : ", job_id)
            if json_out.get("logs"):
                print("\n---------- ---------- ---------- STDOUT ---------- ---------- ----------")
                print(json_out.get("logs") + "\n")
            if json_out.get("error"):
                print("\n---------- ---------- ---------- STDERR ---------- ---------- ----------")
                print(json_out.get("error") + "\n")
            if metadata:
                if json_out.get("metadata"):
                    print("\n---------- ---------- ---------- METADATA ---------- ---------- ----------")
                    print(json_out.get("metadata") + "\n")
            if error_trace:
                if json_out.get("error"):
                    print("\n---------- ---------- ---------- ERROR TRACE ---------- ---------- ----------")
                    print(json_out.get("error_trace", "") + "\n")

    except Exception as ex:
        print(f"ERROR: Failed to extract the run information: {ex}\n")
