"""Type aliases for UnifAI-core."""

from typing import Optional
from typing import TypedDict


env_keys = [
    "PATH",
    "VIRTUAL_ENV",
    "DATABRICKS_HOST",
    "DATABRICKS_ORG_ID",
    "UNIFAI_HOME",
]
priv_env_keys = ["DATABRICKS_TOKEN"]
# Settings = Dict[str, Optional[Union[str, bool]]]

DATABRICKS_VERSIONS = frozenset(("10.4", "11.3"))


class Settings(TypedDict):
    """Type defination for Settings class."""

    AIRFLOW_HOST: Optional[str]
    AIRFLOW_USER: Optional[str]
    AIRFLOW_TOKEN: Optional[str]
    DATABRICKS_HOST: Optional[str]
    DATABRICKS_ORG_ID: Optional[str]
    DATABRICKS_PORT: Optional[int]
    DATABRICKS_CLUSTER_ID: Optional[str]
    UNIFAI_HOME: Optional[str]
    DATABRICKS_TOKEN: Optional[str]
    SCHEMA_NAME: str
    CLUSTER_NAME: str
    profile: str
    databricks: bool
    cluster_config: Optional[dict]
    version: Optional[str]
