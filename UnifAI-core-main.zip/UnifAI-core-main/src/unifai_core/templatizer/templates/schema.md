# Add output table schemas as required by the model

**As a convention: -**

- put one table in each file

- prefix the table name with the application name
  e.g. admissions_model_some_output_table

- the file name should match the table name [excluding the application name prefix]
  e.g. table name = admissions_model_some_output_table / file name = some_output_table.yaml

- always include two default columns in evey table :-

  - run_id : to associate the data back to the job run

  - run_as_of : for partitioning
