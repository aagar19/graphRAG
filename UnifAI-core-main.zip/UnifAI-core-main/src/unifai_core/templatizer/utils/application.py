"""Module providing utilities for generating application files content.

This module includes functions to build the content of application YAML,
job source files, job YAML configurations, DAG definitions for Airflow, and
schema files based on model definitions.
"""

from unifai_core.templatizer.utils.dag import build_dag
from unifai_core.templatizer.utils.job import build_job_src
from unifai_core.templatizer.utils.job import build_job_yaml
from unifai_core.templatizer.utils.schema import get_schema_names


def get_file_content(model_definitions, repo_dir):
    """Generates the content for various application files.

    Based on the provided model definitions, this function compiles the content
    needed for application YAML, job scripts, job configurations, DAGs, and schema
    files.

    Args:
        model_definitions: A dictionary containing the model definitions.
        repo_dir: The file path to the repository directory.

    Returns:
        A dictionary with keys 'application_yaml', 'jobs', 'dags', 'README', and
        'schema_names', each containing the relevant content for the application files.
    """
    file_content = {}

    # Create application yaml content
    app_yaml = build_app_yaml(model_definitions["application"])
    file_content["application_yaml"] = app_yaml

    # Create job src and yaml content
    file_content["jobs"] = {}
    for job in model_definitions["jobs"]:
        job_src = build_job_src(job, repo_dir)
        job_yaml = build_job_yaml(
            job,
            model_definitions["application"]["overview"]["run_type"],
            databricks_runtime=model_definitions["application"]["environment"]["databricks_runtime_version"],
        )
        file_content["jobs"][job["name"]] = {"src": job_src, "yaml": job_yaml}

    # Create DAG content
    file_content["dags"] = {}
    file_content["dags"]["prospective"] = build_dag(model_definitions)
    file_content["dags"]["retrospective"] = build_dag(model_definitions, is_retrospective=True)

    # Create README
    file_content["README"] = [""]

    # Create schema files
    file_content["schema_names"] = get_schema_names(model_definitions["jobs"])

    return file_content


def build_app_yaml(app_dict):
    """Constructs the content for the application YAML file.

    This function creates a dictionary representing the YAML content for an
    application's configuration based on the provided application variables.

    Args:
        app_dict: A dictionary containing the application configuration variables.

    Returns:
        A dictionary representing the application YAML content.
    """
    app_yaml = {
        "name": f"{app_dict['overview']['model_name']}_{app_dict['overview']['model_suffix']}",
        "description": app_dict["overview"]["description"],
        "configuration": app_dict["application_variables"],
        "cluster": {**app_dict["environment"]},
    }
    return app_yaml
