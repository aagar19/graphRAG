"""Module for handling schema names extraction from job definitions."""

import shutil
from pathlib import Path


def get_schema_names(job_definitions):
    """Extracts schema names from job definitions.

    Parses job definitions to identify and collect the names of tables defined
    in the outputs of each job.

    Args:
        job_definitions: A list of dictionaries, each representing a job definition.

    Returns:
        A list of unique strings, each representing a table name defined in the
        job definitions' outputs.
    """
    tables = []
    for job in job_definitions:
        outputs = job["data"]["outputs"]
        for output in outputs:
            if "table" in output:
                tables.append(output["table"])
    return list(set(tables))


def copy_file(destination: str):
    """Copy schema file to destination."""
    # Define source path
    source = Path(__file__).parents[1] / "templates" / "schema.md"

    # Define destination path and parent directory
    parent_dir = Path(destination).parent
    print(parent_dir)

    # Create parent directories if they don't exist
    parent_dir.mkdir(parents=True, exist_ok=True)

    # Copy file
    shutil.copy(source, destination)
