"""Module for building job source files for UnifAI applications.

This module provides functions to dynamically create job source files based on
job definitions from a model's configuration. It supports adding user inputs,
loading data, performing transformations, and writing output within the generated job script.
"""

from importlib import import_module
from inspect import getfullargspec

from unifai_core.templatizer.utils.common import SysPath
from unifai_core.templatizer.utils.common import add_custom_lines
from unifai_core.templatizer.utils.common import load_template
from unifai_core.templatizer.utils.common import split_lines
from unifai_core.templatizer.utils.common import underscore_to_camel_case


INDENT_8 = " " * 8
INDENT_12 = " " * 12
JOB_SRC_FILE_NAME = "job_src.py.txt"


def _add_transform(content, job_defn, repo_dir, infer_variables=True):
    """Adds transformation logic to the job script.

    Args:
        content: Current content of the job script as a list of strings.
        job_defn: Job definition as a dictionary.
        repo_dir: Path to the repository directory.
        infer_variables: Flag to infer argument values automatically.

    Returns:
        Updated content with transformation logic added.
    """
    if infer_variables:
        infer_dict = {
            "infer_arguments": infer_variables,
            "data_inputs": [d["variable"] for d in list(job_defn.get("data", {}).get("inputs", []))],
            "job_inputs": list(job_defn.get("user_inputs", {}).keys()),
            "variable_aliases": job_defn.get("variable_aliases", {}),
        }
    else:
        infer_dict = {"infer_arguments": False}

    transform_lines = []

    for source in job_defn["source_code"]:
        defn_lines = _get_transform_defn(source["import_path"], source["class"], repo_dir, **infer_dict)
        transform_lines.append(f"{INDENT_8}{source['returns']} = {defn_lines[0]}")
        transform_lines.extend(defn_lines[1:])

    content = add_custom_lines(content, f"{INDENT_8}__ADD_TRANSFORM__", transform_lines)
    return content


def _add_data_load(content, job_defn):
    """Adds data loading logic to the job script.

    Args:
        content: Current content of the job script as a list of strings.
        job_defn: Job definition as a dictionary.

    Returns:
        Updated content with data loading logic added.
    """
    data_loads = []

    try:
        for input in job_defn["data"]["inputs"]:
            if "table" in input:
                table = input["table"]
                load_string = f"self.load_table(spark, f'{table}')"
                data_loads.append(f"{INDENT_8}{input['variable']} = {load_string}")
            elif "intermediates_path" in input:
                path = f"str(Path(self.intermediates_path) / '{input['intermediates_path']}')"
                data_loads.append(f"{INDENT_8}{input['variable']} = spark.read.parquet({path})")
            elif "custom" in input:
                data_loads.append(f"{INDENT_8}{input['variable']} = {input['custom']}")
            elif "pickle" in input:
                data_loads.append(f"{INDENT_8}with open({input['pickle']}, 'rb') as f:")
                data_loads.append(f"{INDENT_12}{input['variable']} = pickle.load(f)")
            else:
                # TODO Engg. Add any other data logic that might be useful for users
                data_loads.append(f"{INDENT_12}{input['variable']} = #TODO: Add data load logic here")
    except Exception as e:
        print(f"Error loading job definition from templated YAML file: {e}")

    content = add_custom_lines(content, f"{INDENT_8}__ADD_DATA_LOAD__", data_loads)
    return content


def _add_data_write(content, job_defn):
    """Adds data writing logic to the job script.

    Args:
        content: Current content of the job script as a list of strings.
        job_defn: Job definition as a dictionary.

    Returns:
        Updated content with data writing logic added.
    """
    data_writes = []

    for output in job_defn["data"]["outputs"]:
        if output.get("table") is not None:
            formatted_tablename = "tablename='" + output["table"] + "'"
            data_writes.append(f"{INDENT_8}self.write_table(spark, {output['variable']}, {formatted_tablename})")
        if output.get("intermediates_path") is not None:
            path = f"str(Path(self.intermediates_path) / '{output['intermediates_path']}')"
            data_writes.append(f"{INDENT_8}{output['variable']}.write.parquet({path}, mode='overwrite')")
        if output.get("output_store") is not None:
            output_store_lines = [
                f"{INDENT_8}self.add_multi_bulk_output(",
                f"{INDENT_12}data={output['variable']},",
                f"{INDENT_12}calc_column_mappings={output['output_store']['column_mappings']},",
                f"{INDENT_12}data_link_columns={output['output_store']['data_link_columns']},",
                f"{INDENT_8})",
            ]
            data_writes.extend(output_store_lines)

    content = add_custom_lines(content, f"{INDENT_8}__ADD_DATA_WRITE__", data_writes)
    return content


def _add_imports(content, job_defn):
    """Adds import statements to the job script.

    Args:
        content: Current content of the job script as a list of strings.
        job_defn: Job definition as a dictionary.

    Returns:
        Updated content with import statements added.
    """
    import_lines = job_defn.get("imports", []).copy()
    for source in job_defn["source_code"]:
        import_lines.append(f"from {source['import_path']} import {source['class']}")

    content = add_custom_lines(content, "__ADD_CUSTOM_IMPORTS__", import_lines)

    return content


def _get_transform_defn(
    module_path,
    class_name,
    repo_dir,
    infer_arguments=True,
    data_inputs=None,
    job_inputs=None,
    variable_aliases=None,
):
    """Generates transformation function definition for a job script.

    Args:
        module_path: Path to the module containing the class.
        class_name: Name of the class containing the transformation logic.
        repo_dir: Path to the repository directory.
        infer_arguments: Flag to infer argument values automatically.
        data_inputs: List of data input variable names.
        job_inputs: List of job input variable names.
        variable_aliases: Dictionary mapping variables to their aliases.

    Returns:
        List of strings representing the lines of the transformation function definition.
    """
    # There should be a better way to accomplish this. In this implementation, we get
    # the path of the class, "import" it and then loop through the arguments.
    if infer_arguments:
        data_inputs = data_inputs or []
        job_inputs = job_inputs or []
        variable_aliases = variable_aliases or {}
    try:
        with SysPath(repo_dir):
            source_class = getattr(import_module(module_path), class_name)
            init_args = list(getfullargspec(source_class.__init__))[0]
            init_args = [arg for arg in init_args if arg != "self"]

            transform_args = list(getfullargspec(source_class.transform))[0]
            transform_args = [arg for arg in transform_args if arg != "self"]

    except Exception as ex:  # noqa F841
        init_args = ["ARG"]
        transform_args = []

    # Only class init arguments will be leveraged here. We can enhance this
    # to also include other arguments.
    if any(init_args):
        content = [f"{class_name}("]
        for arg in init_args:
            if infer_arguments:
                if arg in variable_aliases:
                    argument_value = variable_aliases[arg]
                elif arg in data_inputs or arg in job_inputs:
                    argument_value = arg
                else:
                    argument_value = " "
            else:
                argument_value = " "
            content.append(f"{INDENT_12}{arg}={argument_value},")
        content.append(f"{INDENT_8}).transform(")
    else:
        content = [f"{class_name}().transform("]

    if any(transform_args):
        # Infer arguments here as well
        content = content + [f"{INDENT_12}{arg}= ," for arg in transform_args] + [f"{INDENT_8})"]
    else:
        content[-1] = content[-1] + ")"

    return content


def _job_input_args(user_input_dict):
    """Constructs argument list for job inputs.

    Args:
        user_input_dict: Dictionary of user inputs.

    Returns:
        A string representing the arguments for job inputs.
    """
    args = list(user_input_dict.keys()) + ["input_schema", "run_as_of"]
    return ", ".join(args)


def build_job_src(job_defn, repo_dir):
    """Generates the content for a job's source file.

    Args:
        job_defn: Dictionary containing the job definition.
        repo_dir: Path to the repository directory.

    Returns:
        List of strings representing the lines of the job's source file.
    """
    job_template = load_template(JOB_SRC_FILE_NAME)
    # Replace placeholders
    job_string = (
        job_template.replace("{JOB_NAME}", job_defn["name"])
        .replace("{JOB_NAME_CAMEL_CASE}", underscore_to_camel_case(job_defn["name"]))
        .replace("{JOB_INPUTS}", _job_input_args(job_defn["user_inputs"]))
    )
    content = split_lines(job_string)

    # Add imports
    content = _add_imports(content, job_defn)

    # Add data load
    content = _add_data_load(content, job_defn)

    # Add transform
    content = _add_transform(content, job_defn, repo_dir)

    # Add data write
    content = _add_data_write(content, job_defn)

    # Remove pathlib import if not used
    if not any(line for line in content if "(Path(" in line):
        content = [line for line in content if line != "from pathlib import Path"]

    return content


def build_job_yaml(job_defn, run_type, databricks_runtime):
    """Builds the YAML content for a job definition.

    Args:
        job_defn: Dictionary containing the job definition.
        run_type: The run type of the job.
        databricks_runtime: The Databricks runtime version for the job.

    Returns:
        Dictionary representing the YAML content of the job definition.
    """
    job_name = underscore_to_camel_case(job_defn["name"])
    job_yaml = {
        job_defn["name"]: {
            "class": f"{job_name}UnifaiJob",
            "sys_paths": ["{REPO_PATH}"],
            "inputs": {
                **job_defn["user_inputs"],
                "run_as_of": {"type": "string", "required": False, "default": "{SYS_TODAY}"},
                "run_type": {"type": "string", "required": False, "default": run_type.upper()},
                "input_schema": {"type": "string", "required": False, "default": "{SCHEMA}"},
            },
            "cluster": {"runtime_version": databricks_runtime, **job_defn["environment"]},
        }
    }
    if "dependencies" in job_defn:
        job_yaml[job_name.lower()]["dependencies"] = job_defn.get("dependencies")

    return job_yaml
