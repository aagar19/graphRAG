"""Module for interacting with Git repositories in UnifAI applications.

This module provides functionalities for checking Git branch existence, pushing
changes to Git, and generating help instructions for Git operations.
"""

import os
import shlex
from getpass import getuser
from subprocess import run  # noqa: S404


def _get_branch_url(app_dir, branch):
    """Generates the URL for a given branch within a Git repository.

    Args:
        app_dir: Directory within the Git repository.
        branch: Name of the Git branch.

    Returns:
        URL for the given branch within the Git repository.
    """
    repo_url = _run_command("git config --get remote.origin.url", app_dir).stdout.replace(".git", "").strip()
    base_path = _run_command("git rev-parse --show-toplevel", app_dir).stdout.strip()
    app_url = f"{repo_url}/tree/{branch}/{os.path.relpath(app_dir, base_path)}"
    return app_url


def _run_command(command, wd):
    """Executes a shell command in a specific working directory.

    Args:
        command: Shell command to execute.
        wd: Working directory where the command is to be executed.

    Returns:
        CompletedProcess instance representing the execution result.
    """
    out = run(shlex.split(command), capture_output=True, encoding="UTF-8", cwd=wd)  # noqa: S603,S607
    return out


def git_branch_exists(branch, repo_dir):
    """Checks if a given branch exists in the Git repository.

    Args:
        branch: Name of the Git branch.
        repo_dir: Git repository directory.

    Returns:
        True if the branch exists, False otherwise.

    Raises:
        Exception: If an unexpected state is encountered while verifying branch existence.
    """
    verify_out = _run_command(f"git rev-parse --verify {branch}", repo_dir)
    if verify_out.stdout != "":
        return True
    elif verify_out.stderr.startswith("fatal"):
        return False
    else:
        raise Exception(f"Unable to determine whether branch {branch} exists; please verify manually.")


def push_to_git(app_dir, branch=None, app_name=None, commit_message=None):
    """Pushes changes to the Git repository.

    Args:
        app_dir: Directory of the application within the Git repository.
        branch: Branch name to push the changes to.
        app_name: Name of the application.
        commit_message: Commit message to use for the changes.
    """
    if branch is None:
        branch = f"{getuser()}/{app_name.replace('_', '-')}"
    if not git_branch_exists(branch, app_dir):
        _run_command(f"git checkout -b {branch}", wd=app_dir)
        _run_command(f"git push -u origin {branch}", wd=app_dir)
    else:
        _run_command(f"git checkout {branch}", wd=app_dir)
    if commit_message is None:
        commit_message = f"'initial commit of {app_name} UnifAI application'"

    _run_command("git add .", wd=app_dir)
    _run_command(f"git commit -m {commit_message}", wd=app_dir)
    _run_command("git push", wd=app_dir)

    branch_url = _get_branch_url(app_dir, branch)
    print(f"✅ Pushed changes to git, branch:\n\n\t{branch}")
    print(f"\n\t{branch_url}\n")


def print_git_help(app_dir, branch=None):
    """Prints Git commands help for pushing changes.

    Args:
        app_dir: Directory of the application within the Git repository.
        branch: Branch name to use in the help instructions.
    """
    if branch is None:
        branch = "<<new branch name>>"
        new_branch = "-b "
        set_upstream_origin = "-u origin "
    else:
        if git_branch_exists(branch, app_dir):
            new_branch = ""
            set_upstream_origin = ""
        else:
            new_branch = "-b "
            set_upstream_origin = "-u origin "

    print("To push your changes to github, run:\n")
    print(f"\tcd {app_dir}")
    print(f"\tgit checkout {new_branch}{branch}")
    print("\tgit add .")
    print(f"\tgit commit -m 'initial commit of {os.path.basename(app_dir)} UnifAI application'")
    print(f"\tgit push {set_upstream_origin}{branch}\n")
