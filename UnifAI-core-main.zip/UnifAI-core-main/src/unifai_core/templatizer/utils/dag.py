"""Utility module for building DAG files for UnifAI applications.

This module provides functions to dynamically add content to DAG template files,
including user inputs and job lists based on model definitions. It supports generating
both prospective and retrospective DAGs.
"""

from datetime import datetime

from unifai_core.templatizer.utils.common import add_custom_lines
from unifai_core.templatizer.utils.common import load_template
from unifai_core.templatizer.utils.common import split_lines
from unifai_core.templatizer.utils.common import underscore_to_capitalized


INDENT_4 = " " * 4
INDENT_8 = " " * 8


def _add_user_inputs(content, jobs):
    """Adds user inputs to DAG files.

    This function integrates user-defined inputs into the content of DAG files.

    Args:
        content: The original content of the DAG file as a list of strings.
        jobs: A list of job dictionaries detailing user inputs.

    Returns:
        The updated content list with user inputs added.
    """
    job_inputs = _get_job_inputs(jobs)
    lines = [f'{INDENT_8}"{key}": {value},' for key, value in job_inputs.items()]

    try:
        content = add_custom_lines(content, f"{INDENT_8}__ADD_JOB_INPUTS__", lines)
    except ValueError:
        pass  # Intentionally pass to allow downstream handling

    return content


def _add_job_list(content, jobs):
    """Generates the job names and integrates them into the DAG file.

    Args:
        content: The original content of the DAG file as a list of strings.
        jobs: A list of job dictionaries.

    Returns:
        The updated content list with job names and inputs added.
    """
    job_name_line = [f"{INDENT_4}JOBS = {str([job['name'] for job in jobs])}"]

    job_inputs = _get_job_inputs(jobs)
    job_input_lines = [f"{INDENT_4}JOB_INPUTS = " + "{"]
    for name in job_inputs.keys():
        input_line = f'{INDENT_8}"{name}": ' + "'{{ params." + name + " }}',"
        job_input_lines.append(input_line)
    job_input_lines.append(INDENT_4 + "}")

    try:
        content = add_custom_lines(content, f"{INDENT_4}__ADD_JOBS_AND_INPUTS__", job_name_line + job_input_lines)
    except ValueError:
        pass  # Intentionally pass to allow downstream handling

    return content


def _get_job_inputs(job_defn):
    """Extracts and aggregates user inputs from job definitions.

    Args:
        job_defn: A list of job definition dictionaries.

    Returns:
        A dictionary mapping input names to their default values.
    """
    job_inputs = {key: value.get("default") for job in job_defn for key, value in job["user_inputs"].items()}
    return job_inputs


def _get_model_version(default):
    """Determines the model version string based on the default configuration.

    Args:
        default: A dictionary containing either a branch or tag for the model version.

    Returns:
        A formatted string specifying the branch or tag for use in commands.

    Raises:
        ValueError: If neither a 'branch' nor a 'tag' key is present in the default dictionary.
    """
    if "branch" in default:
        return f'--branch {default["branch"]}'
    elif "tag" in default:
        return f'--tag {default["tag"]}'
    else:
        raise ValueError("The 'default' dictionary must contain either a 'branch' or a 'tag' key.")


def _get_replacements(model_defn):
    """Creates a dictionary of placeholder replacements for the DAG template.

    Args:
        model_defn: A dictionary containing the model definitions.

    Returns:
        A dictionary of template placeholders and their replacement values.
    """
    orchestration = model_defn["orchestration"]
    model_name = model_defn["application"]["overview"]["model_name"].lower()
    replacements = {
        "{MODEL_NAME_LOWER}": model_name,
        "{MODEL_SUFFIX_LOWER}": model_defn["application"]["overview"]["model_suffix"],
        "{MODEL_NAME_CAPITALIZE}": underscore_to_capitalized(model_name),
        "{MODEL_NAME_LOWER_HYPHEN}": model_name.replace("_", "-"),
        "{MODEL_SUFFIX_LOWER_HYPHEN}": model_defn["application"]["overview"]["model_suffix"].replace("_", "-"),
        "{TAGS}": orchestration["dag"]["tags"],
        "{DAG_OWNER}": orchestration["dag"]["owner"],
        "{EMAIL_ADDRESSES}": orchestration["dag"]["email"]["address_list"],
        "{EMAIL_ON_FAILURE}": orchestration["dag"]["email"]["email_on_failure"],
        "{EMAIL_ON_RETRY}": orchestration["dag"]["email"]["email_on_retry"],
        "{RETRIES}": orchestration["dag"]["retries"],
        "{TODAY}": datetime.today().strftime("datetime(%Y, %-m, %-d)"),
        "{DEFAULT_CONNECTION_ID}": orchestration["dag"]["default_connection_id"],
        "{DEFAULT_MODEL_VERSION}": _get_model_version(orchestration["git"]["default_model_version"]),
        "{RUN_TYPE}": model_defn["application"]["overview"]["run_type"].upper(),
        "{MODEL_REPO}": orchestration["git"]["repo_url"],
    }
    return replacements


def build_dag(model_defn, remove_todos=False, is_retrospective=False):
    """Builds the content for DAG files from model definitions.

    Args:
        model_defn: A dictionary containing the model definitions.
        is_retrospective: Indicates whether the DAG being built is for retrospective tasks.
        remove_todos: Whether todo comments should be removed or not

    Returns:
        A list of strings representing the content of the DAG file.
    """
    # Load template and define jobs
    if is_retrospective:
        content = load_template("dag_retrospective.py.txt")
        jobs = model_defn["jobs"]
        model_defn["orchestration"]["dag"]["tags"] += ["retrospective"]

    else:
        content = load_template("dag_prospective.py.txt")
        jobs = [job for job in model_defn["jobs"] if job["name"] != "labels"]

    # Fill replacements
    string_replacements = _get_replacements(model_defn)
    for key, value in string_replacements.items():
        content = content.replace(key, str(value))

    content = split_lines(content)
    content = _add_user_inputs(content, jobs)
    content = _add_job_list(content, jobs)

    if remove_todos:
        content = [line for line in content if "# TODO:" not in line]

    return content
