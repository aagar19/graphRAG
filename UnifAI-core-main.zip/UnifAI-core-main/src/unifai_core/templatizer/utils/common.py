"""Utility functions for the UnifAI templatizer module.

This module provides a set of utility functions used across the UnifAI templatizer
for tasks such as loading templates, loading and writing YAML files, manipulating
strings, and managing Python sys paths.
"""

import sys
from pathlib import Path

import yaml


def load_template(filename):
    """Loads a template file from the templates directory.

    Args:
        filename: The name of the template file to load.

    Returns:
        The content of the template file as a string.
    """
    with open(Path(__file__).parents[1] / "templates" / filename) as f:
        content = f.read()
    return content


def load_yaml(path):
    """Loads a YAML file and returns its content.

    Args:
        path: The path to the YAML file.

    Returns:
        The loaded YAML content as a dictionary.
    """
    with open(path) as f:
        loaded_yaml = yaml.safe_load(f)
    return loaded_yaml


def write_file(content, filepath):
    """Writes content to a specified file path.

    This function supports writing dictionaries directly to YAML files and
    lists or strings to any file type, ensuring directories exist.

    Args:
        content: The content to write to the file. Can be a dict, list, or string.
        filepath: The path where the file will be written.
    """
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w+") as f:
        if isinstance(content, dict) and str(filepath).endswith((".yaml", ".yml")):
            yaml.dump(content, f, default_flow_style=False, sort_keys=False)
        else:
            if isinstance(content, list):
                content = "\n".join(content)
            f.write(content)


def underscore_to_camel_case(string):
    """Converts a string from snake_case to CamelCase.

    Args:
        string: The string to convert.

    Returns:
        The converted CamelCase string.
    """
    return "".join(word.capitalize() for word in string.split("_"))


def underscore_to_capitalized(string):
    """Capitalizes and removes underscores from a string.

    Args:
        string: The string to convert.

    Returns:
        The converted string with spaces instead of underscores and capitalized words.
    """
    return " ".join(word.capitalize() for word in string.split("_"))


def add_custom_lines(content, string_break, updates):
    """Inserts custom lines into content at a specified break point.

    Args:
        content: The original list of strings.
        string_break: The marker after which the updates will be inserted.
        updates: A list of strings to insert into the content.

    Returns:
        The updated list of strings with the new lines inserted.
    """
    string_break_index = content.index(string_break)
    updated_content = content[:string_break_index] + updates + content[string_break_index + 1 :]
    return updated_content


def split_lines(content_string):
    """Splits a string into a list of lines.

    Args:
        content_string: The string to split.

    Returns:
        A list of strings, each representing a line from the original string.
    """
    return [line.rstrip() for line in content_string.split("\n")]


class SysPath:
    """Context manager for temporarily adding a path to sys.path."""

    def __init__(self, path):
        """Initializes the context manager with the path to add to sys.path.

        Args:
            path: The path to temporarily add to sys.path.
        """
        self.path = path

    def __enter__(self):
        """Adds the path to sys.path."""
        sys.path.insert(0, self.path)

    def __exit__(self, exc_type, exc_value, traceback):
        """Removes the previously added path from sys.path."""
        try:
            sys.path.remove(self.path)
        except ValueError:
            pass  # Intentionally pass to allow downstream handling
