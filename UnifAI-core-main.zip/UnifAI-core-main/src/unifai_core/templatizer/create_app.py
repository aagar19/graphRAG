"""Module for creating UnifAI application files from definitions.

This module provides functions to generate application files based on
YAML definitions, handling the creation of README, application YAML,
DAGs, job definitions, and schema files. It also includes a helper
function for git commands.
"""

from pathlib import Path

import unifai_core.templatizer.utils.application as app_utils
from unifai_core.templatizer.utils.common import load_yaml
from unifai_core.templatizer.utils.common import write_file
from unifai_core.templatizer.utils.schema import copy_file


def create_application(repo_dir, definitions_path, test=False):
    """Creates UnifAI application files from model definitions.

    This function loads model definitions from a YAML file, generates
    the necessary content, and writes it to appropriate files in the
    application directory. It supports creating a test directory for
    testing purposes.

    Args:
        repo_dir: The directory of the repository where files will be created.
        definitions_path: Path to the YAML file containing model definitions.
        test: Boolean indicating if the app should be created in a test directory.

    Returns:
        The name of the directory where the application files were created.
    """
    # load definitions
    model_definitions = load_yaml(definitions_path)

    # load content
    file_content = app_utils.get_file_content(model_definitions, repo_dir)

    # Write files
    model_name = model_definitions["application"]["overview"]["model_name"]
    model_suffix = model_definitions["application"]["overview"]["model_suffix"]
    model_dir = f"unifai_{model_name}_{model_suffix}"
    if test:
        app_dir = Path(Path(repo_dir) / "UNIFAI_TEST" / model_dir)
    else:
        app_dir = Path(Path(repo_dir) / model_dir)

    write_file(file_content["README"], app_dir / "README.md")
    write_file(file_content["application_yaml"], app_dir / "application.yaml")
    write_file(file_content["dags"]["prospective"], app_dir / "dags" / f"{model_name}_prospective.py")
    write_file(file_content["dags"]["retrospective"], app_dir / "dags" / f"{model_name}_retrospective.py")
    for name, content in file_content["jobs"].items():
        write_file(content["yaml"], app_dir / "jobs" / f"{name}.yaml")
        write_file(content["src"], app_dir / "src" / f"{name}.py")
    for name in file_content["schema_names"]:
        write_file([], app_dir / "schema" / f"{name}.yaml")
    copy_file(app_dir / "schema" / "schema.md")
    print(f"\n\n✅ Created application files in:\n\t{app_dir} \n\n")

    return model_dir
