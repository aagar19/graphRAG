"""This module provides functionalities to review and print TODOs from application files.

It searches for TODO comments in the application directory's relevant files (.md, .py, .yaml, .yml)
and prints them out. It also identifies schema files that need to be created or updated.
"""

import os
from glob import glob


def _get_file_todos(app_dir):
    """Retrieve TODO comments from application files.

    Args:
        app_dir (str): The directory path of the application files.

    Returns:
        dict: A dictionary where keys are file paths and values are lists of TODO comments.
    """
    files = glob(os.path.join(app_dir, "**/*.*"))

    all_todos = {}
    for file in sorted(files):
        if not file.endswith((".md", ".py", ".yaml", ".yml")):
            continue

        with open(file) as f:
            lines = f.readlines()

        file_todos = []
        for i, line in enumerate(lines):
            if "TODO" in line and "Engg. TODO" not in line:
                formatted_i = f"{i}, "[:3]
                file_todos.append(f'Line {formatted_i} {line[line.find("TODO"):].strip()}')

        if any(file_todos):
            all_todos[file] = file_todos

    return all_todos


def _get_schema_paths(app_dir):
    """Finds schema files in the application directory.

    Args:
        app_dir (str): The directory path of the application files.

    Returns:
        list: A list of paths to schema files within the application directory.
    """
    return glob(os.path.join(app_dir, "schema/*.yaml"))


def print_todos(app_dir) -> None:
    """Prints TODO comments and schema file paths that require action.

    Args:
        app_dir (str): The directory path of the application files.
    """
    file_todos = _get_file_todos(app_dir)
    schema_todos = _get_schema_paths(app_dir)
    print(f"\nReviewing TODOs in {app_dir}...")
    if any(file_todos):
        print(f"\nTODOs in {app_dir}:")
        for file, todo_lines in file_todos.items():
            print(f"\n    {file.replace(os.path.join(app_dir, ''), '')}")
            for line in todo_lines:
                print(f"\t{line}")
        print(
            "\nThese TODOs were added to the files automatically on creation. "
            "(UnifAI-core does its best to create file content but has limitations!)"
        )
        print("Please review the TODOs and remove the TODO comment after addressing the TODO.\n")
    if any(schema_todos):
        print("\nYou must also create schema definitions for:\n")
        for schema in schema_todos:
            print(f"\t{schema}")
        print("\t    (See <<https://unifai-docs.optum.com/developement/porting.html#schema>> for help.)")
    if not any(file_todos) and not any(schema_todos):
        print(f"\nNo TODOs in {app_dir}!")
    print("")
