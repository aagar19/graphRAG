"""Module to handle the copy of definition files for UnifAI templatizer.

This module provides functionality to copy a YAML definition file from a template
directory to a specified destination. It ensures the correct file naming conventions
are followed and creates necessary directories if they do not exist.
"""

import shutil
from pathlib import Path
from typing import Union


DEFINITIONS_FILENAME = "model_template.yaml"


def copy_definitions_file(destination: str, file_name: Union[str, None] = None) -> Path:
    """Copies the definitions file from the ./templates directory to a specified destination.

    This function checks if the file name provided ends with a '.yaml' extension and appends it if absent.
    If no file name is provided, it uses a default name. It then calculates the source and destination paths,
    creates necessary parent directories, and copies the file.

    Args:
        destination (str): The path to the destination directory or file.
        file_name (Union[str, None], optional): The name of the file to be copied. If None, a default name is used.

    Returns:
        Path: The path to the copied file in the destination directory.

    """
    # Append ".yaml" if necessary and set default file name if none provided
    if file_name and not file_name.endswith(".yaml"):
        file_name += ".yaml"
    file_name = file_name or DEFINITIONS_FILENAME

    # Define source path
    source = Path(__file__).parent / "templates" / file_name

    # Define destination path and parent directory
    if destination.endswith((".yaml", ".yml")):
        dest = Path(destination).resolve()
        parent_dir = dest.parent
    else:
        dest = Path(destination).resolve() / file_name
        parent_dir = Path(destination)

    # Create parent directories if they don't exist
    parent_dir.mkdir(parents=True, exist_ok=True)

    # Copy file
    shutil.copy(source, dest)

    return dest
