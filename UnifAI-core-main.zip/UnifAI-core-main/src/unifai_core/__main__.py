"""Command-line interface."""

import json
import os
import sys
from subprocess import run  # noqa: S404
from typing import Optional

import click
from click import Context
from tabulate import tabulate

from unifai_core.airflow.apis import list_dag_runs as _list_dag_runs
from unifai_core.airflow.apis import list_dags as _list_dags
from unifai_core.airflow.apis import publish_dag as _publish_dag
from unifai_core.airflow.apis import trigger_dag as _trigger_dag
from unifai_core.airflow.authenticator import get_auth_token
from unifai_core.app.core import deploy as _deploy
from unifai_core.app.core import list_apps as _list_apps
from unifai_core.app.core import list_jobs as _list_jobs
from unifai_core.app.core import list_params as _list_params
from unifai_core.app.core import list_runs as _list_runs
from unifai_core.app.core import publish as _publish
from unifai_core.app.core import remove_app as _remove_app
from unifai_core.app.core import run_job as _run_job
from unifai_core.app.core import undeploy as _undeploy
from unifai_core.cli.types import env_keys
from unifai_core.cli.types import priv_env_keys
from unifai_core.cli.utils import REDACTED_STR
from unifai_core.cli.utils import _prepare_orchestration_data
from unifai_core.cli.utils import ensure_schema
from unifai_core.cli.utils import get_job_stdout
from unifai_core.cli.utils import get_unifai_home
from unifai_core.cli.utils import init_settings
from unifai_core.cli.utils import insert_into_job_runs
from unifai_core.cli.utils import print_success
from unifai_core.cli.utils import setup_all
from unifai_core.cli.utils import setup_spark_env
from unifai_core.data_quality.ai_check import run_ai_check
from unifai_core.data_quality.content_check import run_content_check
from unifai_core.data_quality.DVPJSONRuleGenerator import rulegenerator
from unifai_core.data_transfer.trigger_data_transfer import trigger_data_transfer
from unifai_core.data_transfer.trigger_uniqueness_check import (
    trigger_snowflake_uniqueness_check,
)
from unifai_core.fs import core as fs_core
from unifai_core.mlflow.register_model import register_model
from unifai_core.templatizer.copy_definitions import copy_definitions_file
from unifai_core.templatizer.create_app import create_application
from unifai_core.templatizer.utils.github import print_git_help
from unifai_core.templatizer.utils.github import push_to_git


@click.group()
@click.option(
    "-p",
    "--profile",
    default=None,
    help="Short profile name used to define a specific UnifAI deployment",
)
@click.version_option()
@click.pass_context
def main(ctx: Context, profile: Optional[str]) -> None:
    """UnifAI Core CLI.

    \b
    The UnifAI Core CLI primarily supports administering UnifAI projects running within databricks environements.
    Additionally, it supports running against open source Spark servers for (typically for local development purposes
    noting that this is not yet implemented).  As the OLFP (Optum Labs Foundational Platform) matures the CLI will
    integrate with it (e.g. Data Catalog)

    \b
    Configuration:

    \b
    The CLI can be configured either via environment variables or via a a configuation file at
    $UNIFAI_HOME/unifai-config.  Environment variables take precedence over the configuration file.
    Note: If $UNIFAI_HOME is not set, the cli will try $HOME and then use $CWD if $HOME is not available.

    \b
    If profile parameter passed, the settings associated with that profile will be loaded.
    """  # noqa: D403,D301
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand == "configure" or "--help" in sys.argv:
        ctx.obj["settings"] = init_settings(profile)
    elif ctx.invoked_subcommand == "template" and "create" in sys.argv:
        ctx.obj["settings"] = init_settings(profile)
    else:
        ctx.obj["settings"] = setup_all(profile, False)


@main.command()
@click.pass_context
def configure(ctx):
    """Create or update unifai-config file for give environment."""
    settings = ctx.obj["settings"]
    unifai_home = get_unifai_home(settings)
    p = f"{unifai_home}/unifai-config"

    try:
        with open(p) as f:
            jf = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        jf = {}

    if settings["profile"] in jf.keys():
        current = jf[settings["profile"]]
    else:
        current = {
            "DATABRICKS_HOST": "",
            "DATABRICKS_TOKEN": "",
        }

    current["DATABRICKS_HOST"] = click.prompt(
        "Databricks Host (should begin with https://) ", type=str, default=current.get("DATABRICKS_HOST", "")
    )
    current["DATABRICKS_TOKEN"] = click.prompt("Databricks Token ", type=str, hide_input=True)
    current["SCHEMA_NAME"] = click.prompt(
        "Schema Name ", type=str, default=current.get("SCHEMA_NAME", settings["SCHEMA_NAME"])
    )
    current["CLUSTER_NAME"] = click.prompt(
        "Shared Cluster ", type=str, default=current.get("CLUSTER_NAME", settings["CLUSTER_NAME"])
    )
    current["AIRFLOW_HOST"] = click.prompt(
        "Airflow Host (should begin with http://) ", type=str, default=current.get("AIRFLOW_HOST", "")
    )
    current["AIRFLOW_USER"] = click.prompt("Airflow User ", type=str, default=current.get("AIRFLOW_USER", ""))
    current["AIRFLOW_TOKEN"] = click.prompt("Airflow Token ", type=str, hide_input=True)

    jf[settings["profile"]] = current

    with open(p, "w") as f:
        f.write(json.dumps(jf))


@main.command()
@click.pass_context
def shell(ctx):
    """Launches an IPython shell using databricks-connect."""
    ensure_schema(ctx.obj["settings"])

    import IPython  # type: ignore
    from pyspark.dbutils import DBUtils  # type: ignore
    from pyspark.python.pyspark.shell import sc  # type: ignore # noqa: F401
    from pyspark.python.pyspark.shell import spark  # noqa: F401

    dbutils = DBUtils(spark)  # noqa: F841 # Not used but available for ipython

    click.echo("Launching ipython")

    IPython.embed(colors="neutral")
    sc.stop()


@main.group()
@click.pass_context
def fs(ctx):
    """Command group to view and manage files on local or dbfs."""
    if "--help" not in sys.argv:
        ensure_schema(ctx.obj["settings"])


@fs.command()
@click.argument("path")
def ls(path: str) -> None:
    """List files at PATH.

    Supports local PATH or remote DBFS path (remote paths must start with dbfs:/
    """
    filepaths = fs_core.ls(path)
    for fp in filepaths:
        click.echo(fp)


@main.command()
def show_python_path() -> None:
    """Prints Python Path for environment."""
    click.echo(sys.path)


@main.command()
def show_env() -> None:
    r"""Shows pertinent environment variables.

    Pertinent keys:

    env_keys = [
        "PATH",
        "VIRTUAL_ENV",
        "DATABRICKS_HOST",
        "UNIFAI_HOME",
    ]

    Keys whose values will be redacted:

    priv_env_keys = ["DATABRICKS_TOKEN"]
    """
    env_set = set(env_keys)
    priv_env_set = set(priv_env_keys)
    out = {k: v for k, v in os.environ.items() if k in env_set}
    out.update({k: REDACTED_STR for k in os.environ.keys() if k in priv_env_set})
    click.echo(out)


@main.command()
def clusters() -> None:
    """Lists available clusters and their versions."""
    api_out = run(["databricks", "clusters", "list", "--output", "JSON"], capture_output=True)  # noqa: S603,S607
    print(str(api_out.stdout))
    clusters = json.loads(api_out.stdout)
    click.echo("\n".join([", ".join((i["cluster_name"], i["spark_version"])) for i in clusters["clusters"]]))


@main.command()
@click.argument("storage_folder")
@click.option(
    "-g",
    "--git",
    default=None,
    help="Optional UnifAI-core GIT branch or tag to be used instead of the currently installed version",
)
@click.option(
    "-w", "--wheel", default=None, help="Optional WHEEL package to be used instead of the currently installed version"
)
@click.option("--restart", is_flag=True, help="Force a restart of cluster during the bootstrap deployment.")
@click.option("--skip-upload", is_flag=True, help="Dont upload dependency files after bootstrap.")
@click.pass_context
def bootstrap(ctx: Context, storage_folder: str, git: str, wheel: str, restart: bool, skip_upload: bool) -> None:
    """Bootstrap the core UnifAI application.

    \b
    STORAGE_FOLDER: folder name to be used for the storage of FILES in Databricks
    """  # noqa: D301
    settings = ctx.obj["settings"]
    setup_spark_env(settings)
    # Deploy code to Databricks and trigger schema creation
    _deploy(settings, storage_folder, git, wheel, restart, skip_upload)
    print_success("Bootstrap UnifAI core")


@main.command()
@click.option("--delete-data/--keep-data", default=False, help="Delete or keep data files when removing core")
@click.pass_context
def remove(ctx: Context, delete_data: bool) -> None:
    """Removes UnifAI core from Databricks."""
    if click.confirm("Are you sure you want to remove UnifAI core?", abort=True):
        # Remove remote repos from Databricks (plus schema deletion on Databricks)
        _undeploy(ensure_schema(ctx.obj["settings"]), delete_data)
        print_success("Remove UnifAI core")


@main.group()
@click.pass_context
def apps(ctx: Context) -> None:
    """Application related commands."""
    if "--help" not in sys.argv and "create_template" not in sys.argv:
        ensure_schema(ctx.obj["settings"])


@apps.command()
@click.argument("git_url")
@click.argument("app_folder")
@click.option("-b", "--branch", default="main", help="Optional BRANCH to be used for git check out")
@click.option("-t", "--tag", default=None, help="Optional TAG to be used for git check out")
@click.option(
    "--orchestration-id", default=None, help="(optional) UUID provided as an input; used to link multiple job runs"
)
@click.option(
    "--orchestration-data",
    default=None,
    help="(optional) Additional orchestration metadata (as JSON) that relates back to the external orchestration job "
    '(ex. {"job_name": "sample_job", "run_id": "12345", "link_url": "<link to job>",'
    ' "configuration": "<serialized json>" }',
)
@click.option("--restart", is_flag=True, help="Force a restart of cluster during the deployment.")
@click.pass_context
def publish(
    ctx: Context,
    git_url: str,
    app_folder: str,
    branch: str,
    tag: str,
    orchestration_id: Optional[str] = None,
    orchestration_data: Optional[str] = None,
    restart: bool = False,
) -> None:
    """Publish UnifAI application into a UnifAI environment.

    \b
    GIT_URL: GHEC repository url containing the UnifAI application code
    APP_FOLDER: application code directory within the repository
    """  # noqa: D301
    # Publish application into UnifAI (run on Databricks)
    settings = ctx.obj["settings"]
    orch_id, orch_data = _prepare_orchestration_data(orchestration_id, orchestration_data)
    _publish(
        settings,
        app_folder,
        git_url,
        ("tag" if tag else "branch"),
        (tag if tag else branch),
        orch_id,
        orch_data,
        restart,
    )
    print_success(f"Published application {app_folder!r}")


@apps.command(name="list")
@click.pass_context
def list_apps(ctx: Context) -> None:
    """Returns a list of all installed apps in a UnifAI environment."""
    click.echo(tabulate(_list_apps(), ["Name", "Version", "Repository", "Path", "Description"], tablefmt="grid"))


@apps.command(name="remove")
@click.argument("app_name")
@click.option("--delete-data/--keep-data", default=False, help="Delete or keep data files when removing core")
@click.pass_context
def remove_app(ctx: Context, app_name, delete_data: bool) -> None:
    """Removes application from UnifAI."""
    if click.confirm(f"Are you sure you want to remove the application {app_name!r} UnifAI core?", abort=True):
        _remove_app(app_name, delete_data)
        print_success(f"Remove app {app_name!r}")


@main.group()
@click.pass_context
def jobs(ctx) -> None:
    """Jobs related commands."""
    if "--help" not in sys.argv:
        ensure_schema(ctx.obj["settings"])


@jobs.command(name="list")
@click.argument("app_name")
@click.pass_context
def list_jobs(ctx: Context, app_name: str) -> None:
    """List all installed jobs."""
    click.echo(tabulate(_list_jobs(app_name), ["Name", "Version", "Class", "Path", "Description"], tablefmt="grid"))


@jobs.command(name="list-runs")
@click.argument("app_name")
@click.pass_context
def list_runs(ctx: Context, app_name: str) -> None:
    """List all job runs recorded in the system."""
    runs = _list_runs(app_name)
    to_show = [
        (r.model_job_name, r.start_time, r.complete_time, r.status, r.other_params, r.git_commit_hash) for r in runs
    ]
    click.echo(
        tabulate(
            to_show, ["Job Name", "Start Time", "Complete Time", "Status", "Params", "Commit Hash"], tablefmt="grid"
        )
    )


@jobs.command(name="list-params")
@click.argument("job_name")
@click.pass_context
def list_params(ctx: Context, job_name: str) -> None:
    """List all job params defined."""
    # Get job details
    split_name = job_name.split(".")
    if len(split_name) == 2:
        app_name = split_name[0]
        job_name = split_name[1]
    else:
        raise RuntimeError(
            f"Invalid application/job name provided ({job_name!r}). Must be in format: <app_name>.<job_name>"
        )
    # display job params
    click.echo(
        tabulate(
            _list_params(app_name, job_name),
            ["Job Name", "Param Name", "Type", "Required", "Default", "Description"],
            tablefmt="grid",
        )
    )


@jobs.command(name="run")
@click.argument("job-name", nargs=1)
@click.argument("run-args", nargs=-1)
@click.option(
    "--orchestration-id", default=None, help="(optional) UUID provided as an input; used to link multiple job runs"
)
@click.option(
    "--orchestration-data",
    default=None,
    help="(optional) Additional orchestration metadata (as JSON) that relates back to the external orchestration job "
    '(ex. {"job_name": "sample_job", "run_id": "12345", "link_url": "<link to job>",'
    ' "configuration": "<serialized json>" }',
)
@click.option(
    "--prompt",
    is_flag=True,
    help="Prompt user to enter job arguments. This will also force the run to wait for completion",
)
@click.option(
    "--use-shared-cluster", is_flag=True, help="Whether to use the defined shared cluster or create new job cluster"
)
@click.option(
    "--debug",
    is_flag=True,
    help="Return the logs from the job output. This will also force the run to wait for completion",
)
@click.option("--wait", is_flag=True, help="Whether to wait for the job run to complete")
@click.option("--users-can-view", is_flag=True, help="Whether users in users group can view")
@click.pass_context
def run_job(
    ctx: Context,
    job_name: str,
    run_args: list,
    orchestration_id: Optional[str] = None,
    orchestration_data: Optional[str] = None,
    prompt: bool = False,
    use_shared_cluster: bool = False,
    debug: bool = False,
    wait: bool = False,
    users_can_view: bool = True,
) -> None:
    """Run a job.

    \b
    JOB_NAME: Name of python module with job to run
    JOB_ARGS: Arguments to pass to the job in the form of "<name>=<value>"
    """  # noqa: D301
    settings = ctx.obj["settings"]
    # Get job details
    split_name = job_name.split(".")
    if len(split_name) == 2:
        app_name = split_name[0]
        job_name = split_name[1]
    else:
        # Logging : Insert error logs into job_runs table
        message = f"Invalid application/job name provided ({job_name!r}). Must be in format: <app_name>.<job_name>"
        insert_into_job_runs(message=message, orchestration_id=orchestration_id)
        raise RuntimeError(message)
    orch_id, orch_data = _prepare_orchestration_data(orchestration_id, orchestration_data)
    # Prepare and execute job on databricks
    run_name = _run_job(
        app_name,
        job_name,
        run_args,
        settings,
        orch_id,
        orch_data,
        prompt,
        use_shared_cluster,
        debug,
        wait,
        users_can_view,
    )

    # Display a success message back to the user
    print_success(f"Job {run_name!r}")
    if not orchestration_id:
        print(
            "FYI: To link jobs, the same orchestration ID needs to be used;"
            " include the following parameter in subsequent job runs..."
        )
        print(f"  unifai-admin jobs run {app_name}.<some-other-job> ... --orchestration-id {orch_id}\n")


@jobs.command(name="get-job-output")
@click.argument("job_run_id")
@click.option("--metadata", is_flag=True)
@click.option("--error-trace", is_flag=True)
@click.pass_context
def get_job_output(
    ctx: Context,
    job_run_id: str,
    metadata: bool = False,
    error_trace: bool = False,
) -> None:
    """Displays the logs/errors/metadata for any job run given run id of it."""
    get_job_stdout(run_id=job_run_id, metadata=metadata, error_trace=error_trace)


@main.group()
@click.pass_context
def reporting(ctx) -> None:
    """Snowflake related commands."""
    if "--help" not in sys.argv:
        ensure_schema(ctx.obj["settings"])


@reporting.command(name="check-uniqueness")
@click.argument("snowflake_schema")
@click.pass_context
def check_uniqueness(ctx: Context, snowflake_schema: str) -> None:
    """Check the given snowflake schema for duplicate data."""
    settings = ctx.obj["settings"]
    trigger_snowflake_uniqueness_check(snowflake_schema, settings)


@reporting.command(name="data-transfer")
@click.argument("schema_name")
@click.argument("table_name")
@click.option(
    "-o",
    "--orchestration_id",
    default=None,
    help="Orchestration ID for the records.",
)
@click.option(
    "-p",
    "--parent_id",
    default=None,
    help="Parent ID for the records.",
)
@click.option(
    "-s",
    "--snowflake_schema_name",
    show_default=True,
    default="UNIFAI_DEV",
    help="Snowflake schema to be used",
)
@click.option(
    "--skip-if-exists/--no-skip-if-exists",
    show_default=True,
    default=True,
    help="If no skip, then potentially write duplicate data to jobs and applications tables.",
)
@click.pass_context
def data_transfer(
    ctx: Context,
    schema_name: str,
    table_name: str,
    orchestration_id: str,
    parent_id: str,
    snowflake_schema_name: str,
    skip_if_exists: bool,
) -> None:
    """Transfer data from databricks schema delta tables to reporting database."""
    settings = ctx.obj["settings"]
    trigger_data_transfer(
        orchestration_id, parent_id, schema_name, table_name, snowflake_schema_name, skip_if_exists, settings
    )


@main.command()
@click.argument("data_path")
@click.argument("table_name")
@click.argument("location")
@click.option(
    "-f",
    "--table_format",
    show_default=True,
    default="DELTA",
    help="Desired format of the table",
)
@click.option(
    "-e",
    "--if_not_exist_flag",
    show_default=True,
    default=True,
    help="whether to keep IF NOT EXIST in the command or not",
)
def generate_ddl(
    data_path: str,
    table_name: str,
    location: str,
    table_format: str,
    if_not_exist_flag: bool,
) -> None:
    """Function to retrieve the CREATE DDL statement from a parquet table.

    Args:
        data_path: path to the parquet table
        table_name: the name of the table we want to create
        location: Path where table data will be stored
        table_format: (Optional) format of the table like DELTA, PARQUET etc.  Default is DELTA
        if_not_exist_flag: (Optional) if we want to put IF NOT EXIST flag in our create query Default is True
    """
    from unifai_core.data_management.generate_ddl import create_table_ddl

    query = create_table_ddl(data_path, table_name, location, table_format, if_not_exist_flag)
    if query[0]:
        click.echo(query[1])


@main.command()
@click.argument("file_path")
@click.argument("root_location")
@click.option(
    "-e",
    "--if_not_exist_flag",
    show_default=True,
    default=True,
    help="whether to keep IF NOT EXIST in the command or not",
)
def create_table(file_path: str, root_location: str, if_not_exist_flag: bool) -> None:
    """Function to create a table.

    Args:
        file_path: jinja sql template file containing CREATE DDL command
        root_location: location to give the table in blobstorage
        if_not_exist_flag: whether to keep IF NOT EXIST command in the query
    """
    from unifai_core.data_management.create_table import main  # type: ignore

    result = main(file_path, root_location, if_not_exist_flag)
    if result is not False:
        click.echo("Table created Successfully.")


@main.command()
@click.argument("directory")
@click.argument("location")
# @click.option("-l", "location", help="Desired location of the table")
@click.option(
    "-e",
    "--if_not_exist_flag",
    show_default=True,
    default=True,
    help="whether to keep IF NOT EXIST in the command or not",
)
def create_tables(directory: str, location: str, if_not_exist_flag: bool) -> None:
    """Function to generate tables on the basis of CREATE DDL sqls stored in directory."""
    from unifai_core.data_management.create_tables import main  # type: ignore

    result = main(directory, location, if_not_exist_flag)
    if result:
        click.echo("Tables created Successfully.")


@main.command()
@click.argument("file_path")
@click.option(
    "-e",
    "--if_exist_flag",
    show_default=True,
    default=True,
    help="whether to keep IF EXIST in the command or not",
)
def drop_table(file_path: str, if_exist_flag: bool) -> None:
    """Function to drop a table.

    Args:
        file_path: jinja sql template file containing DROP DDL command
        if_exist_flag: whether to keep IF EXIST command in the query
    """
    from unifai_core.data_management.drop_table import main  # type: ignore

    result = main(file_path, if_exist_flag)
    if result is not False:
        click.echo("Table Dropped Successfully.")


@main.command()
@click.argument("directory")
@click.option(
    "-e",
    "--if_exist_flag",
    show_default=True,
    default=True,
    help="whether to keep IF EXIST in the command or not",
)
def drop_tables(directory: str, if_exist_flag: bool) -> None:
    """Function to drop tables on the basis of DROP DDL sqls stored in directory."""
    from unifai_core.data_management.drop_tables import main  # type: ignore

    result = main(directory, if_exist_flag)
    if result:
        click.echo("Tables dropped Successfully.")


@main.command()
@click.argument("file_path")
@click.argument("location")
@click.option(
    "-e",
    "--if_not_exist_flag",
    show_default=True,
    default=True,
    help="whether to keep IF NOT EXIST in the command or not",
)
@click.option(
    "-c",
    "--continue_on_failure",
    show_default=True,
    default=False,
    help="continue through next command if True else exits the program on failure",
)
def create_tables_from_single_file(
    file_path: str, location: str, if_not_exist_flag: bool, continue_on_failure: bool
) -> None:
    """Create multiple tables from a single sql file containing multiple CREATE DDL commands separated by ';'."""
    from unifai_core.data_management.create_tables_from_single_file import main  # type: ignore  #isort: skip

    result = main(file_path, location, if_not_exist_flag, continue_on_failure)
    if result is not False:
        click.echo("Tables created Successfully.")


@main.command()
@click.argument("file_path")
@click.argument("table_name")
def create_table_against_existing_path(file_path: str, table_name: str) -> None:
    """Create multiple tables from a single sql file containing multiple CREATE DDL commands separated by ';'."""
    from unifai_core.data_management.create_table_against_existing_path import main  # type: ignore  #isort: skip

    result = main(file_path, table_name)
    if result is not False:
        click.echo("Tables created Successfully.")


@main.group()
@click.pass_context
def dags(ctx) -> None:
    """Airflow DAG related commands."""
    pass


@dags.command(name="publish")
@click.option("-f", "--file-path", required=True, help="The path to the DAG python file on the client machine.")
@click.option(
    "-s",
    "--server-path",
    required=False,
    help="The path on the server you wish to save the DAG to. default = '/opt/airflow/dags'",
)
@click.pass_context
def publish_dag(ctx: Context, file_path: str, server_path: str) -> None:
    """Trigger a prompt to create new Airflow connection."""
    token = get_auth_token(ctx.obj["settings"])
    _publish_dag(ctx.obj["settings"], token, file_path, server_path)


@dags.command(name="trigger")
@click.option("-d", "--dag_id", required=True, help="The DAG id to trigger manually in Airflow.")
@click.option(
    "-c",
    "--config",
    required=False,
    help="The DAG run configuration (serialised JSON) provided when starting the DAG run (ex. {'name': 'John'}.",
)
@click.pass_context
def trigger_dag(ctx: Context, dag_id: str, config: str) -> None:
    """Trigger a run for the specified DAG."""
    token = get_auth_token(ctx.obj["settings"])
    _trigger_dag(ctx.obj["settings"], token, dag_id, config)


@dags.command(name="list")
@click.option("-l", "--limit", required=False, default=20, show_default=True, help="Limit the DAGs output by number.")
@click.option(
    "-t",
    "--tags",
    required=False,
    multiple=True,
    default=[],
    show_default=True,
    help="Filter the DAGs output by tag (ex. -t test -t retro).",
)
@click.option(
    "--json", "json", is_flag=True, default=False, show_default=True, help="Return the raw JSON output from the API."
)
@click.pass_context
def list_dags(ctx: Context, limit: int, tags: str, json: bool) -> None:
    """Returns a list all DAGs on the specified Airflow server."""
    token = get_auth_token(ctx.obj["settings"])
    _list_dags(ctx.obj["settings"], token, limit, tags, json)


@dags.command(name="runs")
@click.option("-d", "--dag_id", required=True, show_default=True, help="The DAG id (name) to query runs.")
@click.option(
    "-l", "--limit", required=False, default=5, show_default=True, help="Limit the DAG runs output by number."
)
@click.option(
    "--json", "json", is_flag=True, default=False, show_default=True, help="Return the raw JSON output from the API."
)
@click.pass_context
def list_dag_runs(ctx: Context, dag_id: str, limit: int, json: bool) -> None:
    """List Airflow DAG runs for a specified DAG."""
    token = get_auth_token(ctx.obj["settings"])
    _list_dag_runs(ctx.obj["settings"], token, dag_id, limit, json)


@main.group(name="data-quality")
@click.pass_context
def data_quality(ctx) -> None:
    """Data Quality related commands."""
    if "--help" not in sys.argv:
        ensure_schema(ctx.obj["settings"])


@data_quality.command(name="run")
@click.argument("app-name", nargs=1)
@click.argument("extra-args", nargs=-1)
@click.option(
    "-c",
    "--check-type",
    type=click.Choice(["content-check", "ai-check"], case_sensitive=False),
    prompt="Enter check type (content-check/ai-check)",
    required=True,
    help="whether to run content-check or ai-check",
)
@click.option(
    "--orchestration-id", default=None, help="(optional) UUID provided as an input; used to link multiple job runs"
)
@click.option(
    "--orchestration-data",
    default=None,
    help="(optional) Additional orchestration metadata (as JSON) that relates back to the external orchestration job "
    '(ex. {"job_name": "sample_job", "run_id": "12345", "link_url": "<link to job>",'
    ' "configuration": "<serialized json>" }',
)
@click.pass_context
def run_data_quality(
    ctx: Context,
    app_name: str,
    extra_args: list,
    check_type: str,
    orchestration_id: Optional[str] = None,
    orchestration_data: Optional[str] = None,
) -> None:
    """Run data quality tools(content-check/ai-check) via databricks."""
    settings = ctx.obj["settings"]
    extra_dict = {}
    for arg in extra_args:
        k, v = arg.strip().split("=")
        extra_dict[k] = v
    orch_id, orch_data = _prepare_orchestration_data(orchestration_id, orchestration_data)
    extra_dict["config_type"] = extra_dict.get("config_type", "default").upper()
    if check_type.lower() == "content-check":
        run_content_check(settings, app_name, extra_dict, orch_id, orch_data)
    elif check_type.lower() == "ai-check":
        extra_dict["client"] = extra_dict.get("client", "local")
        extra_dict["env"] = extra_dict.get("environment", extra_dict.get("env", "dev"))
        extra_dict["level"] = extra_dict.get("level", "unifai")
        extra_dict["version"] = extra_dict.get("version", 202208)
        run_ai_check(settings, app_name, extra_dict, orch_id, orch_data)
    else:
        raise Exception("Please enter valid check_type (content-check/ai-check) !")


@data_quality.command(name="generate-dvp-rule")
@click.option(
    "-r",
    "--rulefolder",
    prompt="Provide folder where rules are saved in text",
    required=True,
    help="rules to convert from text to json",
)
@click.option("-c", "--configfolder", help="configuration file to be passed", required=True)
def convert_rule(configfolder: str, rulefolder: str) -> None:
    """Generate JSON rules from the text rules."""
    rulegenerator(rulefolder, configfolder)


@main.group()
@click.pass_context
def mlflow(ctx) -> None:
    """Mlflow related commands."""
    ensure_schema(ctx.obj["settings"])


@mlflow.command(name="register-model")
@click.argument("app_name")
@click.pass_context
def register_mlflow_model(ctx: Context, app_name: str) -> None:
    """Register a model into Mlflow given an application."""
    settings = ctx.obj["settings"]
    register_model(app_name, settings)


@main.group()
@click.pass_context
def template(ctx) -> None:
    """Template related commands."""
    pass


@template.command(name="create-template")
@click.option("--destination", "-d", help="Destination path for base app template config.", required=False, default=".")
@click.option("--file-name", "-f", help="Optional name for the new templated file.", required=False, default=None)
@click.pass_context
def create_template(ctx: Context, destination: str, file_name: str) -> None:
    """Copy the base template file to the destination path."""
    dest = copy_definitions_file(os.path.abspath(destination), file_name)
    print(f"\n✅ Copied templated app definition file to:\n\n\t{dest}\n")
    print("Open this file and follow instructions to begin creating a UnifAI YAML definition your AI/ML model.")


@template.command(name="create-app")
@click.option(
    "--destination", "-d", required=True, help="Path to the destination repo where the application will be created."
)
@click.option("--source", "-s", required=True, help="Path to the completed app definitions YAML source file.")
@click.option("--test", "-t", help="Create files in a TEST directory. [flag]", required=False, is_flag=True)
@click.option("--publish-airflow", help="Publish DAG to Airflow.  [flag]", required=False, is_flag=True)
@click.option("--git-push", help="Push changes to GitHub.  [flag]", required=False, is_flag=True)
@click.option("--git-branch", help="(If deploy) Name of git branch to add application.", required=False, default=None)
@click.pass_context
def create_app(
    ctx: Context, destination: str, source: str, test: str, publish_airflow: bool, git_push: bool, git_branch: str
) -> None:
    """Create a new IdentifAI application files from yaml."""
    app = create_application(destination, source, test)

    if test:
        app_dir = os.path.join(destination, "UNIFAI_TEST/" + app)
        print_git_help(app_dir, git_branch)
        print(f"To review TODOs, run:\n\tunifai-admin template review-todos --app-dir {app_dir}\n")
    else:
        app_dir = os.path.join(destination, app)
        print(f"To review TODOs, run:\n\tunifai-admin template review-todos --app-dir {app_dir}\n")
        if git_push:
            # Push to GitHub
            push_to_git(app_dir, git_branch, app)
        else:
            print_git_help(app_dir, git_branch)

        if publish_airflow and not test:
            token = get_auth_token(ctx.obj["settings"])

            dags = os.listdir(os.path.join(app_dir, "dags"))
            prospective_dag = [dag for dag in dags if dag.endswith("_prospective.py")][0]
            retrospective_dag = [dag for dag in dags if dag.endswith("_retrospective.py")][0]
            print(f"\nAttempting to publish Airflow DAG: {os.path.join(app_dir, 'dags', prospective_dag)}")
            _publish_dag(
                ctx.obj["settings"], token, quiet=True, file_path=os.path.join(app_dir, "dags", prospective_dag)
            )
            print(f"\nAttempting to publish Airflow DAG: {os.path.join(app_dir, 'dags', retrospective_dag)}")
            _publish_dag(
                ctx.obj["settings"], token, quiet=True, file_path=os.path.join(app_dir, "dags", retrospective_dag)
            )
            print(f"\n\n✅ Successfully published Airflow prospective and retrospective DAGs for model: {app}")


@template.command(name="review-todos")
@click.pass_context
@click.option("--app-dir", "-a", required=True, help="Path to the IdentifAI application directory.")
def review_todos(ctx: Context, app_dir: str) -> None:
    """Review the TODOs in the IdentifAI application files."""
    from unifai_core.templatizer.review_todo import print_todos

    print_todos(app_dir)


if __name__ == "__main__":
    main(prog_name="unifai-admin")  # pragma: no cover
