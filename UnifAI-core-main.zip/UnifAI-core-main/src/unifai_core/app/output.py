"""Support for storing data in the output store."""

from datetime import datetime

from pyspark.sql import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType

from unifai_core.app.utils import retry_spark_sql


def add_output(
    calculation_name: str,
    data_link_value: str,
    value: float,
    model_job_id: str,
    code_repo_name: str,
    model_job_path: str,
    model_job_name: str,
    model_run_start_time: float,
) -> None:
    """Add a single entry to the output store."""
    insert_stmt = f"""
insert into unifai_core_model_output values (
"{model_job_id}"
,"{code_repo_name}"
, "{model_job_path}"
, "{model_job_name}"
, cast({model_run_start_time} as timestamp)
, "{calculation_name}"
, "{data_link_value}"
, {value}
)"""
    spark = SparkSession.builder.getOrCreate()
    retry_spark_sql(spark, insert_stmt)


def add_bulk_output(calculation_name: str, data: DataFrame, col_map: dict, **kwargs) -> None:
    """Add multiple entries to output store.

    todo: This function should be decomissioned as a result of the new add_bulk_output function in jobs/base.py
    """
    spark = SparkSession.builder.getOrCreate()
    os = spark.table("unifai_core_model_output")
    prototype = [
        str(kwargs["model_job_id"]),
        kwargs["code_repo_name"],
        kwargs["model_job_path"],
        kwargs["model_job_name"],
        datetime.fromtimestamp(kwargs["model_run_start_time"]),
        calculation_name,
    ]

    if dlv_name := col_map.get("data_link_value"):
        data = data.withColumnRenamed(dlv_name, "data_link_value")
    if r_name := col_map.get("run_as_of"):
        data = data.withColumnRenamed(r_name, "run_as_of")
    if v_name := col_map.get("value"):
        data = data.withColumnRenamed(v_name, "value")

    left_df = spark.createDataFrame(data=[prototype], schema=StructType(os.schema.fields[:6]))

    to_save = left_df.join(data, how="cross")
    to_save = to_save.select(
        to_save.model_run_id,
        to_save.code_repo_name,
        to_save.model_job_path,
        to_save.model_job_name,
        to_save.model_run_start_time,
        to_save.calculation_name,
        to_save.run_as_of,
        to_save.data_link_value,
        to_save.value,
    )

    to_save.write.format("delta").mode("append").saveAsTable("unifai_core_model_output")
