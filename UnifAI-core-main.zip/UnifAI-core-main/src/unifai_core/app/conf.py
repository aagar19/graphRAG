"""Configuration classes for UnifAI Application or job."""

import json
import traceback
from datetime import datetime
from types import TracebackType
from typing import Any
from typing import Dict
from typing import Optional
from typing import Tuple
from typing import Type
from uuid import uuid4

import yaml

from unifai_core.app.utils import _update_databricks_table
from unifai_core.app.utils import _update_orchestration_table
from unifai_core.app.utils import get_configuration
from unifai_core.app.utils import retry_spark_sql
from unifai_core.utils.merge import deep_merge
from unifai_core.utils.parser import parse_value_config
from unifai_core.utils.parser import populate_run_args
from unifai_core.utils.parser import update_run_args


APP_INIT_SCRIPT = """#!/bin/bash
source {INIT_STORE_PATH}/default-init.sh
"""


class ApplicationConfiguration:
    """Configuration for a UnifAI application.

    Supports the following configuations: -
      - path: full path to the application code
      - description: detailed description about the application; defaults to None
      - configuration: respective application configuration; defaults to None
    """

    def __init__(  # noqa: C901
        self,
        app_name: Optional[str] = None,
        app_path: Optional[str] = None,
        additional_config: Optional[dict] = None,
        merge_config: bool = False,
        spark=None,
        with_user: bool = False,
    ) -> None:
        """Load a configuration for an application."""
        # Setup the configs
        self.__app_config: Dict[str, Any] = {} if not (additional_config and merge_config) else additional_config.copy()
        self.__base_config = {
            **({} if not spark else get_configuration(spark, with_user)),
            **({} if not additional_config or merge_config else additional_config),
        }

        # Ensure theres one of name or path
        if (app_name and app_path) or (not app_name and not app_path):
            raise ValueError("Failied to initialize ApplicationConfiguration, must pass in the name or path!")
        # Load based on name
        elif app_name:
            if not spark:
                raise ValueError("Failied to initialize ApplicationConfiguration, need to pass name and spark!")
            self.configuration = self.__load_db_config(spark, app_name)
        # Load based on path
        elif app_path:
            self.configuration = self.__load_yaml_config(app_path)

        self.__parse_app_config(merge_config)

    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """Returns configuration value based on the passed in key, or return the default."""
        return self.get_config().get(key, default)

    def get_app_config(self) -> dict:
        """Returns only application configuration."""
        return self.__app_config

    def get_config(self) -> dict:
        """Returns all configuration releated to the current application."""
        return deep_merge(
            self.__base_config,
            self.__app_config,
            {"APP_NAME": self.name, "APP_PATH": self.path},
        )

    def parse_with_config(self, source: str, extras: Optional[dict] = None) -> str:
        """Utility function to parse a string with respective application configuration."""
        return parse_value_config(source, format_map={**self.get_config(), **(extras or {})})

    def __load_db_config(self, spark, app_name: str) -> dict:
        app_info = spark.sql(
            f"""
                SELECT a.*, r.path as repo_path, r.hash as git_hash
                  FROM unifai_core_applications a, unifai_core_repositories r
                 WHERE a.id = r.application_id
                   AND (a.path LIKE '%{app_name}/{app_name}'
                    OR a.name = '{app_name}')
                 LIMIT 1
                """
        ).collect()[0]
        self.id = app_info.id
        self.name = "default" if app_name == "unifai_core_app" else app_info.name
        self.description = app_info.description
        self.path = app_info.path

        configuration = json.loads(f"{app_info.configuration}".replace("`", "'"))

        self.__base_config["APP_VERSION"] = app_info.version
        self.__base_config["REPO_PATH"] = app_info.repo_path
        self.__base_config["GIT_HASH"] = app_info.git_hash

        return configuration

    def __load_yaml_config(self, app_path: str) -> dict:
        try:
            with open(f"{app_path}/application.yaml") as f:
                configuration = yaml.safe_load(f)
                self.id = None
                self.path = app_path
                if not configuration.get("name"):
                    self.name = app_path.split("/")[-1]
                elif configuration.get("name") == "unifai_core_app":
                    self.name = "default"
                    del configuration["name"]
                else:
                    self.name = configuration.get("name")
                    del configuration["name"]
                if configuration.get("description"):
                    self.description = configuration.get("description")
                    del configuration["description"]
                else:
                    self.description = None
                return configuration
        except Exception as ex:
            raise ValueError(
                "Failied to initialize ApplicationConfiguration, couldn't load yaml config {app_path}!"
            ) from ex

    def __parse_app_config(self, merge_config: bool):  # noqa: C901
        config: Dict[str, Any] = {}
        cluster = self.configuration.get("cluster", {})
        self.use_app_cluster = cluster.get("create_cluster") is True
        use_proton = cluster.get("use_photon") is True
        node_type = "Standard_D4ds_v4" if use_proton else "Standard_F8s_v2"
        self.__resolve_config(config, "CLUSTER_NODE_TYPE", cluster.get("node_type"), node_type)
        self.__resolve_config(
            config, "WORKER_NODE_TYPE", cluster.get("worker_node_type", cluster.get("node_type")), node_type
        )
        self.__resolve_config(config, "CLUSTER_RUNTIME_VERSION", cluster.get("runtime_version"), "10.4.x-scala2.12")
        self.__resolve_config(config, "CLUSTER_RUN_ENGINE", "PHOTON" if use_proton else "STANDARD")
        self.__resolve_config(config, "CLUSTER_MAX_WORKERS", cluster.get("max_workers"), 2)
        self.__resolve_config(config, "CLUSTER_MIN_WORKERS", cluster.get("min_workers"), 1)

        # turn data-quality settings into config
        self.data_quality = self.configuration.get("data_quality", {})
        if len(self.data_quality):
            for k, v in self.data_quality.items():
                for key in v:
                    self.data_quality[k][key] = f"{self.get('APP_PATH')}/{v[key]}"
                    self.__resolve_config(
                        config,
                        "DATA_QUALITY_" + k.upper() + "_" + key.upper(),
                        self.parse_with_config("{FILE_STORE_PATH}/{APP_NAME}/data_quality") + f"/{k}/{key}",
                    )

        # turn dependencies settings into config
        self.dependencies = []
        for dep in self.configuration.get("dependencies", []):
            target_path = self.parse_with_config("{FILE_STORE_PATH}/dependencies/" + dep["target"])
            dependency_dict = {"source_url": dep.get("source"), "target_path": target_path}
            if "git_repo" in dep:
                if "git_version" not in dep:
                    raise Exception("Version is not defined for git repo dependency inside application config !")
                dependency_dict.update({"git_repo": dep["git_repo"], "git_version": dep["git_version"]})
            self.dependencies.append(dependency_dict)
            config[dep["config"].upper()] = target_path

        # turn cluster settings into config
        mlflow = self.configuration.get("mlflow_model_config", {})
        self.__resolve_config(config, "MLFLOW_MODEL_NAME", mlflow.get("model_name"))
        self.__resolve_config(config, "MLFLOW_MODEL_PATH", mlflow.get("model_path"))
        self.__resolve_config(config, "MLFLOW_MODEL_FLAVOR", mlflow.get("mlflow_flavor"))
        self.__resolve_config(config, "MLFLOW_MODEL_ARTIFACT", mlflow.get("artifact_path"))

        # update config (provided + yaml)
        for k, v in self.configuration.get("configuration", {}).items():
            self.__app_config[k.upper()] = None if not v else self.parse_with_config(v, config)

        # Finialise Configuration
        if merge_config:
            self.__app_config = {**self.__app_config, **config}
        else:
            self.__base_config = {**self.__base_config, **config}

        self.configuration["configuration"] = self.__app_config

        # Read in other cluster settings
        self.env_variables = cluster.get("env_variables", {})
        self.spark_config = cluster.get("spark_config", {})
        self.init_script = None
        if self.name == "default" or (self.use_app_cluster and cluster.get("init_script")):
            self.init_script = self.parse_with_config(cluster["init_script"])
        elif self.use_app_cluster and not cluster.get("init_script"):
            self.init_script = self.parse_with_config(APP_INIT_SCRIPT)
        script_file = self.parse_with_config("{APP_NAME}-init.sh") if self.init_script else "default-init.sh"
        self.script_path = self.parse_with_config("{INIT_STORE_PATH}/" + script_file)

    def __resolve_config(self, config: dict, key: str, value, default=None) -> None:
        if value:
            config[key] = value
        elif self.__base_config.get(key):
            config[key] = self.__base_config[key]
        elif default:
            config[key] = default


class JobConfiguration:
    """Configuration for a UnifAI Job."""

    def __init__(
        self,
        application: ApplicationConfiguration,
        job_name: str,
        orchestration_id: str,
        spark=None,
        prompt_user: bool = False,
        **kwargs,
    ) -> None:
        """Load a configuration for a job."""
        self.__application = application
        self.__args: Dict[str, Any] = {}
        self.__config: Dict[str, Any] = {}
        self.__spark = spark
        self.__use_unifai = spark is not None
        self.orchestration_id = orchestration_id
        self.parent_id: Optional[str] = None

        self.__load_db_config(job_name)

        # Prompt for job ARGS
        if prompt_user:
            job_args = populate_run_args(
                f"{application.name}.{job_name}",
                self.__inputs,
                kwargs,
                self.get_config(),
            )
        # Validate job ARGS
        else:
            job_args = update_run_args(job_name, self.get_config(), self.__inputs, **kwargs)

        # Parse/Update ARGS
        self.__args = {}
        for k, v in job_args.items():
            if v and k != "data_as_of" and k != "run_as_of" and k != "run_type":
                self.__args[k] = v
        self.data_as_of = job_args.get("data_as_of") or kwargs.get("data_as_of") or str(datetime.today().date())
        self.run_as_of = job_args.get("run_as_of") or kwargs.get("run_as_of") or str(datetime.today().date())
        self.run_type = job_args.get("run_type") or kwargs.get("run_type")

    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """Returns configuration value based on the passed in key, or return the default."""
        return self.get_config().get(key, default)

    def get_application(self) -> ApplicationConfiguration:
        """Returns job parent application."""
        return self.__application

    def get_args(self) -> dict:
        """Returns job custom arguments."""
        return self.__args

    def get_json_args(self) -> str:
        """Returns job run arguments as JSON string."""
        return json.dumps(
            {**self.__args, **{"data_as_of": self.data_as_of, "run_as_of": self.run_as_of, "run_type": self.run_type}}
        )

    def get_config(self) -> dict:
        """Returns all configuration releated to the current job."""
        return {**self.__application.get_config(), **self.__config}

    def get_dependencies(self) -> list:
        """Returns job specific dependencies."""
        return self.__dependencies

    def get_inputs(self) -> dict:
        """Returns job input configuration."""
        return self.__inputs

    def end_job(
        self,
        exc_type: Optional[Type[BaseException]] = None,
        exc_value: Optional[BaseException] = None,
        exc_tb: Optional[TracebackType] = None,
    ) -> Tuple[int, Optional[str]]:
        """Returns all configuration releated to the current application."""
        self.end_time = datetime.now()
        success = 0
        status_msg = None
        if exc_type or exc_tb:
            success = 1
            ex_type = "UnifaiError" if not exc_type else exc_type.__name__
            status_msg = f"{ex_type}: {exc_value}\n" + "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        elif exc_value:
            status_msg = f"{exc_value}"
        if self.__use_unifai:
            self.__update_run_table(success, status_msg)
        return success, status_msg

    def start_job(
        self,
        job_id: Optional[str] = None,
        run_id: Optional[str] = None,
        job_host: Optional[str] = None,
        orchestration_data: Optional[dict] = None,
        use_unifai: bool = True,
    ) -> None:
        """Returns all configuration releated to the current application."""
        self.job_id = job_id
        self.run_id = run_id
        self.run_uuid = str(uuid4())
        self.start_time = datetime.now()
        self.__use_unifai = use_unifai

        if self.__use_unifai:
            self.databricks_id = _update_databricks_table(
                self.__spark, self.__application.name, self.name, self.get_config(), job_id, run_id, (job_host or "./")
            )
            self.parent_id = _update_orchestration_table(
                self.__spark, self.orchestration_id, orchestration_data, self.get_config()
            )

    def parse_with_config(self, source: str, extras: Optional[dict] = None) -> str:
        """Utility function to parse a string with respective job configuration."""
        return parse_value_config(source, format_map={**self.get_config(), **(extras or {})})

    def __load_db_config(self, job_name: str) -> None:
        self.name = job_name
        if self.__use_unifai:
            job_info = retry_spark_sql(
                self.__spark,
                f"""
                SELECT *
                  FROM unifai_core_jobs
                 WHERE application_id = '{self.__application.id}'
                   AND name = '{job_name}'
                """,
            )[0]
            self.id = job_info.id
            self.class_name = job_info.class_name
            job_config = json.loads(job_info.configuration)
        else:
            self.id = str(uuid4())
            self.class_name = "MockJob"
            job_config = self.__application.configuration

        self.sys_paths = [self.parse_with_config(p) for p in job_config.get("sys_paths", [])]
        self.__dependencies = job_config.get("dependencies", [])
        self.__inputs = job_config.get("inputs", {})
        # Add Job Config
        self.__config["JOB_NAME"] = self.name
        # Parse Cluster Settings
        cluster = job_config.get("cluster", {})
        node_type = cluster.get("node_type")
        if node_type:
            self.__config["CLUSTER_NODE_TYPE"] = node_type
        worker_node_type = cluster.get("worker_node_type") or node_type
        if worker_node_type:
            self.__config["WORKER_NODE_TYPE"] = worker_node_type
        min_workers = cluster.get("min_workers")
        if min_workers:
            self.__config["CLUSTER_MIN_WORKERS"] = min_workers
        max_workers = cluster.get("max_workers")
        if max_workers:
            self.__config["CLUSTER_MAX_WORKERS"] = max_workers
        runtime_version = cluster.get("runtime_version")
        if runtime_version:
            self.__config["CLUSTER_RUNTIME_VERSION"] = runtime_version
        use_photon = cluster.get("use_photon")
        if use_photon is True:
            self.__config["CLUSTER_RUN_ENGINE"] = "PHOTON"
        elif use_photon is False:
            self.__config["CLUSTER_RUN_ENGINE"] = "STANDARD"

    def __update_run_table(self, success: int, status_msg: Optional[str]) -> None:
        """Update run table."""
        sql_config = "NULL" if not self.__args else "'" + json.dumps(self.__args).replace("'", '"') + "'"
        sql_databricks_id = "NULL" if not self.databricks_id else f"'{self.databricks_id}'"
        sql_run_type = "NULL" if not self.run_type else f"'{self.run_type}'"
        sql_status_msg = "NULL" if not status_msg else "'" + status_msg.replace("'", '"') + "'"
        retry_spark_sql(
            self.__spark,
            f"""
            INSERT INTO unifai_core_job_runs (
                id, application_id, job_id, databricks_id, orchestration_id, start_time,
                end_time, run_as_of, run_type, run_user_id, configuration, status, status_message,
                job_hash, unifai_hash, notification_list
            )
            VALUES (
                '{self.run_uuid}', '{self.__application.id}', '{self.id}', {sql_databricks_id},
                '{self.orchestration_id}', CAST({self.start_time.timestamp()} AS TIMESTAMP),
                CAST({self.end_time.timestamp()} AS TIMESTAMP), '{self.run_as_of}', {sql_run_type},
                '{self.get_config().get('SYS_USER', '-unknown-')}', {sql_config}, {success}, {sql_status_msg},
                '{self.get_config()['GIT_HASH']}', '{self.get_config()['VERSION']}', NULL
            )
            """,
        )
