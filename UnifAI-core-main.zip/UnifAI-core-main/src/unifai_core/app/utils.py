"""unifai_core.app.utils module."""

import json
import re
import subprocess  # noqa: S40
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from random import randint
from subprocess import run  # noqa: S40
from typing import Any
from typing import List
from typing import Optional
from typing import Tuple
from uuid import uuid4

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.workspace import ImportFormat
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession


MINIMUM_SLEEP = 5
REQUEST_TIMEOUT = 120


def db_fs_copy(
    source_path: str, target_path: str, recursive: bool = False, overwrite: bool = False, use_cli: bool = False
) -> bool:
    """Databricks File-Store Copy File(s)."""
    try:
        if overwrite:
            db_fs_remove(target_path, True, use_cli)
        if use_cli:
            cmd = ["databricks", "fs", "cp"]
            if recursive:
                cmd.append("--recursive")
            cmd.append(source_path)
            cmd.append(target_path)
            cmd_out = run(cmd, capture_output=True)  # noqa: S607,S603
            return cmd_out.returncode == 0
        else:
            return _get_dbutils().fs.cp(source_path, target_path, recursive)
    except Exception:
        return False


def db_fs_ls(path: str, use_cli: bool = False) -> Optional[list]:
    """Databricks File-Store List Directory."""
    try:
        if use_cli:
            cmd_out = run(["databricks", "fs", "ls", clean_path(path, "dbfs:")], capture_output=True)  # noqa: S607,S603
            if cmd_out.returncode == 0:
                return cmd_out.stdout.decode("utf-8").split("\n")
            return None
        else:
            return _get_dbutils().fs.ls(clean_path(path, "dbfs:"))
    except Exception:
        return None


def db_fs_mkdir(path: str, use_cli: bool = False) -> bool:
    """Databricks File-Store Make Directory."""
    try:
        if use_cli:
            cmd_out = run(  # noqa: S607,S603
                ["databricks", "fs", "mkdirs", clean_path(path, "dbfs:")], capture_output=True
            )
            return cmd_out.returncode == 0
        else:
            return _get_dbutils().fs.mkdirs(clean_path(path, "dbfs:"))
    except Exception:
        return False


def db_fs_remove(path: str, recursive: bool = False, use_cli: bool = False) -> bool:
    """Databricks File-Store Remove File(s)."""
    try:
        if use_cli:
            cmd = ["databricks", "fs", "rm"]
            if recursive:
                cmd.append("--recursive")
            cmd.append(clean_path(path, "dbfs:"))
            cmd_out = run(cmd, capture_output=True)  # noqa: S607,S603
            return cmd_out.returncode == 0
        else:
            return _get_dbutils().fs.rm(clean_path(path, "dbfs:"), recursive)
    except Exception:
        return False


def give_users_view_permission(submit_body: dict) -> dict:
    """Add or Update submit body's access_control_list to grant `users` group VIEW permissions for jobs.

    Only updates access-control if the `users` group is not already in the access_control_list.
    """
    # Get current access control list (list of dictionaries)
    access_control_list = submit_body.get("access_control_list", [])

    # If the `users` group_name doesn't have specified permissions, add CAN_VIEW
    if not any([d for d in access_control_list if d.get("group_name") == "users"]):
        users_permission = {"group_name": "users", "permission_level": "CAN_VIEW"}
        submit_body["access_control_list"] = access_control_list + [users_permission]

    return submit_body


@contextmanager
def run_command(command: List[str]):
    """Runs the subprocess Popen command with proper context opening and closing.

    Args:
        command: CLI command that needs to be executed

    Yields:
        process instance created by subprocess.Popen
    """
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)  # noqa: S607,S603
    try:
        yield process
    finally:
        process.terminate()


def db_run_job(
    run_name: str,
    host: str,
    submit_body: dict,
    debug: bool = False,
    wait: bool = True,
    job_run_info=None,
    users_can_view: bool = True,
) -> Tuple[bool, Optional[str], Optional[str]]:
    """Databricks Run Job."""
    if users_can_view:
        # Give `users` group VIEW permissions
        submit_body = give_users_view_permission(submit_body)

    # Construct run instruction
    cmd = ["databricks", "runs", "submit", "--version", "2.1", "--json", json.dumps(submit_body)]
    if debug or wait:
        cmd.append("--wait")
        print(f"Starting '{run_name}' on Databricks: {host}#job/runs\n")
    # Retry step to catch file read error in databricks
    retries = 1
    while retries >= 0:
        with run_command(cmd) as process:
            time.sleep(2)
            run_found, job_run_url, job_id, run_id = get_job_run_link(submit_body)
            if run_found:
                print("Job run link:", job_run_url)
            _output, _ = process.communicate()
        output = _output.decode("utf-8")
        return_code = process.returncode
        # If run submit failures were due to file not found
        if "Cannot read the python file" in output:
            time.sleep(15)
            retries -= 1
        else:
            retries = -1
    # Extract debug output
    after_job_id, after_run_id = extract_job_info(_output, debug, wait, job_run_info)
    if (after_job_id and job_id != after_job_id) and (after_run_id and run_id != after_run_id):
        print(
            f"\nIt seems that you have triggered mutiple job runs with same name and parameters."
            f"Please use this job url instead of the previous one: {host}#job/{after_job_id}/run/{after_run_id}\n"
        )
    # Return the run status
    return return_code == 0, job_id, run_id


def get_job_run_link(submit_body: dict) -> Tuple[bool, Optional[str], Optional[str], Optional[str]]:
    """Get the job run URL using the submit body's run name and parameter.

    Args:
        submit_body: submit body of the databricks job run

    Returns:
        if the job run with the same submit body is found : True, job run URL, job_id, run_id
        If the job run witht he same submit body is not found : False, None, None, None
    """
    cmd = ["databricks", "runs", "list", "--output", "json"]
    output = subprocess.run(cmd, capture_output=True)  # noqa: S607,S603
    stdout = output.stdout.decode("utf-8")
    runs = json.loads(stdout)

    run_name = submit_body["run_name"]
    spark_python_task = submit_body["spark_python_task"]

    matching_run = None
    for _run in runs["runs"]:
        if _run["run_name"] == run_name and _run["task"]["spark_python_task"] == spark_python_task:
            matching_run = _run
            break

    if matching_run:
        return True, matching_run["run_page_url"], matching_run["job_id"], matching_run["run_id"]
    else:
        return False, None, None, None


def db_ws_ls(path: str) -> Optional[list]:
    """Databricks Workspace List Directory."""
    cmd_out = subprocess.run(  # noqa: S607,S603
        ["databricks", "workspace", "ls", clean_path(path)], capture_output=True
    )
    if cmd_out.returncode == 0:
        return cmd_out.stdout.decode("utf-8").split("\n")
    return None


def db_ws_mkdir(path: str) -> bool:
    """Databricks Workspace Make Directory."""
    cmd_out = subprocess.run(  # noqa: S607,S603
        ["databricks", "workspace", "mkdirs", clean_path(path)], capture_output=True
    )
    return cmd_out.returncode == 0


def db_ws_remove(path: str, recursive: bool = False) -> bool:
    """Databricks Workspace Remove File(s)."""
    cmd = ["databricks", "workspace", "rm"]
    if recursive:
        cmd.append("--recursive")
    cmd.append(clean_path(path))
    cmd_out = subprocess.run(cmd, capture_output=True)  # noqa: S607,S603
    return cmd_out.returncode == 0


def db_ws_import(content, target_path):
    """Databricks Workspace upload File."""
    wsc = WorkspaceClient()
    try:
        wsc.workspace.upload(path=clean_path(target_path), content=content, format=ImportFormat("AUTO"), overwrite=True)
    except Exception as e:
        print(f"An unexpected error occurred:{e}")


def clean_path(path: str, prefix: str = "") -> str:
    """Utility function to help keep paths consistant."""
    return prefix + re.sub(r"^\/?(dbfs|Workspace)\:?", "", path)


def find_repo(path: str) -> Tuple[str, str]:
    """Search upwards from path to find a parent git repo.

    Depends on .git existing at root of repo.

    Args:
        path: start of search

    Returns:
        Tuple of path strings split at the repo root - (repo, rest)

    Raises:
        FileNotFoundError: if no repo is found in the path
    """
    p = Path(path)

    found = False
    file_path = [p.parts[-1]]
    while len(p.parts) > 1:
        p = p.parent
        if ".git" in [peer.name for peer in p.iterdir()]:
            found = True
            break
        else:
            file_path.append(p.parts[-1])

    if not found:
        raise FileNotFoundError(f"{path} does not exits in a git repo")
    else:
        file_path.reverse()
        return str(p), str(Path(*file_path))


def get_configuration(spark, with_user: bool = False) -> dict:
    """Build up the available run-time configuration object."""
    now = datetime.now()
    result = {
        "SYS_NOW": (now.strftime("%Y-%m-%d %H:%M:%S")),
        "SYS_NOW_STR": (now.strftime("%Y%m%d%H%M%S")),
        "SYS_TODAY": (now.strftime("%Y-%m-%d")),
    }
    # Get system configuration
    for config in spark.sql("SELECT * FROM unifai_core_configuration").collect():
        # Only include if not already set
        if not result.get(config.key):
            result[config.key] = config.value
    if with_user:
        result["SYS_USER"] = spark.sql("SELECT current_user()").collect()[0][0]
    return result


def get_git_hash(repo_path: str) -> str:
    """Get the GIT hash from the Databricks repo."""
    cmd_out = subprocess.run(  # noqa: S607,S603
        ["databricks", "repos", "get", "--path", repo_path], capture_output=True
    )
    if cmd_out.returncode != 0:
        raise RuntimeError(
            f"Databricks failed to fetch repo {repo_path!r} with stdout: {cmd_out.stdout!r} and stderr: {cmd_out.stderr!r}"
        )
    # Extract git hash from output
    return json.loads(cmd_out.stdout)["head_commit_id"]


def extract_job_info(stdout: bytes, debug: bool, wait: bool, job_run_info=None) -> Tuple[Optional[str], Optional[str]]:
    """Utility function to extract run information and disply this to the user."""
    try:
        # Extract run info
        job_id = None
        matches = re.search(r'"run_id": (\d+)', str(stdout))
        run_id = "xxx" if not matches else matches.group(1)
        cmd_out = subprocess.run(  # noqa: S607,S603
            ["databricks", "runs", "get-output", "--version", "2.1", "--run-id", run_id],
            capture_output=True,
        )
        if cmd_out.returncode == 0:
            json_out = json.loads(cmd_out.stdout)
            job_id = json_out.get("metadata", {}).get("job_id", json_out.get("job_id"))
            if debug:
                # Print logging output
                if json_out.get("logs"):
                    print("\n---------- ---------- ---------- STDOUT ---------- ---------- ----------")
                    print(json_out.get("logs") + "\n")
                # Print error output and trace
                if json_out.get("error"):
                    print("\n---------- ---------- ---------- STDERR ---------- ---------- ----------")
                    print(json_out.get("error"))
                    print(json_out.get("error_trace", "") + "\n")
        return job_id, run_id
    except Exception as ex:
        # Logging : Insert error logs in metadata tables, can insert other info as well
        message = f"ERROR: Failed to extract the job run information: {ex}\n"
        from unifai_core.cli.utils import insert_into_job_runs

        if job_run_info is None:
            job_run_info = {}
        insert_into_job_runs(
            message=message,
            app_id=job_run_info.get("app_id", None),
            job_id=job_run_info.get("job_id", None),
            config=job_run_info.get("config", None),
            orchestration_id=job_run_info.get("orchestration_id", None),
        )
        print(message)
        return None, None


def retry_spark_sql(spark, sql: str, tries: int = 5, sleep: int = MINIMUM_SLEEP) -> Any:
    """Utility function to allow to retries of SQL statements to try prevent concurrent write issues."""
    counter = 0
    result = None
    success = False
    sleep = MINIMUM_SLEEP if sleep > MINIMUM_SLEEP else sleep
    while not success:
        counter += 1
        try:
            result = spark.sql(sql).collect()
            success = True
        except Exception as ex:
            if counter < tries:
                print(f"WARNING (attempt {counter}): Failed to execute SQL query: {ex}")
                time.sleep((counter * sleep) + randint(0, sleep))  # noqa: S311
            else:
                raise RuntimeError(
                    f"ERROR (attempt {counter}): Unable to execute SQL query ({sql}) after {tries} retries"
                ) from ex
    return result


def _get_dbutils():
    """Utility function to setup DBUtils."""
    return DBUtils(SparkSession.builder.getOrCreate())


def _update_databricks_table(
    spark,
    app_name: str,
    job_name: str,
    config: dict,
    job_id: Optional[str],
    run_id: Optional[str],
    job_host: Optional[str],
) -> Optional[str]:
    """Update databricks table."""
    if job_id and run_id:
        id = str(uuid4())
        link_url = f"{job_host}#job/{job_id}/run/{run_id}"
        retry_spark_sql(
            spark,
            f"""
            INSERT INTO unifai_core_databricks
                   (id, name, job_id, run_id, link_url, update_user_id, update_date_time)
            VALUES ('{id}', 'UnifAI run job - {app_name}.{job_name}', '{job_id}','{run_id}', '{link_url}',
                    '{config.get('SYS_USER', '-unknown-')}', current_timestamp())
            """,
        )
        return id
    return None


def _update_orchestration_table(
    spark, orchestration_id: Optional[str], orchestration_data: Optional[Any], config: dict
) -> Optional[str]:
    """Update orchestration table."""
    # Only write to table if required fields are provided
    data = {}
    if isinstance(orchestration_data, dict):
        data = orchestration_data
    elif isinstance(orchestration_data, str):
        data = json.loads(orchestration_data)
    if orchestration_id and data.get("job_name") and data.get("run_id"):
        try:
            row = spark.sql(
                f"""
                SELECT *
                  FROM unifai_core_orchestration
                 WHERE id = {orchestration_id!r}
                """
            ).collect()[0]

            python_parent_id = row.parent_id
        except Exception:
            sql_config = (
                "NULL"
                if not data.get("configuration")
                else "'" + json.dumps(data["configuration"]).replace("'", "`") + "'"
            )
            sql_link_url = "NULL" if not data.get("link_url") else "'" + data["link_url"] + "'"
            sql_parent_id = "NULL" if not data.get("parent_id") else "'" + data["parent_id"] + "'"
            sql_version = "NULL" if not data.get("version") else "'" + data["version"] + "'"
            retry_spark_sql(
                spark,
                f"""
                INSERT INTO unifai_core_orchestration
                       (id, name, run_id, parent_id, configuration, link_url, version, update_user_id, update_date_time)
                VALUES ('{orchestration_id}', '{data["job_name"]}', '{data["run_id"]}', {sql_parent_id},{sql_config},
                        {sql_link_url}, {sql_version}, '{config.get('SYS_USER', '-unknown-')}', current_timestamp())
                """,
            )

            python_parent_id = data.get("parent_id")
    else:
        python_parent_id = None

    return python_parent_id
