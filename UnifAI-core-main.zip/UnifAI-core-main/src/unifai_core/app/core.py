"""Core app oriented functionality."""

import json
import os
import re
import shutil
import textwrap
import traceback
from datetime import datetime
from enum import Enum
from pathlib import Path
from subprocess import run  # noqa: S40
from tempfile import mkdtemp
from time import sleep
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from uuid import uuid4

import yaml
from pyspark.sql import SparkSession

from unifai_core.app.conf import ApplicationConfiguration
from unifai_core.app.conf import JobConfiguration
from unifai_core.app.utils import _get_dbutils
from unifai_core.app.utils import _update_orchestration_table
from unifai_core.app.utils import clean_path
from unifai_core.app.utils import db_fs_copy
from unifai_core.app.utils import db_fs_ls
from unifai_core.app.utils import db_fs_remove
from unifai_core.app.utils import db_run_job
from unifai_core.app.utils import db_ws_import
from unifai_core.app.utils import db_ws_mkdir
from unifai_core.app.utils import db_ws_remove
from unifai_core.app.utils import get_configuration
from unifai_core.app.utils import retry_spark_sql
from unifai_core.cli.types import Settings
from unifai_core.cli.utils import JOB_CLUSTER_JSON
from unifai_core.cli.utils import ensure_schema
from unifai_core.cli.utils import insert_into_job_runs
from unifai_core.cli.utils import validate_cluster
from unifai_core.schema.utils import UpdateSchemaStatements
from unifai_core.utils.rerun import generate_instructions
from unifai_core.utils.rerun import get_job_details_from_id
from unifai_core.utils.rerun import get_orchestration_details_from_id


class AppDeployStrategy(Enum):
    """Enum for acceptable deployment strategy."""

    GIT = "GIT"
    WHEEL = "WHEEL"
    CONDA = "CONDA"


def deploy(
    settings: Settings,
    storage_folder: str,
    git: Optional[str],
    wheel: Optional[str],
    restart: bool = False,
    skip_upload: bool = False,
) -> None:
    """Bootstrap a UnifAI environment."""
    import unifai_core_app

    # Install UnifAI core
    blob_store_path = f"/dbfs/mnt/azureblobshare/{storage_folder}"
    file_store_path = f"/dbfs/FileStore/{storage_folder}"
    repo_path = f"/Workspace/Repos/{storage_folder}"
    init_store_path = f"/Workspace/Shared/unifai_scripts/{storage_folder}"
    version = _bootstrap_install(unifai_core_app.__path__[0], file_store_path, git, wheel)

    # Create/Update/Validate cluster details
    application = ApplicationConfiguration(
        app_path=unifai_core_app.__path__[0],
        additional_config={
            "BLOB_STORE_PATH": blob_store_path,
            "FILE_STORE_PATH": file_store_path,
            "INIT_STORE_PATH": init_store_path,
            "REPO_PATH": repo_path,
            "SCHEMA": settings["SCHEMA_NAME"],
            "VERSION": version,
        },
        merge_config=True,
    )
    _upload_init_script(application)
    cluster = validate_cluster(settings, application, restart)

    # Trigger remote UnifAI-core bootstrap
    run_name = "UnifAI Bootstrap core"
    submit_body = {
        "run_name": run_name,
        "existing_cluster_id": cluster["cluster_id"],
        "libraries": [],
        "spark_python_task": {
            "python_file": f"{clean_path(file_store_path, 'dbfs:')}/code/unifai_core/remote/bootstrap_core.py",
            "parameters": [
                "--blob-store-path",
                blob_store_path,
                "--file-store-path",
                file_store_path,
                "--init-store-path",
                init_store_path,
                "--repo-path",
                repo_path,
                "--schema",
                settings["SCHEMA_NAME"],
                "--version",
                version,
            ],
        },
    }
    # Trigger bootstrap job run
    if not db_run_job(run_name, f"{settings['DATABRICKS_HOST']}", submit_body, True)[0]:
        raise RuntimeError(f"Databricks failed to bootstrap core version: {version}")
    # Upload dependencies to Databricks
    ensure_schema(settings)
    _upload_dependencies(application, skip_upload, settings)


def _bootstrap_install(app_path: str, file_store_path: str, git: Optional[str], wheel: Optional[str]) -> str:
    """Performes the packaging of UnifAI core code and deploys this to Databricks."""
    temp_dir = mkdtemp()
    # Use provided WHEEL package
    if wheel:
        version = Path(wheel).name.split("-")[1]
        print(f"\nUploading UnifAI Core (WHEEL version: {version}) to Databricks.\n")
        cmd_out = run(  # noqa: S607,S603
            f"pwd && cp {wheel} {temp_dir} && unzip {wheel} -d {temp_dir}",
            capture_output=True,
            shell=True,
        )
        if cmd_out.returncode != 0:
            raise RuntimeError(f"Failed during the building of the UnifAI WHEEL: {cmd_out.stdout.decode('utf-8')}")

    # Prepare WHEEL from GIT repository
    elif git:
        git_url = f"https://github.com/optum-labs/unifai-core@{git}"
        cmd_out = run(  # noqa: S607,S603
            ["pip", "install", "--no-compile", "--no-deps", "-t", temp_dir, f"git+{git_url}"],
            capture_output=True,
        )
        if cmd_out.returncode != 0:
            raise RuntimeError(f"Failed during the building of the UnifAI WHEEL: {cmd_out.stdout.decode('utf-8')}")
        # Get UnifAI-core package version
        cmd_out = run(f"ls -1 {temp_dir} | grep 'dist-info'", capture_output=True, shell=True)  # noqa: S607,S603
        version = re.sub(r"(\.dist-info|\r|\n)", "", cmd_out.stdout.decode("utf-8")).split("-")[-1]
        print(f"\nUploading UnifAI Core (GIT version: {version}) to Databricks.\n")
        shutil.rmtree(f"{temp_dir}/bin")

    # Prepare WHEEL from current install
    else:
        package_path = Path(app_path).parent.absolute()
        cmd_out = run(  # noqa: S607,S603
            f"cp -r {package_path}/unifai_core* {temp_dir}",
            capture_output=True,
            shell=True,
        )
        if cmd_out.returncode == 0:
            cmd_out = run(  # noqa: S607,S603
                "pip show unifai_core | grep Version",
                capture_output=True,
                shell=True,
            )
        if cmd_out.returncode != 0:
            raise RuntimeError(f"Failed during the building of the UnifAI WHEEL: {cmd_out.stderr.decode('utf-8')}")
        version = re.sub(r"(Version:\s+|\n)", "", cmd_out.stdout.decode("utf-8"))
        print(f"\nUploading UnifAI Core (INSTALLED version: {version}) to Databricks.\n")
    # Package WHEEL (for current install or git repository)
    if not wheel:
        wheel_file = f"{temp_dir}/unifai_core-{version}-py3-none-any.whl"
        zip_file = shutil.make_archive(wheel_file, "zip", temp_dir)
        os.rename(zip_file, wheel_file)
    # Upload 'code and WHEEL' to file-store
    _push_to_dbfs(temp_dir, f"{file_store_path}/code", True)
    shutil.rmtree(temp_dir)
    return version


def _upload_init_script(application: ApplicationConfiguration) -> None:
    """If defined, this will upload the init script to Databricks."""
    if application.init_script:
        temp_dir = mkdtemp()
        init_file_path = application.parse_with_config("{INIT_STORE_PATH}")
        db_ws_mkdir(init_file_path)
        print("Uploading Cluster INIT script to Databricks.\n")
        db_ws_import(application.init_script, f"{init_file_path}/{application.name}-init.sh")
        shutil.rmtree(temp_dir)


def _clone_repo_dependency(target_dir: str, https_url: str, version: str, app_name: str) -> None:
    """Clones the git repo into a target directory given the git version, http url and app name."""
    base_dir = os.path.join(target_dir, app_name)
    tmpdir = mkdtemp()
    user = _get_dbutils().secrets.get(scope="github", key="non-user-id")
    password = _get_dbutils().secrets.get(scope="github", key="non-user-pat")
    # Appending user and password in git url
    https_url = https_url[:8] + user + ":" + password + "@" + https_url[8:]
    os.environ["GIT_USERNAME"] = str(user)
    os.environ["GIT_PASSWORD"] = str(password)
    cmd_out = run(["git", "clone", https_url], capture_output=True, cwd=tmpdir)  # noqa: S607,S603
    if cmd_out.returncode != 0:
        raise RuntimeError(f"Failed to clone repo dependency: {https_url}, {cmd_out}")

    repo = https_url.split(os.sep)[-1].split(".")[0]
    repo_dir = os.path.join(tmpdir, repo)

    cmd_out = run(["git", "checkout", version], capture_output=True, cwd=repo_dir)  # noqa: S607,S603
    if cmd_out.returncode != 0:
        raise RuntimeError(f"Failed to check out {repo} version: {version}")

    # Adding __init__ in each python module if not exist
    if not os.path.isfile(os.path.join(repo_dir, "__init__.py")):
        Path(f"{repo_dir}/__init__.py").touch()

    folder_iter = os.walk(repo_dir)
    for current_folder, _, _ in folder_iter:
        if not os.path.isfile(os.path.join(current_folder, "__init__.py")):
            with open(os.path.join(current_folder, "__init__.py"), "w") as f:
                f.write("")

    repo_dir = str(Path(repo_dir).rename(Path(tmpdir) / repo.replace("-", "_")))

    # moving to dbfs location
    os.makedirs(base_dir, exist_ok=True)
    repo_dir = os.path.join(repo_dir, "")
    base_dir = os.path.join(base_dir, "")
    cmd_out = run(["cp", "-rf", repo_dir, base_dir], capture_output=True)  # noqa: S607,S603
    if cmd_out.returncode != 0:
        print(cmd_out)
        raise RuntimeError("Failed to copy the repo !")


def _upload_dependencies(application: ApplicationConfiguration, skip_upload: bool, settings: Settings) -> None:
    """If defined, this will upload 3rd-party dependencies to Databricks."""
    if application.dependencies and not skip_upload:
        print("Downloading UnifAI Core/Application Dependencies...")
        cache_dir = f"{settings['UNIFAI_HOME']}/cache"
        if not os.path.exists(cache_dir):
            os.mkdir(cache_dir)
        temp_dir = mkdtemp()
        upload_flag = False
        for dep in application.dependencies:
            if db_fs_ls(f"{dep['target_path']}") is not None:
                print(f" Dependency -> {dep['source_url']} already installed. Skipping download.")
            else:
                upload_flag = True
                if dep.get("git_repo") is not None:
                    # git repo is getting downloaded inside the remote publish job now
                    pass
                else:
                    target_file = (
                        dep["target_path"].split("/")[-1]
                        if not dep["source_url"].endswith("zip")
                        else dep["source_url"].split("/")[-1]
                    )
                    # Download to cache directory (if not exists)
                    if not os.path.exists(f"{cache_dir}/{target_file}"):
                        print(f" * downloading -> {dep['source_url']}")
                        cmd_out = run(  # noqa: S607,S603
                            ["curl", "-kLv", dep["source_url"], "-o", target_file], capture_output=True, cwd=cache_dir
                        )
                        if cmd_out.returncode != 0:
                            raise RuntimeError(f"Failed to download dependency: {dep['source_url']}")
                    # copy cached file to temp directory
                    _copy_unpack_file(dep["source_url"], target_file, cache_dir, temp_dir)
        # Files changed trigger upload
        if upload_flag:
            print("\nUploading UnifAI Core Dependencies to Databricks.\n")
            _push_to_dbfs(temp_dir, application.parse_with_config("{FILE_STORE_PATH}/dependencies"))
        shutil.rmtree(temp_dir)


def _remote_upload_dependencies(application: ApplicationConfiguration) -> None:
    """This function directly adds dependencies on databricks without creating a temp directory in local."""
    if application.dependencies:
        print("Downloading UnifAI Core/Application Dependencies...")
        for dep in application.dependencies:
            if dep.get("git_repo") is not None:
                target_dir = application.parse_with_config("{FILE_STORE_PATH}/dependencies")
                _clone_repo_dependency(target_dir, dep["git_repo"], dep["git_version"], application.name)


def _copy_unpack_file(source_url: str, target_file: str, cache_dir: str, temp_dir: str) -> None:
    """Copy and unpack files to temp dir."""
    shutil.copyfile(f"{cache_dir}/{target_file}", f"{temp_dir}/{target_file}")
    if source_url.endswith("zip"):
        # using the zip file name as target file path name
        # target in the yaml holds the unzip folder path to be read from which will be used
        # for the dbfs cp command only
        target_file = source_url.split("/")[-1]
        zip_file_path = f"{cache_dir}/{target_file}"
        print(f"Unzipping {zip_file_path} in extract path: {temp_dir}...")
        try:
            shutil.unpack_archive(zip_file_path, temp_dir)
        except FileNotFoundError:
            print(f"The file {zip_file_path} was not found")
        except Exception as e:
            print(
                f"An unexpected error occurred attempting to unzip {target_file} in extract path: " f"{temp_dir}: {e}"
            )


def _push_to_dbfs(source_dir: str, target_path: str, cleanup: bool = False) -> None:
    """Copy files from local to DBFS."""
    db_fs_copy(source_dir, clean_path(target_path, "dbfs:"), True, cleanup, True)


def undeploy(schema: str, delete_data: bool = False) -> None:
    """Undelploys UnifAI from the environment.

    Will remove the UnifAI core app from a Databricks environment

    Args:
        schema: schema that will be deleted
        delete_data: should delete the data files
    """
    spark = SparkSession.builder.getOrCreate()
    unifai_config = get_configuration(spark)

    # Remove cloned repositories
    if unifai_config.get("REPO_PATH"):
        db_ws_remove(unifai_config["REPO_PATH"], True)

    # Remove schema and data files
    retry_spark_sql(spark, f"DROP SCHEMA {schema} CASCADE")
    if delete_data and unifai_config.get("BLOB_STORE_PATH"):
        db_fs_remove(unifai_config["BLOB_STORE_PATH"], True, True)
        db_fs_remove(unifai_config["FILE_STORE_PATH"], True, True)


def publish(
    settings: Settings,
    app_folder: str,
    git_url: str,
    version_type: str,
    version: str,
    orchestration_id: Optional[str] = None,
    orchestration_data: Optional[dict] = None,
    restart: bool = False,
    skip_upload: bool = False,
) -> None:
    """Connect a Databricks repo to a git repo and store in UnifAI environment."""
    # Load Application configuration
    spark = SparkSession.builder.getOrCreate()
    unifai_config = get_configuration(spark)

    # Create/Update repository
    file_store_path = unifai_config.get("FILE_STORE_PATH")
    repo_path = f"{unifai_config.get('REPO_PATH')}"
    clone_path = f"{repo_path}/{git_url.split('/')[-1]}_{app_folder}"
    repo_name = clone_path.split("/")[-1]
    git_hash = _update_db_repo(git_url, repo_path, repo_name, version_type, version)

    run_name = f"UnifAI Application Install/Update - {app_folder}"
    parameters: List[Any] = [
        "--repo-path",
        clone_path,
        "--app-folder",
        app_folder,
        "--git-url",
        git_url,
        "--git-hash",
        git_hash,
        "--version",
        version,
        "--schema",
        settings["SCHEMA_NAME"],
    ]
    # optionally include orchestration metadata
    if orchestration_id:
        parameters.extend(["--orchestration-id", orchestration_id])
    if orchestration_data:
        parameters.extend(["--orchestration-data", json.dumps(orchestration_data)])
    submit_body: Dict[str, Any] = {
        "run_name": run_name,
        "existing_cluster_id": settings["DATABRICKS_CLUSTER_ID"],
        "libraries": [],
        "spark_python_task": {
            "python_file": clean_path(f"{file_store_path}/code/unifai_core/remote/publish_app.py", "dbfs:"),
            "parameters": parameters,
        },
    }
    # Trigger remove job run
    if not db_run_job(run_name, f"{settings['DATABRICKS_HOST']}", submit_body, True)[0]:
        raise RuntimeError(f"Databricks failed to publish app {app_folder!r} in repo {clone_path!r} to {version}")

    application = ApplicationConfiguration(app_name=app_folder, spark=spark)
    # Create application specific cluster
    if application.use_app_cluster:
        _upload_init_script(application)
        validate_cluster(settings, application, restart)
    # Upload any application dependencies
    _upload_dependencies(application, skip_upload, settings)


def remove_app(app_name: str, delete_data: bool = False) -> None:
    """Deletes full app from UnifAI."""
    spark = SparkSession.builder.getOrCreate()
    application = ApplicationConfiguration(app_name=app_name, spark=spark)
    # Remove repository clone
    db_ws_remove(application.get("REPO_PATH"), True)

    # Remove any tables or views
    schemas = retry_spark_sql(spark, f"SELECT * FROM unifai_core_schemas WHERE application_id = {application.id!r}")
    for s in schemas:
        spark.sql(f"DROP {'VIEW' if s.type == 'view' else 'TABLE'} IF EXISTS {s.name}")

    # Remove any data files
    if delete_data:
        db_fs_remove(application.get("BLOB_STORE_PATH"), True, True)

    # Clean-up UnifAI core tables
    retry_spark_sql(spark, f"DELETE FROM unifai_core_schemas WHERE application_id = {application.id!r}")
    retry_spark_sql(spark, f"DELETE FROM unifai_core_jobs WHERE application_id = {application.id!r}")
    retry_spark_sql(spark, f"DELETE FROM unifai_core_repositories WHERE application_id = {application.id!r}")
    retry_spark_sql(spark, f"DELETE FROM unifai_core_applications WHERE id = {application.id!r}")


def list_apps() -> list:
    """Returns the list of installed UnifAI apps."""
    spark = SparkSession.builder.getOrCreate()

    return retry_spark_sql(
        spark,
        """
        SELECT a.name, a.version, r.url, a.path, a.description
          FROM unifai_core_applications a, unifai_core_repositories r
         WHERE a.id = r.application_id
        """,
    )


def list_jobs(app_name: str) -> list:
    """Returns the list of installed UnifAI jobs."""
    spark = SparkSession.builder.getOrCreate()

    return retry_spark_sql(
        spark,
        f"""
        SELECT j.name, a.version, j.class_name, CONCAT(a.path,'/src') AS path, 'tbc' AS description
          FROM unifai_core_applications a, unifai_core_jobs j, unifai_core_repositories r
         WHERE a.id = j.application_id AND a.id = r.application_id
           AND a.name = {app_name!r}
        """,
    )


def list_runs(app_name: str) -> list:
    """Returns the list of job runs."""
    spark = SparkSession.builder.getOrCreate()

    return retry_spark_sql(
        spark,
        f"""
        SELECT j.name, a.version, r.databricks_id, r.orchestration_id, r.start_time, r.end_time,
               r.run_user_id, r.status, r.status_message, r.job_hash, r.unifai_hash
          FROM unifai_core_applications a, unifai_core_jobs j, unifai_core_job_runs r
         WHERE a.id = j.application_id
           AND j.id = r.job_id
           AND a.name = {app_name!r}
        """,
    )


def list_params(app_name: str, job_name: str) -> List[Tuple[str, Any, Any, Any, Any, Any]]:
    """Returns the list of job runs."""
    spark = SparkSession.builder.getOrCreate()

    configuration = retry_spark_sql(
        spark,
        f"""
        SELECT j.*
          FROM unifai_core_applications a, unifai_core_jobs j
         WHERE a.id = j.application_id
           AND a.name = {app_name!r}
           AND j.name = {job_name!r}
        """,
    )[0].configuration
    inputs = json.loads(configuration).get("inputs", {})

    return [(job_name, k, v["type"], v["required"], v["default"], v["description"]) for k, v in inputs.items()]


def run_job(
    app_name: str,
    job_name: str,
    run_args: list,
    settings: Settings,
    orchestration_id: str,
    orchestration_data: Optional[dict] = None,
    prompt_user: bool = False,
    use_shared_cluster: bool = False,
    debug: bool = False,
    wait: bool = True,
    users_can_view: bool = True,
) -> str:
    """Prepare the Spark job definition and trigger this definition in Databricks."""
    spark = SparkSession.builder.getOrCreate()

    # Get application
    run_name = f"UnifAI Run Job - {app_name}.{job_name}"
    application = ApplicationConfiguration(app_name=app_name, spark=spark)
    # Get job
    job_args = {}
    for arg in run_args:
        k, v = arg.strip().split("=")
        job_args[k] = v

    try:
        app_id = spark.sql(
            f"""
                SELECT id FROM unifai_core_applications WHERE name = '{app_name}' LIMIT 1
                """
        ).collect()[0][0]

        job_id = spark.sql(
            f"""
                SELECT id FROM unifai_core_jobs WHERE name = '{job_name}' and
                application_id = '{app_id}' LIMIT 1
                """
        ).collect()[0][0]

        job_run_info = {
            "app_id": app_id,
            "job_id": job_id,
            "orchestration_id": orchestration_id,
            "config": application.get_config(),
        }

    except Exception as e:
        insert_into_job_runs(
            message="Unable to find JOB ID/APP ID from the given parameters",
            config=application.get_config(),
            orchestration_id=orchestration_id,
        )
        print(traceback.format_exc())
        raise RuntimeError() from e

    try:
        job = JobConfiguration(
            application=application,
            job_name=job_name,
            orchestration_id=orchestration_id,
            spark=spark,
            prompt_user=prompt_user,
            **job_args,
        )

        # Build spark job json
        submit_body = _run_job_build_json(
            job,
            run_name,
            application.get("FILE_STORE_PATH"),
            f"{settings['DATABRICKS_HOST']}",
            f"{settings['SCHEMA_NAME']}",
            orchestration_data,
        )
        _run_job_setup_cluster(job, settings, submit_body, use_shared_cluster)

    except Exception as e:
        insert_into_job_runs(
            message=e,
            app_id=app_id,
            job_id=job_id,
            config=application.get_config(),
            orchestration_id=orchestration_id,
        )
        print(traceback.format_exc())
        raise RuntimeError() from e

    # Submit Spark job
    if not db_run_job(
        run_name,
        f"{settings['DATABRICKS_HOST']}",
        submit_body,
        (debug or prompt_user),
        wait,
        job_run_info,
        users_can_view,
    )[0]:
        # Logging : Insert error logs into jo_runs table
        message = f"Databricks failed to run job {run_name}!"
        raise RuntimeError(message)

    return run_name


def rerun_job(workflow_id: str, data_as_of: Optional[str] = None) -> str:
    """Generates instructions to re-run a workflow on databricks."""
    spark = SparkSession.builder.getOrCreate()
    # fetch orchestration_data
    orchestration_data = get_orchestration_details_from_id(spark, workflow_id)
    # fetch all the unique orchestration_ids
    orchestration_ids = orchestration_data.select("id").distinct().rdd.map(lambda row: row[0]).collect()

    # fetch job details
    job_details = get_job_details_from_id(spark, orchestration_ids)

    # if data_as_of is None then use start_time instead
    # This will be passed as a paramter for JobConfiguration
    # and further used for data versioning
    if data_as_of is None:
        data_as_of = job_details.select("start_time").collect()[0][0]
        if isinstance(data_as_of, str):
            data_as_of = datetime.strptime(data_as_of, "%Y-%m-%d").strftime("%Y-%m-%d")
        else:
            data_as_of = data_as_of.strftime("%Y-%m-%d")

    # generate output
    instructions = generate_instructions(spark, workflow_id, orchestration_ids, data_as_of, job_details)

    instruction_str = " ".join(instructions)
    formatted_instruction = textwrap.dedent(instruction_str).strip()
    # formatted_instruction = textwrap.fill(formatted_instruction, width=80)
    print(formatted_instruction)
    return formatted_instruction

    # add a note at the end of instructions if any of the jobs failed and if so what was the error captured

    # placeholder to programatically create a branch based on git hash
    # do an app publish if its not part of the workflow
    # placeholder to call run_job (looping through all the jobs associated with the id)
    # placeholder to destroy the temporary git branch after jobs have finished running


def _run_job_build_json(
    job: JobConfiguration,
    run_name: str,
    file_store_path: str,
    job_host: str,
    schema: str,
    orchestration_data: Optional[dict] = None,
) -> Dict[str, Any]:
    """Build the SPARK json for the request."""
    parameters = [
        "--databricks-job-id",
        "{{job_id}}",
        "--databricks-run-id",
        "{{run_id}}",
        "--databricks-host",
        job_host,
        "--app-name",
        job.get_application().name,
        "--job-name",
        job.name,
        "--job-args",
        job.get_json_args(),
        "--orchestration-id",
        job.orchestration_id,
        "--schema",
        schema,
    ]

    # optionally include orchestration metadata
    if orchestration_data:
        parameters.extend(["--orchestration-data", json.dumps(orchestration_data)])

    return {
        "run_name": run_name,
        "libraries": [{"pypi": {"package": d}} for d in job.get_dependencies()],
        "spark_python_task": {
            "python_file": f"{clean_path(file_store_path, 'dbfs:')}/code/unifai_core/remote/run_job.py",
            "parameters": parameters,
        },
    }


def _run_job_setup_cluster(
    job: JobConfiguration,
    settings: Settings,
    submit_body: dict,
    use_shared_cluster: bool = False,
) -> None:
    """Add the cluster definition to the SPARK json."""
    application = job.get_application()
    if use_shared_cluster:
        cluster = validate_cluster(settings, application)
        submit_body["existing_cluster_id"] = cluster["cluster_id"]
    else:
        job_cluster = json.loads(job.parse_with_config(JOB_CLUSTER_JSON))
        # Update INIT script
        if application.script_path:
            job_cluster["init_scripts"] = [{"workspace": {"destination": clean_path(application.script_path)}}]
        # Update ENV variables
        if application.env_variables:
            job_cluster["spark_env_vars"] = application.env_variables
        # Update SPARK config
        if application.spark_config:
            job_cluster["spark_conf"] = {**job_cluster.get("spark_conf", {}), **application.spark_config}
        submit_body["new_cluster"] = job_cluster


def _update_db_repo(
    git_url: str, repo_path: str, repo_name: str, version_type: str = "branch", version: str = "main"
) -> str:
    """Create/Update GIT repository in Databricks."""
    # If repository not exist
    clone_path = clean_path(f"{repo_path}/{repo_name}")
    if not _does_repo_exists(clone_path):
        db_ws_mkdir(repo_path)
        api_out = run(  # noqa: S603, S607
            ["databricks", "repos", "create", "--url", git_url, "--path", clone_path],
            capture_output=True,
        )
        if api_out.returncode != 0 and not ("RESOURCE_ALREADY_EXISTS" in str(api_out.stdout)):
            raise RuntimeError(
                f"Databricks failed to create repo for {git_url!r} - {clone_path}"
                f" with stdout: {str(api_out.stdout)} and stderr: {str(api_out.stderr)}"
            )
    # Update repo to specified version
    api_out = run(  # noqa: S603, S607
        ["databricks", "repos", "update", f"--{version_type}", version, "--path", clone_path], capture_output=True
    )
    if api_out.returncode != 0:
        raise RuntimeError(
            f"Databricks failed to update repo for {git_url!r} - {clone_path}"
            f" with stdout: {str(api_out.stdout)} and stderr: {str(api_out.stderr)}"
        )

    sleep(10)  # Waiting for clone to complete in Databricks
    return json.loads(api_out.stdout)["head_commit_id"]


def _does_repo_exists(repo_path: str) -> bool:
    """Searches the databricks cli repos list api result for named repo.

    The api result is in the form of:
    {
        "repos": [{
            "id": 3327955558647898,
            "path": "/Repos/<storage_folder>/<repo_name>",
            "url": "<url to remote repo>",
            "provider": "gitHub",
            "head_commit_id": "cdfe3738c8badcb81521f8e5b3e64ad6c89eb5ee"
        }]
    }

    Args:
        repo_path: databricks path to repo

    Returns:
        true if repo exists otherwise false
    """
    api_out = run(["databricks", "repos", "list"], capture_output=True)  # noqa: S603, S607
    if api_out.returncode == 0:
        json_out = json.loads(api_out.stdout)
        for repo in json_out.get("repos", []):
            if repo.get("path") == repo_path:
                return True
    return False


def _remote_publish_app(
    spark,
    repo_path: str,
    app_folder: str,
    git_url: str,
    git_hash: str,
    orchestration_id: Optional[str],
    orchestration_data: Optional[dict],
    version: str,
    dbricks_vers: str,
) -> None:
    """Databricks job to perfrom the install/update of the application."""
    app_path = f"{repo_path}/{app_folder}"
    application = ApplicationConfiguration(
        app_path=app_path,
        additional_config={"REPO_PATH": repo_path},
        spark=spark,
        with_user=True,
    )
    # Copy Data-Quality to DBFS
    if len(application.data_quality):
        for k, v in application.data_quality.items():
            for key in v:
                db_fs_copy(
                    clean_path(application.data_quality[k][key], "file:/Workspace"),
                    clean_path(application.get("DATA_QUALITY_" + k.upper() + "_" + key.upper()), "dbfs:"),
                    True,
                    True,
                )

    sql_configuration = "'" + json.dumps(application.configuration).replace("'", "`") + "'"
    retry_spark_sql(
        spark,
        f"""
        MERGE INTO unifai_core_applications AS t
        USING (SELECT '{application.name}' AS name, '{application.description}' AS description,
                      '{app_path}' AS path, '{version}' AS version, {sql_configuration} as configuration) AS s
            ON t.path = s.path
        WHEN MATCHED THEN
            UPDATE SET name = s.name, description = s.description, version = s.version, configuration = s.configuration,
                update_user_id = current_user(), update_date_time = current_timestamp()
        WHEN NOT MATCHED THEN
            INSERT (id, name, description, path, version, configuration, update_user_id, update_date_time)
            VALUES ('{str(uuid4())}', s.name, s.description, s.path, s.version, s.configuration,
                    current_user(), current_timestamp())
        """,
        sleep=20,
    )
    # Get new application ID
    app_id = application.id
    if not app_id:
        app_id = spark.sql(f"SELECT * FROM unifai_core_applications WHERE path = '{app_path}'").collect()[0].id
    # Write all application details
    _update_schema(spark, application, git_hash, dbricks_vers, app_id)
    _update_repository(spark, app_id, repo_path, git_url, git_hash)
    _update_jobs(spark, application.path, app_id)
    # Write optional orchestration data
    _update_orchestration_table(spark, orchestration_id, orchestration_data, application.get_config())
    _remote_upload_dependencies(application)


def _update_configuration(spark, unifai_config: dict) -> None:
    # add/update configuration items
    for key, value in unifai_config.items():
        sql_value = "NULL" if not value else f"'{value}'"
        retry_spark_sql(
            spark,
            f"""
            MERGE INTO unifai_core_configuration AS t
            USING (SELECT '{key}' AS key, {sql_value} AS value) AS s
               ON t.key = s.key
             WHEN MATCHED THEN
                  UPDATE SET value = s.value, update_user_id = current_user(), update_date_time = current_timestamp()
             WHEN NOT MATCHED THEN
                  INSERT (id, key, value, update_user_id, update_date_time)
                  VALUES ('{str(uuid4())}', s.key, s.value, current_user(), current_timestamp())
            """,
            sleep=20,
        )

    # remove items no longer defined
    retry_spark_sql(
        spark,
        f"""
        DELETE FROM unifai_core_configuration
            WHERE key NOT IN ('{"','".join(unifai_config.keys())}')
        """,
    )


def _update_jobs(spark, app_path: str, app_id: int) -> None:
    active_jobs = []
    try:
        # add/update application jobs
        jobs_path = f"{app_path}/jobs"
        for p in os.listdir(jobs_path):
            if p.endswith(".yaml") or p.endswith(".yml"):
                jobs = yaml.safe_load(open(f"{jobs_path}/{p}"))
                for job, rest in jobs.items():
                    if isinstance(rest, dict):
                        # Update job summary into unifai
                        _update_job_summary(spark, job, rest, app_id)
                        active_jobs.append(job)
                    else:
                        raise RuntimeError(
                            f"Databricks failed to create/update job {job!r}. The file structure is incorrect!"
                        )

    except FileNotFoundError:
        pass  # OK - no jobs to install

    # remove jobs no longer defined
    if active_jobs:
        retry_spark_sql(
            spark,
            f"""
            DELETE FROM unifai_core_jobs
             WHERE nvl(application_id, '---') = nvl({'NULL' if not app_id else f"'{app_id}'"}, '---')
               AND name NOT IN ('{"','".join(active_jobs)}')
            """,
        )


def _update_job_summary(spark, job_name: str, result: dict, app_id: int) -> None:
    config = {
        "sys_paths": result.get("sys_paths", []),
        "dependencies": result.get("dependencies", []),
        "inputs": {},
        "cluster": result.get("cluster", {}),
    }
    class_name = result.get("class", None)
    if not class_name:
        raise RuntimeError(
            f"Databricks failed to create/update job {job_name!r}. The file structure does not contain a class name!"
        )

    inputs = result.get("inputs", {})
    for param, rest in inputs.items():
        # Support for simple input format (e.g. input_name: 'default value')
        if isinstance(rest, str):
            inputs[param] = {
                "default": rest,
                "description": "---",
                "required": False,
                "type": "STRING",
            }
        # Support for detailed input format (e.g. input_name: {default: 'some value', ...})
        elif isinstance(rest, dict):
            inputs[param] = {
                "default": rest.get("default", None),
                "description": rest.get("description", "---"),
                "required": rest.get("required", False),
                "type": rest.get("type", "STRING"),
            }
        else:
            raise RuntimeError(
                f"Databricks failed to create/update job {job_name!r}."
                f" The file structure does not contain a valid input definition {param!r}!"
            )
    # update inputs into config
    config["inputs"] = inputs

    sql_app_id = "NULL" if not app_id else f"'{app_id}'"
    sql_config = "NULL" if not config else f"'{json.dumps(config)}'"
    retry_spark_sql(
        spark,
        f"""
        MERGE INTO unifai_core_jobs AS t
        USING (SELECT {sql_app_id} AS application_id, '{job_name}' AS name, '{class_name}' AS class_name,
                {sql_config} AS configuration, {(0 if config else 0)} AS status) AS s
            ON nvl(t.application_id, '---') = nvl(s.application_id, '---') and t.name = s.name
        WHEN MATCHED THEN
            UPDATE SET class_name = s.class_name, configuration = s.configuration, status = s.status,
                    update_user_id = current_user(), update_date_time = current_timestamp()
        WHEN NOT MATCHED THEN
            INSERT (id, application_id, name, class_name, configuration, status, update_user_id, update_date_time)
            VALUES ('{str(uuid4())}', s.application_id, s.name, s.class_name, s.configuration, s.status,
                    current_user(), current_timestamp())
        """,
        sleep=20,
    )


def _update_repository(spark, app_id: str, repo_path: str, git_url: str, git_hash: str) -> None:
    retry_spark_sql(
        spark,
        f"""
        MERGE INTO unifai_core_repositories AS t
        USING (SELECT '{app_id}' AS application_id, '{repo_path}' AS path,
                      '{git_hash}' AS hash, '{git_url}' AS url) AS s
              ON t.application_id = s.application_id and t.path = s.path
        WHEN MATCHED THEN
             UPDATE SET hash = s.hash, url = s.url, update_user_id = current_user(),
             update_date_time = current_timestamp()
        WHEN NOT MATCHED THEN
             INSERT (id, application_id, path, hash, url, update_user_id, update_date_time)
             VALUES ('{str(uuid4())}', s.application_id, s.path, s.hash, s.url, current_user(), current_timestamp())
        """,
        sleep=20,
    )


def _update_schema(
    spark, application: ApplicationConfiguration, version: str, dbricks_vers: str, app_id: Optional[str] = None
) -> None:
    blob_store_path = clean_path(application.get("BLOB_STORE_PATH"))
    # Generate schema
    active_schemas, error_msgs = _update_schema_generate(
        spark, application.path, blob_store_path, version, dbricks_vers, app_id
    )
    # Update schema summary into UnifAI
    _update_schema_summary(spark, active_schemas, version, app_id)
    # Remove schemas no longer defined
    _update_schema_remove(spark, list(active_schemas.keys()), blob_store_path, app_id)
    # Throw exception back to process
    if error_msgs:
        raise RuntimeError(f"Databricks failed to create/update schema :: {error_msgs}")


def _update_schema_generate(
    spark, app_path: str, blob_store_path: str, version: str, dbricks_vers: str, app_id: Optional[str] = None
) -> Tuple[dict, Optional[str]]:
    active_schemas: Dict[str, Optional[Any]] = {}
    error_msgs = None
    schema_path = f"{app_path}/schema"
    try:
        for p in os.listdir(schema_path):
            if p.endswith(".yaml") or p.endswith(".yml"):
                statements = UpdateSchemaStatements(
                    f"{schema_path}/{p}", blob_store_path, version, dbricks_vers, app_id
                )
                for name, list_sql in statements:
                    try:
                        # Execute create/alter table statement
                        for sql in list_sql:
                            retry_spark_sql(spark, sql)
                        active_schemas[name] = statements.get_schema_details(name)
                    except RuntimeError as ex1:
                        active_schemas[name] = None
                        error_msgs = "" if not error_msgs else f"{error_msgs} / "
                        error_msgs += f"Error: file={p} table={name} reason={ex1}"
    except Exception as ex2:
        print(f"Warning: {ex2}")
    # return
    return (active_schemas, error_msgs)


def _update_schema_remove(spark, tables_list: List[str], blob_store_path: str, app_id: Optional[str] = None) -> None:
    """Update schemas to remove deprecated elements."""
    # Find any deprecated schema elements
    old_tables = retry_spark_sql(
        spark,
        f"""
        SELECT *
          FROM unifai_core_schemas
         WHERE nvl(application_id, '---') = nvl({'NULL' if not app_id else f"'{app_id}'"}, '---')
           AND name NOT IN ('{"','".join(tables_list)}')
        """,
    )
    # Remove tables/views from schema
    for t in old_tables:
        retry_spark_sql(spark, f"DROP {'VIEW' if t.type == 'view' else 'TABLE'} IF EXISTS {t.name}")
        retry_spark_sql(spark, f"DELETE FROM unifai_core_schemas WHERE id = '{t.id}'")
        db_fs_remove(f"{blob_store_path}/{t.name}", True, True)


def _update_schema_summary(spark, result: dict, version: str, app_id: Optional[str] = None) -> None:
    for name, config in result.items():
        sql_app_id = "NULL" if not app_id else f"'{app_id}'"
        sql_config = "NULL" if not config else f"'{json.dumps(config)}'"
        sql_type = "unknown" if not config else config.get("type", "unknown")
        retry_spark_sql(
            spark,
            f"""
            MERGE INTO unifai_core_schemas AS t
            USING (SELECT {sql_app_id} AS application_id, '{name}' AS name, {sql_config} AS configuration,
                  {(0 if config else 1)} AS status, '{sql_type}' AS type) AS s
                ON nvl(t.application_id, '---') = nvl(s.application_id, '---') and t.name = s.name
                AND t.name = '{name}'
                AND nvl(t.application_id, "NULL") = {sql_app_id}
            WHEN MATCHED AND t.version != '{version}' THEN
                UPDATE SET configuration = s.configuration, status = s.status, type = s.type, version = '{version}',
                           update_user_id = current_user(), update_date_time = current_timestamp()
            WHEN NOT MATCHED THEN
                INSERT (id, application_id, name, configuration, status, type, version,
                        update_user_id, update_date_time)
                VALUES ('{str(uuid4())}', s.application_id, s.name, s.configuration, s.status, s.type, '{version}',
                        current_user(), current_timestamp())
            """,
            sleep=20,
        )


def load_artifacts_yaml(artifacts_file_path) -> dict:
    """Loading artifacts from yaml file."""
    with open(artifacts_file_path) as f:
        configuration = yaml.safe_load(f)
    return configuration
