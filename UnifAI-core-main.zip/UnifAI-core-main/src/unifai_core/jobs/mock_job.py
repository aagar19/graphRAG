"""Unifai Core Mock Job utility."""

import sys
from datetime import datetime
from importlib import import_module

from unifai_core.app.conf import ApplicationConfiguration
from unifai_core.app.conf import JobConfiguration
from unifai_core.jobs.legacy_adapter import SysPath


class UnifaiMockJob:
    """Unifai Core Job utility to enable creation of interactive mock job instances."""

    def _get_most_recent_orchestration(self, spark, job_name, app_name, schema=None):
        if schema is None:
            schema = spark.catalog.currentDatabase()

        # Get orchestration_id of most recent (successful) job run, if it exists
        orchestration = spark.sql(
            f"""
                SELECT jr.orchestration_id FROM {schema}.unifai_core_job_runs jr
                INNER JOIN {schema}.unifai_core_jobs j
                    ON jr.job_id = j.id
                INNER JOIN {schema}.unifai_core_applications a
                    ON j.application_id = a.id
                WHERE j.name = '{job_name}' and a.name = '{app_name}'
                    AND jr.status = 0
                ORDER BY jr.start_time DESC
                LIMIT 1
            """
        ).collect()
        if orchestration == []:
            return None
        else:
            return orchestration[0][0]

    def _build_configurations(self, spark, job_name, app_name, orchestration_id=None):
        # Remove `unifai_` from app_name
        if app_name.startswith("unifai_"):
            app_name = app_name[len("unifai_") :]

        # Get orchestration_id, if not provided
        if orchestration_id is None:
            orchestration_id = self._get_most_recent_orchestration(spark, job_name, app_name)

        # Create JobConfiguration
        app = ApplicationConfiguration(app_name=app_name, spark=spark)
        job = JobConfiguration(application=app, job_name=job_name, orchestration_id=orchestration_id, spark=spark)

        # Get orchestration's run-as-of, if it exists
        job.run_as_of = self._orchestration_run_as_of(spark, orchestration_id)

        # Return
        return app, job

    def _load_class(self, app_path, job_name, job_class_name, job_sys_paths, leave_on_syspath):
        if leave_on_syspath:
            for path in job_sys_paths + [f"{app_path}/src"]:
                sys.path.append(path)
            job_class = getattr(import_module(job_name), job_class_name)
        else:
            with SysPath(*(job_sys_paths + [f"{app_path}/src"])):
                job_class = getattr(import_module(job_name), job_class_name)
        return job_class

    def _orchestration_run_as_of(self, spark, orchestration_id, schema=None):
        if schema is None:
            schema = spark.catalog.currentDatabase()
        run_as_of = spark.sql(
            f"""
                SELECT run_as_of FROM {schema}.unifai_core_job_runs
                WHERE orchestration_id = '{orchestration_id}'
                ORDER BY start_time DESC
                LIMIT 1
            """
        ).collect()
        if run_as_of == [] or run_as_of is None:
            return datetime.now()
        else:
            return run_as_of[0][0]

    def mock_job_instance(self, spark, job_name, app_name, orchestration_id=None, leave_on_syspath=False):
        """Method to create mock job instance with mock values, with & without a previous run/orchestration id."""
        # Create ApplicationConfiguration and JobConfiguration instance
        app, job = self._build_configurations(spark, job_name, app_name, orchestration_id)

        # Add mock values (we're not doing metadata insert!)
        job.job_id = "MOCK"  # Databricks job_id
        job.run_id = "MOCK"  # Databricks run_id
        job.run_uuid = "MOCK"  # Job-run id
        job.start_time = datetime.now()

        # Get job class
        job_class = self._load_class(app.path, job.name, job.class_name, job.sys_paths, leave_on_syspath)

        return job_class(spark, job)
