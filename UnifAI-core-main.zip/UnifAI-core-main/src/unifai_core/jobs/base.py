"""Unifai Core Job base class."""

import warnings
from typing import Any
from typing import Optional

from pandas import DataFrame as PandasDataFrame
from pyspark.sql import DataFrame
from pyspark.sql.functions import broadcast
from pyspark.sql.functions import col
from pyspark.sql.functions import concat_ws
from pyspark.sql.functions import expr
from pyspark.sql.functions import lit
from pyspark.sql.functions import to_date
from pyspark.sql.types import StringType

from unifai_core.app.conf import JobConfiguration
from unifai_core.utils.delta_schemas import has_schema_mismatches
from unifai_core.utils.delta_schemas import update_dataframe_to_match_existing
from unifai_core.utils.output_store import format_data
from unifai_core.utils.output_store import pivot_columns
from unifai_core.utils.output_store import select_columns
from unifai_core.utils.parser import update_run_args
from unifai_core.utils.rerun import get_version_from_timestamp
from unifai_core.utils.rerun import load_from_current_version


class UnifaiJob:
    """UnifaiJob base class is used to wrap around out job model runs."""

    def __init__(self, spark, job: JobConfiguration) -> None:
        """Initialize the base class."""
        self.__application = job.get_application()
        self.__job = job
        self.__spark = spark

        self.__config = self.__job.get_config()
        self.__inputs = self.__job.get_inputs()

        self.job_id = self.__job.job_id
        self.run_id = self.__job.run_id
        self.run_uuid = self.__job.run_uuid
        self.orchestration_id = self.__job.orchestration_id
        self.parent_id = self.__job.parent_id

        self.app_name = self.__application.name
        self.app_path = self.__application.path
        self.job_name = self.__job.name
        self.repo_path = self.get("REPO_PATH")
        self.sys_user = self.get("SYS_USER", "-unknown-")

        self.start_time = self.__job.start_time
        self.data_as_of = self.__job.data_as_of
        self.run_as_of = self.__job.run_as_of
        self.run_type = self.__job.run_type

        # Depricated property (support v0.2 jobs)
        self.job = {
            "id": self.__job.id,
            "name": self.__job.name,
            "configuration": self.__config,
            "current_user": self.sys_user,
        }

    def run(self, **kwargs) -> None:
        """Main run function."""
        # Pre-check job configuration
        job_args = update_run_args(
            job_name=self.job_name,
            job_config=self.get_config(),
            inputs=self.__inputs,
            **{
                **kwargs,
                **{"data_as_of": self.data_as_of, "run_as_of": self.run_as_of, "run_type": self.run_type},
            },
        )
        # Custom job pre-checker
        self.custom_pre_checker(**job_args)
        # Execute
        self.execute(spark=self.__spark, **job_args)

    # Custom Job Pre-Checker: (optional) override this to provide custom config checks
    def custom_pre_checker(self, **kwargs) -> None:
        """Check to ensure all required params are provided."""
        pass

    # Job Execution: required to provide and override for this method
    def execute(self, spark, **kwargs) -> None:
        """(optional) extension point to do additional config checks."""
        raise RuntimeError(f"Failed to run {self.app_name}.{self.job_name}. No execution function provided!")

    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """Returns configuration value based on the passed in key, or return the default."""
        return self.__config.get(key, default)

    def get_config(self) -> dict:
        """Returns all configuration releated to the current job."""
        return self.__config

    def add_bulk_output(self, calculation_name: str, data: DataFrame) -> None:
        """Function for adding bulk_outputs to the output store.

        Args:
          calculation_name (str): The name of the calculation.
          data (DataFrame): The data provided to the output store. This dataframe should hold data on columns
          (run_as_of, data_link_value, data_link_type and calculation_value).
        """
        output_store = self.__spark.table("unifai_core_model_output_store")

        # todo: attempt to clean up any data which exists for the partition

        # Read existing schema cols in unifai_core_model_output_store into a list
        schema_cols = [field.name for field in output_store.schema.fields]

        # Only consider columns in data dict if column value exists in output schema (i.e. remove cols we don't need)
        data = data.select([column for column in data.columns if column in schema_cols])

        # Consolidate dataframe
        data = (
            data.withColumn("calculation_name", lit(calculation_name))
            .withColumn("calculation_value", col("calculation_value").cast(StringType()))
            .withColumn("calculation_datatype", lit(dict(data.dtypes)["calculation_value"]))
            .withColumn("run_id", lit(self.run_uuid))
            .withColumn("repository_name", lit(str(self.repo_path).split("/")[-1]))
            .withColumn("application_name", lit(self.app_name))
            .withColumn("job_name", lit(self.job_name))
            .withColumn("orchestration_id", lit(self.orchestration_id))
            .withColumn("run_type", lit(self.run_type))
        )

        # Write dataframe to output_store
        data.write.format("delta").mode("append").saveAsTable("unifai_core_model_output_store")

    def add_multi_bulk_output(self, calc_column_mappings: dict, data_link_columns: list, data: DataFrame) -> None:
        """Function for adding bulk_outputs to the output store.

        Args:
          calc_column_mappings (dict): A dict mapping calculation_name label to calculation data column
                                e.g, { 'pharmacy-catageory': 'PHARMACY_CAT' } where 'PHARMACY_CAT' is a column in the
                                "data" DataFrame.
          data (DataFrame): The data provided to the output store. This dataframe should hold model output data on
                                respective data columns for the values in the column_mappings dict
                                 e.g, data should have data column(s) 'PHARMACY_CAT' as per above example.
                                And optionally, the run_as_of date, otherwise it will use UnifaiJob object run_as_of
                                to populate this column.
          data_link_columns (list):  List of columns (in order) to concatenate for `data_link_value` in output store
                                e.g., ['UNIQ_MBR_ID', 'ENTY_ID'] --> 'UNIQ_MBR_ID|ENTY_ID'.

        """
        output_store = self.__spark.table("unifai_core_model_output_store")

        # Read existing schema cols in unifai_core_model_output_store into a list
        schema_cols = [field.name for field in output_store.schema.fields]

        # Convert to spark dataframe, if pandas
        if isinstance(data, PandasDataFrame):
            data = self.__spark.createDataFrame(data)

        # Adding data_link value and type
        data = data.withColumn(
            "data_link_value", concat_ws("|", *[expr(f'COALESCE({c}, "")') for c in data_link_columns])
        )
        data = data.withColumn("data_link_type", lit("|".join(data_link_columns)))

        # Write data to table for each calculation grouping
        for calculation_name, calculation_col in calc_column_mappings.items():
            # Consolidate dataframe
            result = data
            result = (
                result.withColumn("calculation_name", lit(calculation_name))
                .withColumn("calculation_value", col(calculation_col).cast(StringType()))
                .withColumn("calculation_datatype", lit(dict(result.dtypes)[calculation_col]))
                .withColumn("repository_name", lit(str(self.repo_path).split("/")[-1]))
                .withColumn("application_name", lit(self.app_name))
                .withColumn("job_name", lit(self.job_name))
            )
            # If missing unifai data colummns (not provided in the dataframe)
            if "orchestration_id" not in result.columns:
                result = result.withColumn("orchestration_id", lit(self.orchestration_id))
            if "run_as_of" not in result.columns:
                result = result.withColumn("run_as_of", to_date(lit(self.run_as_of)))
            if "run_type" not in result.columns:
                result = result.withColumn("run_type", lit(self.run_type))
            if "run_id" not in result.columns:
                result = result.withColumn("run_id", lit(self.run_uuid))
            # Only consider columns in result dict if column value exists in output schema (i.e. exclude cols we don't need)
            result = result.select([column for column in result.columns if column in schema_cols])
            # Write dataframe to output_store
            result.write.format("delta").mode("append").saveAsTable("unifai_core_model_output_store")

    def load_from_output_store(self, calc_column_mappings: dict, unifai_extra_col_exprs: dict) -> DataFrame:
        """Load data from the unifai_core_model_output store into a legacy/new format.

        This function allows mapping and pivoting existing calculation_name and calculation_values in the
        unifai_core_model_output store to a legacy/new column name. The keys in the calc_column_mappings dict are
        existing row values in the unifai_core_model_output_store's calculation_name column, and the value is a new
        column name in the returned spark DataFrame.

        Args:
            calc_column_mappings: Mapping of UnifAI calculation name to legacy/new calculation name
            unifai_extra_col_exprs: Extra UnifAI specific columns to include in the returned DataFrame. You can optionally
                                    retrieve the run_id, run_as_of, orchestration_id, repository_name, application_name,
                                    or job_name from the unifai_core_model_output_store table through the following
                                    format, for example, {"orchestration_id": "orchestration_id"}. You can also include
                                    a SQL expression on any of these columns, for example, {"ANCHOR_MOYR":
                                    "CAST(DATE_FORMAT(run_as_of, "yyyyMM") AS STRING)"}.

        Returns:
            A spark DataFrame based on the unifai_core_model_output_store table, pivoted on the calc_column_mapping key
            values, split on the data_link_value, and formatted such that each value in the calc_column_mapping dict is
            now a column in the DataFrame.
        """
        # Filter data in output store based on UnifAI job run's orchestration_id or parent_id
        output_store_df = self.load_table(spark=self.__spark, tablename="unifai_core_model_output_store")

        # Check if all keys in calc_column_mappings are present in the calculation_name column
        calculation_names = output_store_df.select("calculation_name").distinct().rdd.map(lambda row: row[0]).collect()
        missing_keys = [key for key in calc_column_mappings.keys() if key not in calculation_names]

        if missing_keys:
            missing_columns = [calc_column_mappings[key] for key in missing_keys]
            print(
                f"Warning: The following keys provided in calc_column_mappings are not present in the calculation_name "
                f" column {', '.join(missing_keys)}. These will result in columns with all null values: "
                f"{', '.join(missing_columns)}."
            )

        selected_column_df = select_columns(df=output_store_df, extra_columns=unifai_extra_col_exprs)
        pivoted_df = pivot_columns(df=selected_column_df, target_columns=list(calc_column_mappings.keys()))
        updated_df = format_data(df=pivoted_df, calculation_column_mappings=calc_column_mappings)
        return updated_df

    def add_unifai_columns(self, df, target_columns):
        """Add docstring."""
        missing_columns = set(target_columns) - set(df.columns)
        if "orchestration_id" in missing_columns:
            df = df.withColumn("orchestration_id", lit(self.orchestration_id))
        if "run_as_of" in missing_columns:
            df = df.withColumn("run_as_of", to_date(lit(self.run_as_of)))
        if "run_type" in missing_columns:
            df = df.withColumn("run_type", lit(self.run_type))
        if "run_id" in missing_columns:
            df = df.withColumn("run_id", lit(self.run_uuid))

        return df

    def is_allow_empty(self, spark, table: str) -> bool:
        """Checks if the table has allow_empty flag true or false."""
        allow_empty_str = (
            spark.sql(
                f"""
            show TBLPROPERTIES {table} ("unifai.allow_empty")
        """
            )
            .collect()[0]
            .value
        )

        if (allow_empty_str).lower() == "true":
            return True
        else:
            return False

    def write_table(
        self, spark, df: DataFrame, tablename: str, mode: str = "overwrite", update_to_match_schema: bool = False
    ) -> None:
        """Writes dataframe to table, and adds `run_id` and `run_as_of` columns."""
        print(f"Attempting to write data to table: '{tablename}'")
        # Convert to spark dataframe, if pandas
        if isinstance(df, PandasDataFrame):
            df = spark.createDataFrame(df)

        # Get existing table information
        existing_data = spark.table(tablename)

        # Add missing UnifAI columns
        df = self.add_unifai_columns(df, existing_data.columns)

        # Update dataframe to match schema, if appropriate
        non_matching = has_schema_mismatches(df, existing_data)

        # Allow extra columns and column datatype conversions in `df` based on update_to_match_schema flag
        if non_matching and update_to_match_schema:
            df = update_dataframe_to_match_existing(df, existing_data)

        if non_matching and not update_to_match_schema:
            print(
                "Skipping logic to fill empty columns as null and cast mismatch column "
                "datatypes to allowed conversions. If you would like this to happen, set "
                f"'update_to_match_schema: true' in the path_to_table_mapping.yaml for table: '{tablename}'"
            )

        orchestration_info = ""

        # Get write mode
        if "orchestration_id" in existing_data.columns:
            mode = "append"
            orchestration_info = f"(orchestration_id: {self.orchestration_id})"

        try:
            if not self.is_allow_empty(spark, tablename) and (len(df.head(1)) == 0):
                raise Exception(f"Empty dataframe is not allowed for this table : {tablename}.")
            else:
                df.select(*existing_data.columns).write.mode(mode).saveAsTable(tablename)
                print(f"Successfully wrote data to table: '{tablename}' " + orchestration_info)
        except Exception as e:
            raise RuntimeError(f"Unable to process query with error: {e}") from e

    def load_table(self, spark, tablename: str) -> DataFrame:
        """Loads table."""
        existing = spark.table(tablename)
        column_order = existing.columns
        if "orchestration_id" in column_order and self.orchestration_id:
            print(f"Attempting to read data from table: '{tablename}' (orchestration_id: {self.orchestration_id})")
            orchestration_data = existing.filter(f"orchestration_id='{self.orchestration_id}'")
            if len(orchestration_data.head(1)):
                print(f"Successfully read data from table: '{tablename}' (orchestration_id: {self.orchestration_id})")
                return orchestration_data
            else:
                print(
                    f"Table: '{tablename}' has no data partitioned on (orchestration_id: {self.orchestration_id}).\n"
                    f"Attempting to read data based on orchestration_id's parent_id"
                )
                # Get all orchestration_ids associated with parent_id
                parent_orchestrations = spark.sql(
                    f"""
                        SELECT id AS orchestration_id FROM unifai_core_orchestration o
                        INNER JOIN (
                            SELECT parent_id FROM unifai_core_orchestration
                            WHERE id = '{self.orchestration_id}'
                        ) subset
                        ON o.parent_id = subset.parent_id
                    """
                )

                parent_orchestration_ids = None
                try:
                    # Retrieve list of parent's orchestration_ids
                    parent_orchestration_ids = parent_orchestrations.rdd.map(lambda x: x.orchestration_id).collect()
                    print(
                        f"Attempting to read data from table: '{tablename}' parent (orchestration_id: "
                        f"{parent_orchestration_ids})"
                    )
                except Exception as e:
                    print(f"Unable to convert {parent_orchestrations} Spark DataFrame to a list with error: {e}")

                parent_data = existing.join(broadcast(parent_orchestrations), on="orchestration_id", how="inner")
                if len(parent_data.head(1)):
                    print(
                        f"Successfully read data from table: '{tablename}' parent (orchestration_id: "
                        f"{parent_orchestration_ids})"
                    )
                    return parent_data
                else:
                    if not self.is_allow_empty(spark, tablename):
                        warnings.warn(
                            f"Encountered empty dataframe for table '{tablename}' where "
                            f"orchestration_id={self.orchestration_id} or parent "
                            f"orchestration_ids={parent_orchestration_ids}",
                            stacklevel=2,
                        )
                    else:
                        print(
                            f"Encountered empty dataframe for table '{tablename}' where "
                            f"orchestration_id={self.orchestration_id} or parent "
                            f"orchestration_ids={parent_orchestration_ids}"
                        )
        else:
            # if the table does not have orchestration_id and is one of our input tables then check
            # if we need to fetch version history based on data_as_of
            print(f"Fetching data from {tablename} as of {self.data_as_of}")
            if load_from_current_version(self.data_as_of):
                # do nothing as we have already have data from current version
                pass
            else:
                # query the table with the right version
                version = get_version_from_timestamp(spark, self.data_as_of, tablename)
                existing = spark.sql(f"SELECT * FROM {tablename} VERSION AS OF {version}")
        return existing

    def load_prospective_scores(self, orchestration_ids: DataFrame, risk_band_col_mapping: dict):
        """Load prediction scores for multiple run_as_of dates.

        Args:
            orchestration_ids: list of all orchestration ids to fetch prospective scores from in pyspark DF.
            risk_band_col_mapping: mapping of the output column.

        Returns:
            DF containing scores for all given orchestration ids.
        """
        output_df = self.__spark.sql("SELECT * FROM unifai_core_model_output_store")
        output_df = output_df.join(
            broadcast(orchestration_ids), output_df.orchestration_id == orchestration_ids.id, "inner"
        )
        unifai_extra_col_exprs = {"run_as_of": "run_as_of", "prospective_orchestration_id": "orchestration_id"}
        selected_column_df = select_columns(df=output_df, extra_columns=unifai_extra_col_exprs)
        pivoted_df = pivot_columns(df=selected_column_df, target_columns=list(risk_band_col_mapping.keys()))
        updated_df = format_data(df=pivoted_df, calculation_column_mappings=risk_band_col_mapping)

        return updated_df

    def save_prospective_labels(self, labels: DataFrame, id_columns: tuple, target_ids: DataFrame):
        """Writes the labels generated for prospective scores in unifai_core_prospective_labels table.

        Args:
            labels: Generated Labels DF.
            id_columns: combination(s) of id columns to identify the member.
            target_ids: member ids.
        """
        output_labels_df = labels.join(target_ids, on=list(id_columns), how="inner")
        output_labels_df = output_labels_df.withColumn("id", expr("uuid()"))
        output_labels_df = output_labels_df.withColumn("application_name", lit(self.app_name))
        output_labels_df = output_labels_df.withColumn(
            "data_link_value", concat_ws("|", *[expr(f'COALESCE({c}, "")') for c in id_columns])
        )
        output_labels_df = output_labels_df.withColumn("data_link_type", lit("|".join(id_columns)))
        output_labels_df = output_labels_df.withColumn("run_id", lit(self.run_id))
        self.write_table(self.__spark, df=output_labels_df, tablename="unifai_core_prospective_labels", mode="append")


class UnifaiMlflowJob(UnifaiJob):
    """Mlflow job class to support mlflow model registry transactions from unifai job."""

    def load_xgb_model(self, spark, model_name=None, version=None):
        """Method to load xgb model.

        Args:
          spark: Spark session.
          model_name: Name of  the registered mlflow model.
          version: Specific version to be loaded from mlfow registry.

        Return:
          mlflow xgb model object.

        """
        import mlflow  # type: ignore
        from mlflow.tracking.client import MlflowClient  # type: ignore

        if model_name is None:
            app_details = spark.sql(
                f"SELECT * FROM unifai_core_applications WHERE name = '{self.job['app_name']}'"
            ).collect()[0]
            app_id = app_details.id
            row = spark.sql(
                f"select model_name, mlflow_latest_version from unifai_core_mlflow_models where app_id='{app_id}'"
            ).collect()[0]
            model_name = row[0]
            version = row[1]

        if version is not None:
            pass
        else:
            print(f"No Model Version : Fetching latest version for the model {model_name}")
            client = MlflowClient()
            latest_version_info = client.get_latest_versions(model_name)
            version = latest_version_info[0].version
            print(f"The latest version of the model '{model_name}' is '{version}'.")

        model_xgb = mlflow.xgboost.load_model(f"models:/{model_name}/{version}")
        return model_xgb

    def register_mlflow_model(self):
        """TODO Future scope."""
        pass
