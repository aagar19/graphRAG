"""UnifAI Core Job class, supporting legacy (pre-UnifAI) pipelines.

Includes support for path-to-table adapter, mock-config structure.
Additionally includes a StubClass which does nothing (used in place of pipeline custom classes,
    and SysPath context manager used to insert paths into sys.path for imports from/in legacy pipeline.
"""

import os
import sys
from types import TracebackType
from typing import Any
from typing import Dict
from typing import Optional
from typing import Type

import yaml

from unifai_core.app.conf import JobConfiguration
from unifai_core.jobs.base import UnifaiJob
from unifai_core.legacy_adapters.config_utils import replace_templates
from unifai_core.legacy_adapters.path_adapter import DataIO


class UnifaiLegacyAdapterJob(UnifaiJob):
    """UnifAI Job class which supports legacy pipelines."""

    def __init__(self, spark, job: JobConfiguration, table_mappings: Optional[dict] = None) -> None:
        """Initialize the adapter class."""
        super().__init__(spark, job)
        self.spark = spark
        self.schema = self.spark.catalog.currentDatabase()
        self.add_sys_path = SysPath
        self.stub_class = StubClass()
        self.table_mappings = table_mappings

    def _add_schema(self, mapping: Dict[str, Optional[Any]]):
        """Adds `schema` key (value=self.schema) to dictionary if it does not yet exists."""
        for _, value in mapping.items():
            if isinstance(value, dict):
                if "table" in value and "schema" not in value:
                    value["schema"] = self.schema
                else:
                    self._add_schema(value)

    def _load_app_yaml(self, path: str):
        """Loads a YAML file from a path relative to the app's base directory."""
        yaml_path = os.path.join(self.app_path, path)
        # If not found, try without `/Workspace` prefix
        if not os.path.exists(yaml_path) and self.app_path.startswith("/Workspace"):
            yaml_path = os.path.join(self.app_path.replace("/Workspace", ""), path)
        if os.path.exists(yaml_path):
            with open(yaml_path) as f:
                template = yaml.safe_load(f)
            return template
        elif self.table_mappings:
            return self.table_mappings
        else:
            raise FileNotFoundError(f"No such file or directory: {yaml_path}")

    def _load_table_mapping_template(self):
        """Loads config/path_to_table_mapping.yaml file relative to the app's base directory."""
        mapping = self._load_app_yaml("configs/path_to_table_mapping.yaml")
        replace_templates(mapping, unifai_schema=self.schema)
        self._add_schema(mapping)
        return mapping

    def data_adapter(self, **schema_kwargs):
        """Initializes DataIO object with spark, table mappings, and the current job instance (`self`)."""
        return DataIO(self.spark, self.table_mapping(**schema_kwargs), self)

    def pipeline_config(self, **template_kwargs):
        """Loads the mimicking pipeline config template and updates placeholders with run configuration values."""
        config_template = self._load_app_yaml("configs/config_template.yaml")
        # Add Job app path to templates (non-Job run specific)
        templates = {"APP_PATH": self.app_path, "REPO_PATH": self.repo_path, **template_kwargs}
        return replace_templates(config_template, **templates)

    def table_mapping(self, **schema_kwargs):
        """Loads the path-to-table mapping and updates placeholders with run schema values."""
        mapping_template = self._load_table_mapping_template()
        return replace_templates(mapping_template, **schema_kwargs)


class StubClass:
    """A class which does nothing.

    Used in legacy pipelines to replace existing classes providing functionality otherwise replaced by UnifAI.
    """

    def __getattr__(self, item):
        """Returns self, for any attribute."""
        return self

    def __call__(self, *args, **kwargs):
        """Returns self, for any instance call."""
        return self


class SysPath:
    """Context manager for sys.path hacks. Inserts path on entry, and removes path on exit."""

    def __init__(self, *paths):
        """Initializes SysPath."""
        self.__paths = paths

    def __enter__(self):
        """Inserts path into sys.path."""
        for p in self.__paths:
            sys.path.insert(0, p)

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]] = None,
        exc_value: Optional[BaseException] = None,
        exc_tb: Optional[TracebackType] = None,
    ) -> bool:
        """Removes path from sys.path."""
        try:
            for p in self.__paths:
                sys.path.remove(p)
        except ValueError:
            pass
        # Return true if there was no process exception
        return exc_value is None
