"""Module to transfer data from unifai metastore to snowflake."""
