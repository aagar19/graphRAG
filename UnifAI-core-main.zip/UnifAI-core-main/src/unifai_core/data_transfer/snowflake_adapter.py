"""Module to provide the SnowflakeAdapter class."""

from pyspark.dbutils import DBUtils


class SnowflakeAdapter:
    """Class to provide a simple interface for running snowflake queries."""

    def __init__(self, spark, schema):
        """Initializer for SnowflakeAdapter.

        Usage: SnowflakeAdapter(spark, schema)
         - spark: a SparkSession
         - schema: a string specifying which Snowflake schema to run queries
                   against
        """
        self.spark = spark
        self.dbutils = DBUtils(self.spark)
        self.snowflake_configs = {
            "sfUrl": "uhg-optumcare.east-us-2.azure.snowflakecomputing.com",
            "sfUser": "oea_oh_admin@optum.com",
            "sfDatabase": "OCDP_PRD_OCUDX_HCE_DB",
            "sfSchema": schema,
            "sfWarehouse": "OCDP_PRD_OCUDX_QUERY_WH",
            "sfRole": "AR_PRD_OEA_OH_ADMIN_OPTUM_ROLE",
            "pem_private_key": self.dbutils.secrets.get(scope="snowflake", key="sf_rsa_key"),
        }

    def run_query(self, query):
        """Runs a query on Snowflake.

        Argument:
         - query: a string containing the query

        Returns:
         - A loaded spark dataframe
        """
        print(f"Executing query on snowflake: {query}")
        return (
            self.spark.read.format("snowflake")
            .options(**self.snowflake_configs)
            .option("query", query)
            .load()
            .collect()
        )
