"""Transfer data from unifai metastore to snowflake."""

import argparse

from unifai_core.data_transfer.snowflake_adapter import SnowflakeAdapter


# Table dictionary to map related input and output keys for querying
table_dict = {
    "unifai_core_job_runs": {"input_key": "id", "output_key": "id"},
    "unifai_core_jobs": {"input_key": "application_id", "output_key": "application_id"},
    "unifai_core_applications": {"input_key": "application_id", "output_key": "id"},
    "unifai_core_databricks": {"input_key": "databricks_id", "output_key": "id"},
    "unifai_core_model_output_store": {"input_key": "orchestration_id", "output_key": "orchestration_id"},
    "unifai_core_model_calculation": {"input_key": "orchestration_id", "output_key": "orchestration_id"},
    "unifai_core_orchestration": {"input_key": "orchestration_id", "output_key": "id"},
}


def validate_parent_id(spark, schema: str, parent_id: str) -> bool:
    """Function to validate if parent id exists in unifai_core_orchestration or not.

    Returns -> parent id
    """
    matching_records = spark.sql(f"SELECT * FROM {schema}.unifai_core_orchestration WHERE parent_id = '{parent_id}'")
    if matching_records.count() >= 1:
        print("Valid Parent id")
    else:
        raise ValueError(f"Parent id {parent_id} is invalid. Check your parent id.")
    return True


def validate_schema(spark, schema):
    """Function to check if schema exists in databricks workspace.

    Returns -> schema
    """
    if schema not in [database[0] for database in spark.catalog.listDatabases()]:
        raise Exception("Schema name invalid. Please enter schema name that exists in spark catalog.")
    else:
        print("Schema exists in spark unity catalog")
    return schema


def validate_orchestration_id(spark, schema, id):
    """Function to validate if orchestration id exists in unifai_core_orchestration or not.

    Returns -> Orchestration id
    """
    matching_records = spark.sql(f"SELECT * FROM {schema}.unifai_core_orchestration WHERE id = '{id}'")
    if matching_records.count() >= 1:
        print("Valid orchestration id")
    else:
        raise ValueError(f"Orchestration id {id} is invalid. Check your orchestration id.")
    return id


def validate_table_name(spark, schema, table_list):
    """Function to validate if table exists in schema.

    Returns -> Tables list
    """
    known_tables = [row.tableName for row in spark.sql(f"show tables in {schema}").select("tableName").collect()]
    missing_tables = set(table_list) - set(known_tables)
    if any(missing_tables):
        raise ValueError(f"Invalid table names: {','.join(missing_tables)}. Please provide correct table name.")
    return table_list


def extract_orchestration_ids(spark, schema, parent_id):
    """Function to extract all orchestration ids associated with a parent id in unifai_core_orchestration.

    Returns -> list of orchestration ids
    """
    matching_records = spark.sql(
        f"SELECT id FROM {schema}.unifai_core_orchestration WHERE parent_id = '{parent_id}'"
    ).collect()
    ids = [id[0] for id in matching_records]
    return list(set(ids))


def reporting_data_transfer(
    schema_name, tables, snowflake_schema_name, skip_existing=True, orchestration_id=None, parent_id=None
):
    """Function to tranfer data to snowflake schema and tables through orchestration id.

    Will skip writes to unifai_core_applications and unifai_core_jobs if the
    application/job already exist in snowflake

    Returns -> None
    """
    print("Validating your inputs. Please wait.....")
    from pyspark.dbutils import DBUtils
    from pyspark.sql import SparkSession

    spark = SparkSession.builder.getOrCreate()
    dbutils = DBUtils(spark)

    # Snowflake config dictionary to establish connection
    snowflake_dict = {
        "snowflake_connection": {
            "sfUrl": "uhg-optumcare.east-us-2.azure.snowflakecomputing.com",
            "sfUser": "oea_oh_admin@optum.com",
            "sfDatabase": "OCDP_PRD_OCUDX_HCE_DB",
            "sfSchema": f"{snowflake_schema_name}",
            "sfWarehouse": "OCDP_PRD_OCUDX_QUERY_WH",
            "sfRole": "AR_PRD_OEA_OH_ADMIN_OPTUM_ROLE",
            "pem_private_key": dbutils.secrets.get(scope="snowflake", key="sf_rsa_key"),
        }
    }
    table_list = tables.split(",")
    validate_table_name(spark, schema_name, table_list)
    # Check if Input is Parent ID or Orchestration ID
    if parent_id and validate_parent_id(spark, schema_name, parent_id):
        orchestration_ids = extract_orchestration_ids(spark, schema_name, parent_id)
    elif orchestration_id:
        validate_orchestration_id(spark, schema_name, orchestration_id)
        orchestration_ids = [orchestration_id]
    else:
        raise RuntimeError("Out of orchestration id and parent id, provide at least 1")

    for orchestration_id in orchestration_ids:
        for table in table_list:
            # Select targetted column name from input table as it will be primary key for input table.
            targeted_column = table_dict[table]["input_key"]

            # Select targetted id for input table as it will be used for filtering of data from table.
            target_id = spark.sql(
                f"SELECT {targeted_column} FROM {schema_name}.unifai_core_job_runs where orchestration_id='{orchestration_id}'"
            ).collect()
            ids = {targeted_column[0] for targeted_column in target_id}
            for id_value in ids:
                print(f"Targeted column id for table: {table} is {targeted_column} and value is", id_value)

                # Other tables has a direct association with unifai_core_job_runs table in UnifAI metastore.
                query = f"SELECT * FROM {schema_name}.{table} where {table_dict[table]['output_key']}='{id_value}'"

                # Dataframe to be appended into the output schema and table
                df = spark.sql(query)

                snowflake = SnowflakeAdapter(spark, snowflake_schema_name)
                should_write_to_snowflake = df.count() != 0

                # Check if the data exists for applications and jobs table in snowflake
                if skip_existing and str(table) in ("unifai_core_applications", "unifai_core_jobs"):
                    snowflake_count = snowflake.run_query(
                        f"SELECT COUNT(*) AS C FROM {table} WHERE {table_dict[table]['output_key']}='{id_value}'"
                    )[0]["C"]
                    should_write_to_snowflake = should_write_to_snowflake and snowflake_count == 0

                # Write the data to snowflake based on the should_write_to_snowflake flag
                if should_write_to_snowflake:
                    # df.write.mode("append").format("delta").saveAsTable(f"{snowflake_dict['snowflake_connection']['sfSchema']}.{table}")
                    df.write.mode("append").format("snowflake").options(
                        **snowflake_dict["snowflake_connection"]
                    ).option("dbtable", table).option("column_mapping", "name").save()
                else:
                    print(f"Nothing to write for this orchestration id for {table} table")
            print(
                f"Data Transfer execution completed successfully for {table} table, for {orchestration_id} orchestration_id"
            )
        print(f"Data Transfer execution completed successfully for {orchestration_id} orchestration_id")


if __name__ == "__main__":
    """Transfer data to snowflake."""
    parser = argparse.ArgumentParser(description="Data Transfer to snowflake")
    parser.add_argument("schema")
    parser.add_argument("table_values")
    parser.add_argument(
        "--orchestration_id",
        dest="orchestration_id",
        default=None,
        type=lambda x: None if x in ["", "null", "none", None] else x,
    )
    parser.add_argument(
        "--parent_id", dest="parent_id", default=None, type=lambda x: None if x in ["", "null", "none", None] else x
    )
    parser.add_argument("--snowflake_schema", dest="snowflake_schema")
    parser.add_argument("--skip-if-exists", dest="skip_existing", action="store_true", default=True)
    parser.add_argument("--no-skip-if-exists", dest="skip_existing", action="store_false")
    args = parser.parse_known_args()[0]
    # orchestration_id = None if args.orchestration_id == "null" else args.orchestration_id
    # parent_id = None if args.parent_id == "null" else args.parent_id
    reporting_data_transfer(
        args.schema, args.table_values, args.snowflake_schema, args.skip_existing, args.orchestration_id, args.parent_id
    )
