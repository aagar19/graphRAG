"""Module for triggering the snowflake uniqueness check."""

import json
from subprocess import run  # noqa: S404

from pyspark.sql import SparkSession

from unifai_core.app.utils import clean_path
from unifai_core.app.utils import retry_spark_sql


def trigger_snowflake_uniqueness_check(snowflake_schema, settings):
    """Function to trigger the uniqueness check as a spark submit job."""
    spark = SparkSession.builder.getOrCreate()

    schema_name = settings["SCHEMA_NAME"]

    file_store_path = retry_spark_sql(
        spark,
        f"""
        SELECT *
          FROM {schema_name}.unifai_core_configuration
         WHERE key='FILE_STORE_PATH'
        """,
    )[0].value

    run_name = "Checking uniqueness"
    submit_body = {
        "run_name": run_name,
        "existing_cluster_id": settings["DATABRICKS_CLUSTER_ID"],
        "spark_python_task": {
            "python_file": f"{clean_path(file_store_path, 'dbfs:')}/code/unifai_core/data_transfer/uniqueness_check.py",
            "parameters": [
                snowflake_schema,
            ],
        },
    }

    print(f"\nStarting '{run_name}' on databricks cluster: {settings['DATABRICKS_HOST']}#job/runs\n")
    api_out = run(  # noqa: S607,S603
        ["databricks", "runs", "submit", "--wait", "--json", json.dumps(submit_body)],
        capture_output=True,
    )
    if api_out.returncode == 1:
        raise RuntimeError("Duplicate data detected!")
    elif api_out.returncode != 0:
        raise RuntimeError(
            f"Databricks failed to run the uniqueness check"
            f" with stdout: {api_out.stdout!r} and stderr: {api_out.stderr!r}"
        )

    stdout = json.loads(api_out.stdout)
    databricks_run_id = stdout["run_id"]
    print(f"{run_name} job has completed successfully successfully. Spark submit job run id is : {databricks_run_id}")
