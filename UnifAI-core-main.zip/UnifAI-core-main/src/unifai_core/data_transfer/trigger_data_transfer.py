"""Job triggering related to data transfer."""

import json
from subprocess import run  # noqa: S404

from pyspark.sql import SparkSession

from unifai_core.app.utils import clean_path
from unifai_core.app.utils import retry_spark_sql
from unifai_core.data_transfer.reporting_data_transfer import validate_schema


def trigger_data_transfer(
    orchestration_id, parent_id, schema_name, table_name, snowflake_schema, skip_existing_flag, settings
):
    """Function to trigger a spark submit job to insert the data into content check and metadata tables."""
    spark = SparkSession.builder.getOrCreate()

    validate_schema(spark, schema_name)

    file_store_path = retry_spark_sql(
        spark,
        f"""
        SELECT *
          FROM {schema_name}.unifai_core_configuration
         WHERE key='FILE_STORE_PATH'
        """,
    )[0].value

    skip_existing_cli = "--skip-if-exists" if skip_existing_flag else "--no-skip-if-exists"
    print("orch ", orchestration_id)
    print("parent ", parent_id)
    run_name = "Reporting data transfer"
    submit_body = {
        "run_name": run_name,
        "existing_cluster_id": settings["DATABRICKS_CLUSTER_ID"],
        "spark_python_task": {
            "python_file": f"{clean_path(file_store_path, 'dbfs:')}/code/unifai_core/data_transfer/reporting_data_transfer.py",
            "parameters": [
                schema_name,
                table_name,
                "--orchestration_id",
                "null" if not orchestration_id else orchestration_id,
                "--parent_id",
                "null" if not parent_id else parent_id,
                "--snowflake_schema",
                snowflake_schema,
                skip_existing_cli,
            ],
        },
    }

    print(f"\nStarting '{run_name}' on databricks cluster: {settings['DATABRICKS_HOST']}#job/runs\n")
    api_out = run(  # noqa: S607,S603
        ["databricks", "runs", "submit", "--wait", "--json", json.dumps(submit_body)],
        capture_output=True,
    )
    if api_out.returncode != 0:
        raise RuntimeError(
            f"Databricks failed to transfer data for reporting"
            f" with stdout: {api_out.stdout!r} and stderr: {api_out.stderr!r}"
        )

    stdout = json.loads(api_out.stdout)
    databricks_run_id = stdout["run_id"]
    print(f"{run_name} job has completed successfully successfully. Spark submit job run id is : {databricks_run_id}")
