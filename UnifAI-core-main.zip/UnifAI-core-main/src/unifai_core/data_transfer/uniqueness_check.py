"""Checks uniqueness of data in Snowflake."""

import argparse
import sys

from unifai_core.data_transfer.snowflake_adapter import SnowflakeAdapter


uniqueness_queries = {
    "unifai_core_applications": """
            SELECT
                id,
                COUNT(*)
            FROM
                unifai_core_applications
            GROUP BY id
            HAVING COUNT(*) > 1
        """,
    "unifai_core_jobs": """
            SELECT
                id,
                COUNT(*)
            FROM
                unifai_core_jobs
            GROUP BY id
            HAVING COUNT(*) > 1
        """,
    "unifai_core_job_runs": """
            SELECT
                id,
                COUNT(*)
            FROM
                unifai_core_job_runs
            GROUP BY id
            HAVING COUNT(*) > 1
        """,
    "unifai_core_model_output_store": """
            SELECT
                data_link_value,
                run_as_of,
                calculation_name,
                run_id,
                COUNT(*)
            FROM
                unifai_core_model_output_store
            GROUP BY data_link_value, run_as_of, calculation_name, run_id
            HAVING COUNT(*) > 1
        """,
}


def check_uniqueness(snowflake_schema):
    """Function to check uniqueness of data in snowflake.

    Checks unifai_core_applications, unifai_core_jobs, unifai_core_job_runs,
    and unifai_core_model_output_store for data which may have been copied
    over twice.

    Argument:
     - snowflake_schema: a string containing the snowflake schema to check

    Returns:
     - True/False, where True indicates duplicate data was found
    """
    from pyspark.sql import SparkSession

    spark = SparkSession.builder.getOrCreate()

    snowflake = SnowflakeAdapter(spark, snowflake_schema)

    duplicates_found = False
    for table, query in uniqueness_queries.items():
        query_result = snowflake.run_query(query)
        if len(query_result) > 0:
            print(f"Found duplicates in table {table}:")
            print(query_result)
            duplicates_found = True
        else:
            print(f"Found no duplicates in table {table}")

    return duplicates_found


if __name__ == "__main__":
    """Run the uniqueness check."""
    parser = argparse.ArgumentParser(description="Data Transfer to snowflake")
    parser.add_argument("snowflake_schema")
    args = parser.parse_known_args()[0]
    duplicates_exist = check_uniqueness(args.snowflake_schema)

    if duplicates_exist:
        sys.exit(1)
