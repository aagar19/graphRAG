"""Functionality for registering an existing model into MLflow."""

import json
import os
import pickle  # noqa: S403
from datetime import datetime
from subprocess import run  # noqa: S404

from pyspark.sql import SparkSession

from unifai_core.app.conf import ApplicationConfiguration
from unifai_core.mlflow.utils import _update_mlflow_models
from unifai_core.mlflow.utils import _update_mlflow_runs


def register_model(app_name: str, settings):
    """Main Function to fetch all metadata details and triggers a spark submit job to register an MLflow model.

    Args:
        app_name: Application name to extract model path
        settings: contains databricks host id, cluster id and schema name

    Raises:
        RuntimeError: if fetching of data fails from metadata tables
    """
    try:
        spark = SparkSession.builder.getOrCreate()
        application = ApplicationConfiguration(app_name=app_name, spark=spark)
        app_location = application.path
        if app_location[0] != "/":
            app_location = application.path[1:]
        model_location = application.get("MLFLOW_MODEL_PATH")
        if model_location[0] == "/":
            model_location = model_location[1:]

        trigger_job(
            os.path.join(app_location, model_location),
            application.get("MLFLOW_ARTIFACT_PATH"),
            application.get("MLFLOW_MODEL_NAME"),
            application.get("MLFLOW_MODEL_FLAVOR"),
            settings,
            app_name,
        )

    except Exception as e:
        raise RuntimeError("Error while fetching the data from metadata tables : ", e) from e


def trigger_job(model_path: str, artifact_path: str, model_name: str, flavor: str, settings, app_name) -> None:
    """Triggers a spark submit job to register a model."""
    run_name = f"UnifAI Core Register {model_name} in MLflow"
    tags = ["MLflow", "model_register"]
    start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    spark = SparkSession.builder.getOrCreate()

    repo = spark.sql(
        """
        SELECT *
          FROM unifai_core_repositories
         WHERE application_id IS NULL
        """
    ).collect()[0]
    submit_body = {
        "run_name": run_name,
        "tags": tags,
        "existing_cluster_id": settings["DATABRICKS_CLUSTER_ID"],
        "libraries": [],
        "spark_python_task": {
            "python_file": f"{repo.path}/src/unifai_core/remote/register_model_mlflow.py",
            "parameters": [
                "--run-name",
                run_name,
                "--model-path",
                model_path,
                "--artifact-path",
                artifact_path,
                "--model-name",
                model_name,
                "--flavor",
                flavor,
                "--databricks-job-id",
                "{{job_id}}",
                "--databricks-run-id",
                "{{run_id}}",
                "--databricks-host",
                settings["DATABRICKS_HOST"],
                "--app-name",
                app_name,
                "--start-time",
                start_time,
                "--unifai-core-path",
                f"{repo.path}/src",
                "--schema",
                settings["SCHEMA_NAME"],
            ],
        },
    }

    print(f"\nStarting '{run_name}' on databricks cluster: {settings['DATABRICKS_HOST']}#job/runs\n")
    api_out = run(  # noqa: S607,S603
        ["databricks", "runs", "submit", "--wait", "--json", json.dumps(submit_body)],
        capture_output=True,
    )
    if api_out.returncode != 0:
        raise RuntimeError(
            f"Databricks failed to insert the data for content check run"
            f" with stdout: {api_out.stdout!r} and stderr: {api_out.stderr!r}"
        )

    stdout = json.loads(api_out.stdout)
    databricks_run_id = stdout["run_id"]
    print(f"{run_name} job has completed successfully successfully. Spark submit job run id is : {databricks_run_id}")


def _register_model(
    experiment_name, run_name: str, model_path: str, artifact_path: str, model_name: str, flavor: str = "xgboost"
):
    """Register a model in MLflow.

    Args:
        experiment_name: Experiment name for mlflow
        run_name: Name of the MLflow run
        model_path: path of the model file
        artifact_path: location in dbfs where all artifacts of model will be stored
        model_name: Name of model to be registered
        flavor: flavor of the model according to MLflow norms

    Returns:
        run: mlflow run object
        status: 0 if function executed without errors 1 otherwise
        status_message: Exception message

    Raises:
        Flavor not defined exception
    """
    import mlflow  # type: ignore

    try:
        mlflow.set_experiment(experiment_name)
        with mlflow.start_run(run_name=run_name) as run:
            with open(model_path, "rb") as f:
                model = pickle.load(f)  # noqa: S301

            # Log the xgboost model
            if flavor == "xgboost":
                mlflow.xgboost.log_model(xgb_model=model, artifact_path=artifact_path, registered_model_name=model_name)
            elif flavor == "sklearn":
                mlflow.sklearn.log_model(sk_model=model, artifact_path=artifact_path, registered_model_name=model_name)
            else:
                raise Exception("Other flavors are not supported yet !")

        return run, 0, None
    except Exception as ex:
        return None, 1, f"{ex}"


def _insert_metadata(
    spark,
    run_details,
    job_status,
    job_status_message,
    args,
    databricks_id,
    experiment_name,
    job_run_id,
    orchestration_id,
):
    """Inserts into UnifAI core MLflow metadata tables."""
    from mlflow.tracking.client import MlflowClient  # type: ignore

    configuration = {"app_name": args.app_name}
    unifai_hash = spark.sql("SELECT value FROM unifai_core_configuration WHERE key = 'VERSION'").collect()[0][0]
    app_details = spark.sql(f"SELECT * FROM unifai_core_applications WHERE name = '{args.app_name}'").collect()[0]
    app_id = app_details.id
    app_hash = spark.sql(f"select hash from unifai_core_repositories where application_id = '{app_id}'").collect()[0][0]

    run_dict = {
        "job_run_id": job_run_id,
        "databricks_id": databricks_id,
        "orchestration_id": orchestration_id,
        "mlflow_run_id": run_details.info.run_id if run_details is not None else None,
        "mlflow_run_name": run_details.info.run_name if run_details is not None else None,
        "experiment_id": run_details.info.experiment_id if run_details is not None else None,
        "experiment_name": experiment_name,
        "start_time": args.start_time,
        "configuration": json.dumps(configuration),
        "job_status": job_status,
        "job_status_message": job_status_message,
        "app_hash": app_hash,
        "unifai_hash": unifai_hash,
    }
    model_run_id = _update_mlflow_runs(spark, run_dict)

    if job_status == 0 and run_details is not None:
        client = MlflowClient()
        latest_version_info = client.get_latest_versions(args.model_name)
        model_dict = {
            "app_id": app_id,
            "model_name": args.model_name,
            "description": latest_version_info[0].description,
            "latest_version": latest_version_info[0].version,
            "tags": json.dumps(latest_version_info[0].tags),
            "stage": latest_version_info[0].current_stage,
            "artifact_uri": run_details.info.artifact_uri,
            "last_used": None,
        }
        _update_mlflow_models(spark, model_run_id, model_dict)
