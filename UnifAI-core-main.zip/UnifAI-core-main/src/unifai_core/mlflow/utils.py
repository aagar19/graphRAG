"""Utility functions for mlflow module."""

from uuid import uuid4

from unifai_core.app.utils import retry_spark_sql


def _update_mlflow_runs(spark, run_dict):
    """Inserts into UnifAI core mlflow runs table."""
    id = uuid4()
    insert_sql = f"""
            MERGE INTO unifai_core_mlflow_runs AS t
            USING (SELECT '{id}' AS id) AS s ON t.id = s.id WHEN NOT MATCHED THEN
                INSERT (id, job_run_id, databricks_id, orchestration_id,  mlflow_run_id, mlflow_run_name, experiment_id,
                 experiment_name, start_time, end_time, run_user_id, run_as_of, configuration, job_status,
                 job_status_message, app_hash, unifai_hash)
                VALUES
                ('{id}',
                '{run_dict['job_run_id']}',
                '{run_dict['databricks_id']}',
                '{run_dict['orchestration_id']}',
                '{run_dict['mlflow_run_id']}',
                '{run_dict['mlflow_run_name']}',
                '{run_dict['experiment_id']}',
                '{run_dict['experiment_name']}',
                '{run_dict['start_time']}',
                 current_timestamp(),
                 current_user(),
                 current_timestamp(),
                '{run_dict['configuration']}',
                '{run_dict['job_status']}',
                '{run_dict['job_status_message']}',
                '{run_dict['app_hash']}',
                '{run_dict['unifai_hash']}')
            """
    retry_spark_sql(spark, insert_sql, sleep=20)
    return id


def _update_mlflow_models(spark, model_run_id, model_dict):
    """Inserts into UnifAI core mlflow models table."""
    id = uuid4()
    insert_sql = f"""
            MERGE INTO unifai_core_mlflow_models AS t
            USING (SELECT '{id}' AS id) AS s ON t.id = s.id WHEN NOT MATCHED THEN
                INSERT (id, app_id, model_run_id, model_name, description, latest_version, tags, stage, artifact_uri, last_used)
                VALUES
                ('{id}',
                '{model_dict['app_id']}',
                '{model_run_id}',
                '{model_dict['model_name']}',
                '{model_dict['description']}',
                '{model_dict['latest_version']}',
                '{model_dict['tags']}',
                '{model_dict['stage']}',
                '{model_dict['artifact_uri']}',
                '{model_dict['last_used']}')
            """
    retry_spark_sql(spark, insert_sql, sleep=20)
