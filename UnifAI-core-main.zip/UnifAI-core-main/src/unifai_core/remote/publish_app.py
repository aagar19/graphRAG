"""Cluster wrapper for app install CLI command."""

import argparse
import json
import os


if __name__ == "__main__":
    """Execute Databricks install/update application."""
    parser = argparse.ArgumentParser(description="Run install/update application from cluster")
    parser.add_argument("--repo-path", dest="repo_path")
    parser.add_argument("--app-folder", dest="app_folder")
    parser.add_argument("--git-url", dest="git_url")
    parser.add_argument("--git-hash", dest="git_hash")
    parser.add_argument("--orchestration-id", dest="orchestration_id")
    parser.add_argument("--orchestration-data", dest="orchestration_data")
    parser.add_argument("--version", dest="version")
    parser.add_argument("--schema", dest="schema")

    args = parser.parse_known_args()[0]

    from pyspark.sql import SparkSession

    spark = SparkSession.builder.getOrCreate()
    spark.sql(f"USE {args.schema}")

    from unifai_core.app.core import _remote_publish_app

    dbricks_vers = os.environ.get("DATABRICKS_RUNTIME_VERSION", "-unknown-")
    _remote_publish_app(
        spark,
        args.repo_path,
        args.app_folder,
        args.git_url,
        args.git_hash,
        args.orchestration_id,
        (None if not args.orchestration_data else json.loads(f"{args.orchestration_data}")),
        args.version,
        dbricks_vers,
    )
