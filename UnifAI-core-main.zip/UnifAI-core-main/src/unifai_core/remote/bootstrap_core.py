"""Cluster wrapper for bootstrap core CLI command."""

import argparse
import os


if __name__ == "__main__":
    """Execute Databricks bootstrap core."""
    parser = argparse.ArgumentParser(description="Run UnifAI-core bootstrap from cluster")
    parser.add_argument("--blob-store-path", dest="blob_store_path")
    parser.add_argument("--file-store-path", dest="file_store_path")
    parser.add_argument("--init-store-path", dest="init_store_path")
    parser.add_argument("--repo-path", dest="repo_path")
    parser.add_argument("--schema", dest="schema")
    parser.add_argument("--version", dest="version")

    args = parser.parse_known_args()[0]

    from pyspark.sql import SparkSession

    spark = SparkSession.builder.getOrCreate()
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {args.schema}")
    spark.sql(f"USE {args.schema}")

    import unifai_core_app
    from unifai_core.app.conf import ApplicationConfiguration
    from unifai_core.app.core import _update_configuration
    from unifai_core.app.core import _update_schema

    application = ApplicationConfiguration(
        app_path=unifai_core_app.__path__[0],
        additional_config={
            "BLOB_STORE_PATH": args.blob_store_path,
            "FILE_STORE_PATH": args.file_store_path,
            "INIT_STORE_PATH": args.init_store_path,
            "REPO_PATH": args.repo_path,
            "SCHEMA": args.schema,
            "VERSION": args.version,
        },
        merge_config=True,
        with_user=True,
    )
    # Create/Update unifai-core schema and populate with setup
    dbricks_vers = os.environ.get("DATABRICKS_RUNTIME_VERSION", "-unknown-")
    _update_schema(spark, application, args.version, dbricks_vers)
    _update_configuration(spark, application.get_app_config())
