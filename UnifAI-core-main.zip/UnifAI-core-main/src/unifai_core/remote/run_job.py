"""Cluster wrapper for running a job via the CLI command."""

import argparse
import json
import sys
from importlib import import_module
from typing import Any
from typing import Dict

from pyspark.sql import SparkSession

from unifai_core.app.conf import ApplicationConfiguration
from unifai_core.app.conf import JobConfiguration
from unifai_core.jobs.legacy_adapter import SysPath


if __name__ == "__main__":
    """Execute Databricks job runner."""

    parser = argparse.ArgumentParser(description="Run a job from cluster")
    parser.add_argument("--databricks-job-id", dest="databricks_job_id")
    parser.add_argument("--databricks-run-id", dest="databricks_run_id")
    parser.add_argument("--databricks-host", dest="databricks_host")
    parser.add_argument("--app-name", dest="app_name")
    parser.add_argument("--job-name", dest="job_name")
    parser.add_argument("--job-args", dest="job_args")
    parser.add_argument("--orchestration-id", dest="orchestration_id")
    parser.add_argument("--orchestration-data", dest="orchestration_data")
    parser.add_argument("--schema", dest="schema")
    args = parser.parse_known_args()[0]

    spark = SparkSession.builder.getOrCreate()
    spark.sql(f"USE {args.schema}")

    # Get job args
    job_args: Dict[str, Any] = json.loads(args.job_args)
    # Leave as string (handeled in models) -- TODO: come back and fix this
    # if job_args.get("data_as_of"):
    #     job_args["data_as_of"] = datetime.strptime(f"{job_args.get('data_as_of')}", "%Y-%m-%d")
    # if job_args.get("run_as_of"):
    #     job_args["run_as_of"] = datetime.strptime(f"{job_args.get('run_as_of')}", "%Y-%m-%d")

    # Get application/job information
    application = ApplicationConfiguration(app_name=args.app_name, spark=spark, with_user=True)
    job = JobConfiguration(
        application=application, job_name=args.job_name, orchestration_id=args.orchestration_id, spark=spark, **job_args
    )
    with SysPath(*(job.sys_paths + [f"{application.path}/src"])):
        try:
            # Logging Job Started
            job.start_job(
                job_id=args.databricks_job_id,
                run_id=args.databricks_run_id,
                job_host=args.databricks_host,
                orchestration_data=args.orchestration_data,
            )
            # Load and Run Job Class
            cls = getattr(import_module(job.name), job.class_name)
            if cls is None:
                raise ValueError(f"Failed to load the expected job class ({job.name!r}, {job.class_name!r})")
            cls(spark, job).run(**job.get_args())
            # Logging Job Ended (success)
            success, status_msg = job.end_job()
        except Exception as ex:
            # Logging Job Ended (failed)
            success, status_msg = job.end_job(type(ex), ex, sys.exc_info()[2])

    if success != 0:
        raise RuntimeError(
            f"Error: {status_msg}\n"
            f"Databricks job run ({application.name}.{job.name}) failed to complete successfully!"
            f" with uuid={job.run_uuid} / databricks-job-id={args.databricks_job_id}"
            f" / databricks-run-id={args.databricks_run_id}"
        )
