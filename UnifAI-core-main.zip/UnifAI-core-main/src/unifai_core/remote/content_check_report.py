"""Cluster wrapper for content check data insert."""

import argparse
import json
import os
from datetime import datetime
from uuid import uuid4

import pandas as pd
import yaml
from jinja2 import Template
from pyspark.sql import SparkSession
from yaml.loader import SafeLoader

from unifai_core.app.conf import ApplicationConfiguration
from unifai_core.app.utils import _update_databricks_table
from unifai_core.app.utils import _update_orchestration_table
from unifai_core.app.utils import clean_path
from unifai_core.data_quality.utils import _update_dataset_summary
from unifai_core.data_quality.utils import _update_results
from unifai_core.data_quality.utils import _update_runs
from unifai_core.data_quality.utils import _update_summary


def fetch_output_path(config_location, extra_args):
    """Fetches the result csv path."""
    sinks_path = os.path.join(config_location, "sinks.yaml")
    env_path = os.path.join(config_location, "env.yaml")
    with open(env_path) as f:
        env_vars = yaml.load(f, Loader=SafeLoader)["context"]
    if extra_args:
        env_vars.update(**{f"{v.split('=')[0]}": f"{v.split('=')[1]}" for v in (extra_args.split(","))})
    template = open(sinks_path).read()
    j2_template = Template(template)
    output = yaml.safe_load(j2_template.render(env_vars))
    for item in output["sinks"]:
        if item["type"] == "file":
            return clean_path(item["properties"]["path"], "/dbfs")
    raise ValueError("Could not find output path in sink")


if __name__ == "__main__":
    """Inserts Data into Content Check Tables."""
    parser = argparse.ArgumentParser(description="Inserts data into content check tables")
    parser.add_argument("--app-name", dest="app_name")
    parser.add_argument("--start-time", dest="start_time")
    parser.add_argument("--end-time", dest="end_time")
    parser.add_argument("--databricks-host", dest="databricks_host")
    parser.add_argument("--databricks-job-id", dest="databricks_job_id")
    parser.add_argument("--databricks-run-id", dest="databricks_run_id")
    parser.add_argument("--job-status", dest="job_status")
    parser.add_argument("--job-status-message", dest="job_status_message")
    parser.add_argument("--config-location", dest="config_location")
    parser.add_argument("--extra-args", dest="extra_args")
    parser.add_argument("--orchestration-id", dest="orchestration_id")
    parser.add_argument("--orchestration-data", dest="orchestration_data")
    parser.add_argument("--layer", dest="layer")
    parser.add_argument("--schema", dest="schema")
    args = parser.parse_known_args()[0]

    spark = SparkSession.builder.getOrCreate()
    spark.sql(f"USE {args.schema}")

    # Get application information
    application = ApplicationConfiguration(app_name=args.app_name, spark=spark, with_user=True)

    # Add databricks/orchestration metadata
    databricks_id = _update_databricks_table(
        spark,
        application.name,
        f"UnifAI Data-Quality (Chimera) - {application.name}.content-check",
        application.get_config(),
        args.databricks_job_id,
        args.databricks_run_id,
        args.databricks_host,
    )
    _update_orchestration_table(spark, args.orchestration_id, args.orchestration_data, application.get_config())

    checks_passed = False
    run_id = str(uuid4())
    if args.job_status == "0":
        output_path = fetch_output_path(clean_path(args.config_location, "/dbfs"), args.extra_args)
        dataset_summary = pd.read_csv(os.path.join(output_path, "dataset_summary.csv"))
        dataset_summary["application_id"] = application.id
        dataset_summary["orchestration_id"] = args.orchestration_id
        dataset_summary_dicts = dataset_summary.to_dict("index")
        dataset_check_summary = pd.read_csv(os.path.join(output_path, "dataset_check_summary.csv"))
        dataset_check_summary["application_id"] = application.id
        dataset_check_summary["orchestration_id"] = args.orchestration_id
        dataset_check_summary_dicts = dataset_check_summary.to_dict("index")
        checks_passed = all(dataset_summary["accept"])
        results = dataset_summary[["application_id", "orchestration_id", "view_name", "accept"]]
        results_dict = results.to_dict("index")

        # Extract data-quality result metadata
        _update_results(spark, run_id, results_dict, args.layer)
        _update_summary(spark, run_id, dataset_check_summary_dicts)
        _update_dataset_summary(spark, run_id, dataset_summary_dicts)

        # Values for Data Quality Bad Records table
        # bad_records_dict = {
        #     "input_table": "test",
        #     "check": "test",
        #     "record_id": "172gaa",
        #     "SEVERITY": None,
        #     "ERROR_CODE": None,
        #     "FAILURE_REASON": None
        # }
        # _update_bad_records(spark, dq_result_id, bad_records_dict)

    # Write out data-quality run metadata
    configuration = {
        "app_name": application.name,
        "notification_list": [],
        "check_type": "content-check",
        "extra_args": args.extra_args,
    }
    runs_dict = {
        "application_id": application.id,
        "databricks_id": databricks_id,
        "orchestration_id": args.orchestration_id,
        "start_time": datetime.strptime(args.start_time, "%Y-%m-%d %H:%M:%S"),
        "end_time": datetime.strptime(args.end_time, "%Y-%m-%d %H:%M:%S"),
        "configuration": json.dumps(configuration),
        "job_status": args.job_status,
        "jobs_status_message": str(args.job_status_message).replace("'", ""),
        "checks_passed": checks_passed,
        "app_hash": application.get("GIT_HASH"),
        "unifai_hash": application.get("VERSION"),
    }

    _update_runs(spark, run_id, runs_dict)
    print(run_id)
