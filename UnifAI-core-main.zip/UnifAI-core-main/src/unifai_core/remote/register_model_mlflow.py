"""Cluster Wrapper to register a model in MLflow."""

import argparse

from pyspark.sql import SparkSession

from unifai_core.app.utils import _update_databricks_table
from unifai_core.app.utils import get_configuration
from unifai_core.mlflow.register_model import _insert_metadata
from unifai_core.mlflow.register_model import _register_model


if __name__ == "__main__":
    """Register model in Mlflow."""
    parser = argparse.ArgumentParser(description="Register model in Mlflow")
    parser.add_argument("--run-name", dest="run_name")
    parser.add_argument("--model-path", dest="model_path")
    parser.add_argument("--artifact-path", dest="artifact_path")
    parser.add_argument("--model-name", dest="model_name")
    parser.add_argument("--flavor", dest="flavor")
    parser.add_argument("--databricks-job-id", dest="databricks_job_id")
    parser.add_argument("--databricks-run-id", dest="databricks_run_id")
    parser.add_argument("--databricks-host", dest="databricks_host")
    parser.add_argument("--app-name", dest="app_name")
    parser.add_argument("--start-time", dest="start_time")
    parser.add_argument("--schema", dest="schema")

    args = parser.parse_known_args()[0]

    spark = SparkSession.builder.getOrCreate()
    spark.sql(f"USE {args.schema}")

    # Load application definition
    unifai_config = get_configuration(spark, True)
    application = spark.sql(
        f"""
        SELECT a.*, r.path AS repo_path, r.hash AS git_hash, current_user() as current_user
            FROM unifai_core_applications a, unifai_core_repositories r
            WHERE a.id = j.application_id
            AND a.name = '{args.name}'
        """
    ).collect()[0]

    experiment_name = f"/Users/{application.current_user}/{args.model_name}"
    run_details, status, status_message = _register_model(
        experiment_name, args.run_name, args.model_path, args.artifact_path, args.model_name, args.flavor
    )

    # Add databricks job/run details
    databricks_id = _update_databricks_table(
        spark,
        args.app_name,
        "UnifAI Data Quality Content Check",
        unifai_config,
        args.databricks_job_id,
        args.databricks_run_id,
        args.databricks_host,
    )

    _insert_metadata(
        spark,
        run_details,
        status,
        status_message,
        args,
        databricks_id,
        experiment_name,
        job_run_id=None,
        orchestration_id=None,
    )
