"""Set of command line programs that can be run on a remote cluster directly."""
