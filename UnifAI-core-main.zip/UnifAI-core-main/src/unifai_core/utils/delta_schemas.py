"""Shared utilities to aid column safety checks when saving a dataframe to a dedicated delta table schema."""

from typing import Dict
from typing import Optional
from typing import Set
from typing import Tuple

import pyspark.sql.functions as F  # noqa
from pyspark.sql import DataFrame


ALLOWED_CONVERSIONS: Dict[str, Set[str]] = {
    "int": {"float", "double", "bigint"},
    "bigint": {"double", "float"},
    # Add more allowed conversions here as needed...
}


def can_convert(dtype: str, base_dtype: str, allowed_conversions: Optional[Dict[str, Set[str]]] = None) -> bool:
    """Check if a data type can be safely converted to a base data type.

    Args:
        dtype: The data type to convert from.
        base_dtype: The base data type to convert to.
        allowed_conversions: Dictionary of allowed data type conversions.

    Returns:
        Boolean indicating if the conversion is allowed.
    """
    if allowed_conversions is None:
        allowed_conversions = ALLOWED_CONVERSIONS

    if dtype == "void":
        return True
    elif base_dtype == "string":
        return True
    else:
        return base_dtype in allowed_conversions.get(dtype, set())


def get_missing_columns(df: DataFrame, base_df: DataFrame) -> Set[str]:
    """Get the set of columns missing in a DataFrame compared to a base DataFrame.

    Args:
        df: The DataFrame to check.
        base_df: The base DataFrame to compare against.

    Returns:
        A set of missing column names.
    """
    return set(base_df.columns) - set(df.columns)


def get_non_matching_dtypes(
    df: DataFrame, base_df: DataFrame
) -> Tuple[Dict[str, Dict[str, str]], Dict[str, Dict[str, str]]]:
    """Compare data types between two DataFrames and categorize them into castable and non-castable.

    Args:
        df: The DataFrame to check.
        base_df: The base DataFrame to compare against.

    Returns:
        A tuple containing two dictionaries:
        - The first dictionary contains castable columns and their respective data types.
        - The second dictionary contains non-castable columns and their respective data types.
    """
    df_dtypes, base_df_dtypes = dict(df.dtypes), dict(base_df.dtypes)
    castable, not_castable = {}, {}

    shared_columns = set(base_df.columns).intersection(set(df.columns))
    for col in shared_columns:
        dtype, base_dtype = df_dtypes[col], base_df_dtypes[col]
        if dtype != base_dtype:
            if can_convert(dtype, base_dtype):
                castable[col] = {"from": dtype, "to": base_dtype}
                print(f"castable = {castable[col]}")
            else:
                not_castable[col] = {"from": dtype, "to": base_dtype}
                print(f"non-castable = {not_castable[col]}")

    return castable, not_castable


def update_dataframe_to_match_existing(new_df: DataFrame, existing_df: DataFrame) -> DataFrame:
    """Update the schema of a DataFrame to match the schema of an existing DataFrame.

    Args:
        new_df: The DataFrame to update.
        existing_df: The existing DataFrame whose schema needs to be matched.

    Returns:
        The updated DataFrame.
    """
    # Handle missing columns
    missing_columns = get_missing_columns(new_df, existing_df)
    if missing_columns:
        existing_dtypes = dict(existing_df.dtypes)
        for col in missing_columns:
            new_df = new_df.withColumn(col, F.lit(None).astype(existing_dtypes[col]))
        print("Added columns with `None`, missing from dataframe to match target:" + ", ".join(missing_columns))

    # Handle non-matching data types
    castable_nonmatching, non_castable_nonmatching = get_non_matching_dtypes(new_df, existing_df)
    for col, dtypes in castable_nonmatching.items():
        print(f'Casting `{col}` (`{dtypes["from"]}`->`{dtypes["to"]}`)')
        new_df = new_df.withColumn(col, F.col(col).astype(dtypes["to"]))
    for col, dtypes in non_castable_nonmatching.items():
        print(f'Casting `{col}` (`{dtypes["from"]}`->`{dtypes["to"]}`) not supported.')

    return new_df


def has_schema_mismatches(df: DataFrame, base_df: DataFrame) -> bool:
    """Check if there are missing columns or mismatched data types between two DataFrames.

    Args:
        df: The DataFrame to check.
        base_df: The base DataFrame to compare against.

    Returns:
        True if there are missing columns or mismatched data types, otherwise False.
    """
    missing_columns = get_missing_columns(df, base_df)
    castable, not_castable = get_non_matching_dtypes(df, base_df)

    if missing_columns:
        print(f"Dataframe is missing columns defined in its corresponding delta schema: {missing_columns}")

    if castable or not_castable:
        print(
            f"Dataframe contains columns of datatype mismatch compared to its corresponding delta schema. "
            f"Castable columns: {castable}. Non-castable columns: {not_castable}"
        )

    return bool(missing_columns) or bool(castable) or bool(not_castable)
