"""Safe Dictionary used when formatting values."""


class SafeFormatDict(dict):
    """Safe Dictionary used when formatting values."""

    def __missing__(self, key):
        """Fail safe return if key not found."""
        return "{" + key + "}"
