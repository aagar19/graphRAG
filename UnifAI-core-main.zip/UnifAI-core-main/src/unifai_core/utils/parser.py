"""Parser (with prompt) of user provided args."""

import re
from typing import Any
from typing import Dict
from typing import Optional

from unifai_core.utils.formatter import SafeFormatDict


def populate_run_args(run_name: str, job_inputs: dict, job_args: dict, sys_config: dict) -> dict:
    """Cycle through job inputs and prompt the user."""
    import click

    # Break out if no inputs are defined
    result: Dict[str, Any] = {}
    if not job_inputs:
        return result

    # Display input prompt
    print(f"\nPlease provide the {run_name} inputs ...")

    # Loop through each job input
    for name, config in job_inputs.items():
        required = config["required"]
        # Get value from CLI (if provided) or using the configured default
        value = parse_value_config(job_args.get(name), config.get("default", (None if required else "")), sys_config)
        # Prompt user for input
        prompt_msg = f" # ({'REQUIRED' if required else 'optional'}) {name}"
        dtype = config.get("type", "string").lower()
        if dtype == "boolean":
            value = click.confirm(f"{prompt_msg}?", default=True)
        elif dtype == "integer":
            input_value = None if not __is_int(str(value)) else str(value)
            value = click.prompt(prompt_msg, type=int, default=input_value)
        elif dtype == "float":
            input_value = None if not __is_float(str(value)) else str(value)
            value = click.prompt(prompt_msg, type=float, default=input_value)
        else:
            value = click.prompt(prompt_msg, type=str, default=value)
        value = __cast_value_to_type(name, value, config.get("type", "string").lower())
        # Ensure require params has a value
        if required and value is None:
            raise ValueError(f"Failed to start job {run_name} as required input ({name}) was not provided!")
        # Update args list
        result[name] = value

    # return final values
    return result


def update_run_args(job_name: str, job_config: dict, inputs: dict, **kwargs) -> dict:
    """Cycle through job inputs and ensure all are correctly captured."""
    result = {}
    for name, config in inputs.items():
        required = config["required"]
        # Get value from CLI (if provided) or using the configured default
        default = config.get("default", (None if required else ""))
        value = parse_value_config(kwargs.get(name), default, job_config)
        value = __cast_value_to_type(name, value, config.get("type", "string").lower())
        # Ensure require params has a value
        if required and value is None:
            raise ValueError(f"Failed to parse required job ({job_name}) input ({name}), as it was not provided!")
        # Update args list
        result[name] = value
    return result


def __is_int(value: Optional[str]) -> bool:
    """Private function used to determine if the value is an integer."""
    return re.sub(r"[Ee-]", "", str(value)).isnumeric()


def __is_float(value: Optional[str]) -> bool:
    """Private function used to determine if the value is a float."""
    return __is_int(re.sub(r"\.", "", str(value)))


def __to_bool(value: str) -> Optional[bool]:
    """Casts string to boolean."""
    if str(value).lower() in ["1", "true", "t", "yes", "y"]:
        return True
    elif str(value).lower() in ["0", "false", "f", "no", "n"]:
        return False
    else:
        return None


def __to_float(value: str) -> Optional[float]:
    """Casts string to float."""
    return None if not __is_int(value) else float(value)


def __to_int(value: str) -> Optional[int]:
    """Casts string to integer."""
    return None if not __is_int(value) else int(value)


def __to_list(name: str, value: Any, dtype: str) -> list:
    """Format string to list, and format each value in list."""
    if isinstance(value, list):
        return value
    elif str(value) == "[]":
        return []
    else:
        li = str(value).lstrip("[").rstrip("]").split(",")
        if "[" in dtype and dtype.endswith("]"):
            sub_type = dtype.split("[")[1].rstrip("]")
            li = [__cast_value_to_type(name, v, sub_type) for v in li]
        return li


def __cast_value_to_type(name: str, value: Any, dtype: str) -> Any:
    """Cast string value to target type, provided config."""
    try:
        if value is None:
            return None
        elif dtype == "boolean" or dtype == "bool":
            return __to_bool(value)
        elif dtype == "float":
            return __to_float(value)
        elif dtype == "integer" or dtype == "int":
            return __to_int(value)
        elif dtype == "string":
            return str(value)
        elif dtype.startswith("list"):
            return __to_list(name, value, dtype)
        else:
            raise ValueError(f"Cannot cast {name} to {dtype} as this type is unsuportted!")
    except ValueError as ex:
        raise ValueError(f"Cannot cast {name} to {dtype} == {value!r}!") from ex


def parse_value_config(value: Any, default: Any = None, format_map: Optional[dict] = None) -> Any:
    """Utility function to parse configuration into value."""
    value = value if str(value).lower() not in ["", "none"] else default
    if isinstance(value, str) and "{" in value and "}" in value:
        return value.format_map(SafeFormatDict(format_map or {}))
    return value
