"""Shared utilities function for reruning a workflow."""

import json
from datetime import datetime
from typing import List
from uuid import uuid4

import pyspark.sql.functions as f
from pyspark.sql import DataFrame


def load_from_current_version(data_as_of: str) -> bool:
    """Check if version history of a table needs to be fetched.

    This function checks if it's necessary to fetch the version history of a table.
    Version checking is not required if `data_as_of` and the current date are the same.
    In such cases, the function will pull the latest version of the data.

    Args:
        data_as_of (str): A date parameter to compare the current date against.

    Returns:
        bool: True if current version history needs to be fetched, False otherwise.
    """
    return data_as_of == str(datetime.today().date())


def get_version_from_timestamp(spark, data_as_of, tablename):
    """This function will return the version of the table associated with data_as_of date.

    Args:
    spark: SparkSession()
    data_as_of : str - This parameter helps fetch the right data version from the history of the table
    tablename : The table whose history we are trying to fetch

    Returns:
    Version : Based on the history of the table it will return the version associated with the
    data_as_of date. If there are multiple versions associated with the same day then the latest
    version is returned. If the data_as_of date pre-exists the creation of table then the initial
    version is returned else we default to latest version of table. (TBD)
    """
    query = f"SELECT MAX(version) FROM (DESCRIBE HISTORY {tablename})"
    version = spark.sql(f"{query} where date_format(timestamp, 'yyyy-MM-dd') <= '{data_as_of}'").collect()[0][0]
    # if the data_as_of pre-dates the existence of the table default to the latest version
    if version is None:
        raise ValueError("No data version found for the give data_as_of parameter")
    return version


def get_orchestration_details_from_id(spark, id: str) -> DataFrame:
    """Takes in an ID as input and pulls data from unifai_core_orchestration.The id can be orchestration_id / run_id."""
    # query with orchestration_id first
    # print("Trying to fetch details as orchestration_id")
    orchestration_details = spark.sql(f"SELECT * from unifai_core_orchestration where id = '{id}'")
    if not (orchestration_details.head(1)):
        # query with job_id
        # print("Trying to fetch details as run_id")
        orchestration_details = spark.sql(f"SELECT * from unifai_core_orchestration where run_id = '{id}' ")
        if not (orchestration_details.head(1)):
            raise ValueError("No workflows found with the given id")
    return orchestration_details


def get_job_details_from_id(spark, orchestration_ids: List) -> DataFrame:
    """Fetch job_details based on orchestration_ids."""
    orchestration_ids_str = ",".join(["'" + str(value) + "'" for value in orchestration_ids])
    job_details = spark.sql(
        f"""SELECT  jr.start_time, jr.run_as_of, jr.run_type, jr.configuration, jr.status,
                            jr.status_message, jr.job_hash, j.name as job_name, a.name as app_name,
                            a.id as app_id
                            from unifai_core_job_runs as jr inner join unifai_core_jobs as j
                            inner join unifai_core_applications as a on
                            (jr.job_id = j.id and jr.application_id = a.id) where
                             jr.orchestration_id in ({orchestration_ids_str})
                             order by start_time"""
    )

    if not (job_details.head(1)):
        raise ValueError("No matching jobs found with the orchestration_id")
    return job_details


def generate_config_str(configuration: dict) -> str:
    """Generates a string of key=value format from the configuration dictionary."""
    config_str = " ".join([f"{key}={value}" for key, value in configuration.items()])
    return config_str


def get_git_url(spark, app_id: str) -> str:
    """Get the git repository url of the app that was published from the unifai_core_repositories table."""
    query = f"SELECT url FROM unifai_core_repositories WHERE application_id = '{app_id}'"
    git_path = spark.sql(query).collect()[0][0]
    return git_path


def generate_instructions(spark, workflow_id, orchestration_ids, data_as_of, job_details) -> List:
    """Generates instructions to re-run a workflow on databricks."""
    run_type = "RERUN"
    end_line = "-" * 100
    config_command = "`unifai-admin -p <profile> configure`"
    instructions = []
    error_messages = []
    i = 1

    # get application_name and job_name
    for each in orchestration_ids:
        subset_job_details = job_details.filter(f.col("orchestration_id") == each).collect()
        git_hash = subset_job_details[0]["job_hash"]
        app_name = subset_job_details[0]["app_name"]
        app_id = subset_job_details[0]["app_id"]
        git_url = get_git_url(spark, app_id)
        instructions.append(
            f"Instructions to re-run a workflow for unifai_{app_name} with id '{workflow_id}' using unifai-admin commands\n"
        )
        instructions.append("\n")
        instructions.append(
            f"{i}. Create a new git branch in order to fetch the right code version using the git hash : {git_hash}\n"
        )
        i += 1
        instructions.append(
            f"Example: Open the git repository on your system and execute the following command:\n"
            f"\tgit checkout -b <new_branch_name> {git_hash}\n"
            f"\tgit push -u origin <new_branch_name>\n"
        )
        instructions.append(f"{i}. Execute {config_command} command to configure your databricks environment\n")
        i += 1
        instructions.append(
            f"{i}. Publish the app using the command:\n\n"
            f"unifai-admin -p <profile_name> apps publish {git_url} unifai_{app_name} --branch <new_branch_name>\n"
        )
        i += 1
        instructions.append("{i}. After successfully publishing the app run the jobs in the following order\n\n")
        i += 1
        new_orch_id = str(uuid4())
        for row in subset_job_details:
            config = generate_config_str(json.loads(row["configuration"]))
            if row["status"] == 0:
                instructions.append(
                    f"""unifai-admin -p <profile_name> jobs run {app_name}.{row["job_name"]} """
                    f"""run_as_of={row["run_as_of"]}  data_as_of={data_as_of}"""
                    f"""run_type={run_type} {config} --orchestration-id={new_orch_id}\n"""
                )
            else:
                error_messages.append(
                    """The following command ended with error\n"""
                    f"""unifai-admin -p <profile_name> jobs run {app_name}.{row["job_name"]} """
                    f"""run_as_of={row["run_as_of"]}  data_as_of={data_as_of}"""
                    f"""run_type={run_type} {config} --orchestration_id={new_orch_id}\n"""
                    f"""{row["status_message"]}\n\n"""
                )
        instructions.append(f"{end_line}\n")

    # if any errors are found append it to the instructions list
    if error_messages:
        instructions.append("Jobs that ended with errors:\n\n")
        instructions.extend(error_messages)

    return instructions
