"""Shared utilities to aid loading data from unifai_core_model_output_store into legacy/different pivoted format."""

from __future__ import annotations

import itertools
from collections import Counter
from datetime import datetime

import pyspark.sql.functions as F  # noqa
from dateutil.relativedelta import relativedelta  # type: ignore
from pyspark.sql import DataFrame
from pyspark.sql.window import Window


def _data_link_dynamic_split(df: DataFrame, unique_data_link_list: list[str]) -> DataFrame:
    """Dynamically split the data_link_value column and create additional columns.

     The data_link_value and data_link_type will be dropped after the split.

    Args:
        df: The spark DataFrame with columns "data_link_value" and "data_link_type".
        unique_data_link_list: List of unique data_link values (e.g ["ENTY_ID|UNIQ_MBR_ID", "UNIQ_MBR_ID|ENTY_ID|ADMIT_DT"]).

    Returns:
        A spark DataFrame with split columns on the data_link_value.
    """
    # Get unique target columns
    data_link_columns = list(set(itertools.chain.from_iterable([u.split("|") for u in unique_data_link_list])))

    # Create new columns with data link values
    map_col = F.map_from_arrays(F.split("data_link_type", r"\|"), F.split("data_link_value", r"\|"))
    new_cols = [map_col.getItem(x).alias(str(x)) for x in data_link_columns]
    return df.select(*df.columns, *new_cols).drop("data_link_type", "data_link_value")


def _data_link_static_split(df: DataFrame, unique_data_link: str) -> DataFrame:
    """Statically split the data_link_value column and create additional columns.

    Args:
        df: The spark DataFrame with columns "data_link_value" and "data_link_type".
        unique_data_link: String containing the unique data_link value (e.g "ENTY_ID|UNIQ_MBR_ID").

    Returns:
        A spark DataFrame with explicit and additional data_link columns after the split.
    """
    data_link_columns = unique_data_link.split("|")
    split_df = df.withColumn("data_link_values", F.split("data_link_value", r"\|"))
    for i, column in enumerate(data_link_columns):
        split_df = split_df.withColumn(column, F.col("data_link_values")[i])

    drop_cols = ["data_link_type", "data_link_value", "data_link_values"]
    return split_df.select(*data_link_columns, *[col for col in df.columns if col not in drop_cols])


def get_original_dtypes(df: DataFrame) -> dict[str, str]:
    """Creates dictionary of original datatypes for each unique `calculation_value` column value.

    Args:
        df: The spark DataFrame containing calculation_name and calculation_datatype.

    Returns:
        A dictionary where key = calculation_name and value = calculation_datatype (e.g
        {"mortality-score": "float"}).
    """
    return {
        row["calculation_name"]: row["calculation_datatype"]
        for row in df.select("calculation_name", "calculation_datatype").distinct().collect()
    }


def pivot_columns(df: DataFrame, target_columns: list | None) -> DataFrame:
    """Pivot grouped data (over non-`calculation_*` columns) on `calculation_name` column and reverts to original datatype.

    Args:
        df: The spark DataFrame.
        target_columns: List of values in `calculation_name` that are translated to columns.
            If `target_columns is None`, then all values in `calculation_name` are translated to columns.

    Returns:
        The pivoted spark DataFrame.
    """
    non_calculation_columns = [col for col in df.columns if not col.lower().startswith("calculation_")]
    pivoted = (
        df.groupby(non_calculation_columns)
        .pivot("calculation_name", values=target_columns)
        .agg(F.max(F.col("calculation_value")))
    )

    original_dtypes = get_original_dtypes(df)
    for col_name, dtype in original_dtypes.items():
        if col_name in pivoted.columns:
            pivoted = pivoted.withColumn(col_name, F.col(col_name).astype(dtype))
    return pivoted


def select_columns(df: DataFrame, extra_columns: dict[str, str]) -> DataFrame:
    """Select specific columns with optional extra columns.

    Args:
        df: The spark DataFrame.
        extra_columns: Extra (UnifAI specific) columns to include in the select expression, with SQL expressions.

    Returns:
        A spark DataFrame with selected columns.
    """
    keep_cols = ["calculation_name", "calculation_datatype", "calculation_value", "data_link_type", "data_link_value"]
    selected = df.selectExpr(
        *[f"{col} as {col}" for col in keep_cols], *[f"{expr} as {col}" for col, expr in extra_columns.items()]
    )
    return selected


def format_data(df: DataFrame, calculation_column_mappings: dict[str, str]) -> DataFrame:
    """Split data link columns and rename calculation columns.

    Args:
        df: The pivoted spark DataFrame.
        calculation_column_mappings: A mapping of calculation column names to new names (usually the legacy
                                     calculation column name).

    Returns:
        A reformatted spark DataFrame.
    """
    df = split_data_link_columns(df)
    for source, dest in calculation_column_mappings.items():
        df = df.withColumnRenamed(source, dest)
    return df


def split_data_link_columns(df: DataFrame) -> DataFrame:
    """Split data_link_column based on data_link_type values.

    Args:
        df: The spark DataFrame to split on the data_link_value column.

    Returns:
        A spark DataFrame with split columns.

    Raises:
        ValueError: If no data_link_type values found (empty dataframe).
    """
    unique_types = [row.data_link_type for row in df.select("data_link_type").distinct().collect()]

    if len(unique_types) == 0:
        raise ValueError("No data_link_type values found (empty dataframe)")
    elif len(unique_types) == 1:
        return _data_link_static_split(df, unique_types[0])
    else:
        return _data_link_dynamic_split(df, unique_types)


def generate_run_as_of_range(
    run_as_of: str,
    prediction_window: dict[str, int],
    data_lag: dict[str, int],
    allowance: tuple | dict[str, int] | None = (("days", 7),),
    end_lag: tuple | dict[str, int] | None = (("months", 1),),
    date_format: str = "%Y-%m-%d",
) -> tuple[str, str]:
    """Generate range of dates based on the prediction window, allowance, end lag and data lag.

    Args:
        run_as_of: current run_as_of date
        prediction_window: prediction window for the model
        data_lag: claims lag or any other lag related to data consumption
        allowance: time window to accommodate different run dates for different months. Defaulting it to 7 days as
                   usually pipeline gets triggered around 20-26 of the month.
        end_lag: give users the flexibility to remove/add latest n months. Defaulting it to 1 month to remove the
                 current month.
        date_format: format of run_as_of date

    Returns:
        Earliest date and Latest Date from the date range.
    """
    # Convert default tuples to dictionaries (defaulting as tuple for sake of immutability)
    if isinstance(allowance, tuple):
        allowance = {unit: n for unit, n in allowance}
    if isinstance(end_lag, tuple):
        end_lag = {unit: n for unit, n in end_lag}

    run_as_of_date = datetime.strptime(run_as_of, date_format)
    # Get the earliest run date valid for results
    delta = Counter(allowance) + Counter(data_lag) + Counter(prediction_window)
    # Add element-wise
    early_date = run_as_of_date - relativedelta(**dict(delta))

    # Get latest run date considered for results
    last_date = run_as_of_date - relativedelta(**end_lag) + relativedelta(**allowance)

    early_date = early_date.strftime(date_format)
    last_date = last_date.strftime(date_format)

    return early_date, last_date


def deduplicate_orchestration_ids(df: DataFrame) -> DataFrame:
    """Deduplicates orchestration IDs based on the latest update_date_time for each ID.

    Args:
        df (DataFrame): A Spark DataFrame containing the columns 'id', 'run_as_of', 'update_date_time', and 'run_type'.

    Returns:
        DataFrame: A deduplicated Spark DataFrame.
    """
    # Create a column that represents the truncation level based on run_type
    df = df.withColumn(
        "trunc_level",
        F.when(F.col("run_type") == "MONTHLY", F.date_trunc("month", F.col("run_as_of"))).otherwise(
            F.date_trunc("day", F.col("run_as_of"))
        ),
    )

    # Define the window specification
    window_spec = Window.partitionBy("trunc_level").orderBy(F.col("update_date_time").desc())

    # Apply the window function to rank rows within each partition
    df = df.withColumn("rank", F.row_number().over(window_spec))

    # Filter to keep only the top-ranked row in each partition
    deduplicated_df = df.filter(F.col("rank") == 1).drop(
        "rank", "trunc_level", "run_type", "run_as_of", "update_date_time"
    )

    return deduplicated_df


def get_orchestration_ids(spark, early_date: str, last_date: str, app_name: str) -> DataFrame:
    """Get list of orchestration ids given list of run_as_of's.

    Args:
        spark: spark instance
        early_date: First date from the date range.
        last_date: Last date from the date range.
        app_name: name of the application.

    Returns:
        DF containing list of orchestration ids.
    """
    query = f"""
    select distinct(o.id), jr.run_as_of, o.update_date_time, jr.run_type from unifai_core_orchestration o
    inner join unifai_core_job_runs jr
        on jr.orchestration_id = o.id
    inner join unifai_core_applications a
        on jr.application_id = a.id
    where a.name = '{app_name}'
      and jr.run_as_of between '{early_date}' and '{last_date}'
    """
    orchestration_ids = spark.sql(query)

    deduplicated_orchestration_ids = deduplicate_orchestration_ids(orchestration_ids)

    return deduplicated_orchestration_ids
