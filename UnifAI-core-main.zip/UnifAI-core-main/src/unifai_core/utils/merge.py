"""Shared utilities to improve merging dictionaries."""


def deep_merge(source: dict, *args) -> dict:
    """Performs a Deep Merge of two or more dictionaries."""
    if not args:
        raise ValueError("Deep-Merge requires atleast 2 parameters (source1, ..., destination)")
    list_args = list(args)
    result = _deep_merge(source, list_args.pop())
    if len(list_args) > 0:
        for arg in list_args:
            result = _deep_merge(arg, result)
    return result


def _deep_merge(source: dict, destination: dict) -> dict:
    """Performs a Deep Merge of two dictionaries."""
    result = destination.copy()
    for key, value in source.items():
        current = result.get(key)
        if isinstance(value, dict):
            result[key] = _deep_merge(value, current or {})
        elif not current:
            result[key] = value
    return result
