"""Airflow API integration methods."""

from typing import Mapping
from typing import Optional
from typing import Union
from uuid import uuid4

import requests
from requests.exceptions import HTTPError

from unifai_core.airflow.api_config import get_endpoint
from unifai_core.airflow.log_formatter import format_dag_runs_list
from unifai_core.airflow.log_formatter import format_dags_list
from unifai_core.app.utils import REQUEST_TIMEOUT
from unifai_core.cli.types import Settings


DEFAULT_PATH = "/opt/airflow/dags"


def publish_dag(
    settings: Settings, token: str, file_path: str, server_path: Optional[str] = None, quiet: bool = False
) -> None:
    """A function used to publish a DAG onto an Airflow server.

    @param file_path - The path to the DAG python file on the client machine
    @param server_path (optional) - The path on the server you wish to save the DAG to. default = '/opt/airflow/dags'
    """
    clean_path = (server_path or "").replace(f"{DEFAULT_PATH}/unifai", "").replace(DEFAULT_PATH, "")
    clean_path = f"{DEFAULT_PATH}/{clean_path}".replace("//", "/")

    headers: Optional[Mapping[str, Union[str, bytes]]] = {
        "Authorization": f"Bearer {token}",
        "file_path": file_path,
        "password": settings.get("AIRFLOW_TOKEN", "") or "",
        "server_path": clean_path or DEFAULT_PATH,  # Ensure clean_path is always a str
    }

    if not quiet:
        print("Preparing to publish DAG...")

    try:
        with open(file_path, "rb") as file_to_upload:
            response = requests.post(
                get_endpoint("PUBLISH", settings),
                files={"file": file_to_upload},
                headers=headers,
                timeout=REQUEST_TIMEOUT,
            )
            response.raise_for_status()
            print(f"DAG successfully published to Airflow. You can view the DAG here: {settings['AIRFLOW_HOST']}/home")
            if not quiet:
                print(response.json())
    except HTTPError as http_err:
        print(f"Airflow Publish Error: {http_err}")
        raise RuntimeError(f"Airflow Publish Error: {http_err}") from http_err
    except Exception as err:
        print(f"Unexpected error: {err}")
        raise RuntimeError(f"Unexpected error occurred: {err}") from err


def trigger_dag(settings: Settings, token: str, dag_id: str, config: Optional[str] = None):
    """A function used to manually trigger a DAG on an Airflow server.

    @param dag_id - The name of the associated dag_id to be triggered
    @param config (optional) - The configuration to pass to the DAG.
    """
    headers = {
        "Authorization": token,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    try:
        config = "{}" if not config else config.replace("\\", "")
        response = requests.post(
            get_endpoint("TRIGGER", settings, {"DAG_ID": dag_id}),
            data=f'{{"dag_run_id": "{str(uuid4())}", "conf": {config}}}',
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )
        response.raise_for_status()
        print(
            f"DAG with dag_id = {dag_id} triggered successfully\n"
            f"You can view the DAG here : {settings['AIRFLOW_HOST']}dags/{dag_id}"
        )
    except HTTPError as ex:
        raise RuntimeError(f"Airflow Trigger Error: {ex}") from ex


def list_dags(settings: Settings, token: str, limit: int = 100, tags: Optional[str] = None, json_output: bool = False):
    """A function used to receive response for list of DAGs on an Airflow server.

    @param limit (optional)- Limit output list
    @param tags (optional) - Specify an array of tags to filter by
    @param json_output (optional) - Return the raw JSON output from the API
    """
    headers = {
        "Authorization": token,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    try:
        response = requests.get(
            get_endpoint("LIST", settings),
            params={"limit": str(limit), "tags": "unifai" if not tags else ",".join(tags)},
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )
        response.raise_for_status()
        if json_output:
            print(response.json())
        else:
            format_dags_list(response.json())
    except HTTPError as ex:
        raise RuntimeError(f"Airflow List Error: {ex}") from ex


def list_dag_runs(settings: Settings, token: str, dag_id: str, limit: int = 10, json_output: bool = False):
    """A function used to list the runs of a specified DAG.

    @param dag_id - The dag_id to query runs instances
    @param limit (optional)- Limit output list
    @param json_output (optional) - Return the raw JSON output from the API
    """
    headers = {
        "Authorization": token,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    try:
        response = requests.get(
            get_endpoint("LIST_RUNS", settings, {"DAG_ID": dag_id}),
            params={"limit": str(limit), "order_by": "start_date"},
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )
        response.raise_for_status()
        if json_output:
            print(response.json())
        else:
            format_dag_runs_list(response.json())
    except HTTPError as ex:
        raise RuntimeError(f"Airflow List-Runs Error: {ex}") from ex
