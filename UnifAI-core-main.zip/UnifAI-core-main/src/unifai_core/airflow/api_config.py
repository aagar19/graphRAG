"""Airflow API Config."""

from typing import Optional

from unifai_core.cli.types import Settings
from unifai_core.utils.formatter import SafeFormatDict


API_ENDPOINTS = {
    "PUBLISH": "{AIRFLOW_HOST}api/publish",
    "TRIGGER": "{AIRFLOW_HOST}api/v1/dags/{DAG_ID}/dagRuns",
    "LIST": "{AIRFLOW_HOST}api/v1/dags",
    "LIST_RUNS": "{AIRFLOW_HOST}api/v1/dags/{DAG_ID}/dagRuns",
}


def get_endpoint(endpoint: str, settings: Settings, config: Optional[dict] = None) -> str:
    """Utility function to parse the Airflow Endpoints."""
    return API_ENDPOINTS[endpoint].format_map(SafeFormatDict({**settings, **(config or {})}))
