"""Airflow Logger Format code."""

from datetime import datetime

from colorama import Fore
from colorama import Style
from tabulate import tabulate


STATES = {
    "failed": Fore.RED,
    "running": Fore.LIGHTGREEN_EX,
    "success": Fore.GREEN,
    "up_for_retry": Fore.LIGHTYELLOW_EX,
    "upstream_failed": Fore.YELLOW,
}


def format_dags_list(dags):
    """Formating of returned DAGs list."""
    table = [["DAG_ID", "TAGS", "FILE_PATH", "ACTIVE", "PAUSED", "LAST_PARSED_TIME"]]

    for dag in dags["dags"]:
        is_active = f"{STATES['success'] if dag['is_active'] else STATES['failed']}{dag['is_active']}{Style.RESET_ALL}"
        is_paused = f"{STATES['success'] if dag['is_paused'] else STATES['failed']}{dag['is_paused']}{Style.RESET_ALL}"

        tags = ""
        for tag in dag["tags"]:
            tags += tag["name"] + "\n"

        entry = [dag["dag_id"], tags, dag["fileloc"], is_active, is_paused, dag["last_parsed_time"]]
        table.append(entry)

    print(tabulate(table, tablefmt="grid"))


def format_dag_runs_list(dags):
    """Formating of returned DAG runs list."""
    table = [["DAG ID", "DURATION", "START_DATE", "DAG_RUN_ID", "STATE"]]

    for dag_run in dags["dag_runs"]:
        delta = None
        if dag_run["end_date"] is not None:
            delta = (
                datetime.strptime(dag_run["end_date"][:-6], "%Y-%m-%dT%H:%M:%S.%f")
                - datetime.strptime(dag_run["start_date"][:-6], "%Y-%m-%dT%H:%M:%S.%f")
            ).seconds

        entry = [
            dag_run["dag_id"],
            "running" if not delta else f"{round(float(delta/60), 2)} min(s)",
            dag_run["start_date"],
            dag_run["dag_run_id"],
            f"{STATES[dag_run['state']]}{dag_run['state']}{Style.RESET_ALL}",
        ]
        table.append(entry)

    print(tabulate(table, tablefmt="grid"))
