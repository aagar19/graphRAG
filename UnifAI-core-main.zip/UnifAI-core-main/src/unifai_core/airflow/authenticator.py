"""Airflow Authenticator code."""

import base64

import click

from unifai_core.cli.types import Settings


def get_auth_token(settings: Settings) -> str:
    """A function used get the user."""
    user_pwd = click.prompt(f"Please enter user ({settings['AIRFLOW_USER']}) password ", type=str, hide_input=True)
    bytes_token = f"{settings['AIRFLOW_USER']}:{user_pwd}".encode()
    return f"Basic {base64.b64encode(bytes_token).decode('utf-8')}"
