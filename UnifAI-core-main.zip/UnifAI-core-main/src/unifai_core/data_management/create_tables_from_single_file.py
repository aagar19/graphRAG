"""Create Multiple Tables given a single sql file containing multiple CREATE DDl commands seperated by ';'."""

import os
import shutil
import tempfile
import traceback

from unifai_core.data_management.create_table import main as create_table


def main(file_path: str, location: str, if_not_exist_flag=True, continue_on_failure=False):
    """Create multiple tables from a single sql file containing multiple CREATE DDL commands separated by ';'.

    Args:
        file_path: jinja sql template file containing multiple CREATE DDL commands
        location: location to give the table in blobstorage
        if_not_exist_flag: whether to have IF NOT EXISTS statement in create query
        continue_on_failure: continue through next command if True else exits the program on failure

    Returns:
        Boolean Flag depicting success or failure
    """
    try:
        with open(file_path) as f:
            template = f.read()

        # Splitting the lines and string trailing characters
        template_queries = template.split(";")
        template_queries = [i.rstrip() for i in template_queries if i.rstrip() != ""]

        dir_path = tempfile.mkdtemp()
        for idx, template_query in enumerate(template_queries):
            try:
                file_path = os.path.join(dir_path, f"file_{idx}.sql")
                with open(file_path, "w") as f:
                    f.write(template_query)
                result = create_table(file_path, location, if_not_exist_flag)
                if result is False:
                    raise Exception("Error creating the table")
            except Exception as e:
                print(f"Exception occurred while creating table for query : {template_query} -> {e} ")
                if not continue_on_failure:
                    shutil.rmtree(dir_path)
                    return False
        shutil.rmtree(dir_path)
        return True
    except Exception:
        print(traceback.format_exc())
        return False
