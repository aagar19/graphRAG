"""Drop Table given an sql file containing DROP DDL command."""

from unifai_core.data_management.utils import apply_sql_template
from unifai_core.data_management.utils import execute_query


def main(file_path, if_exist_flag=True):
    """Function to drop a table.

    Args:
        file_path: jinja sql template file containing DROP DDL command
        if_exist_flag: whether to keep IF EXIST command in the query

    Returns:
        Query Output if table dropped successfully otherwise False

    Raises:
        NotImplementedError: when path doesn't begin with 'dbfs:' (filesystem on remote databricks server)
            or '/' (local file system)
    """
    try:
        if file_path.startswith("dbfs:"):
            from pyspark.sql import SparkSession  # type: ignore

            spark = SparkSession.builder.getOrCreate()
            template_query = spark.read.text(file_path, wholetext=True).collect()[0][0]
        elif file_path.startswith("/"):
            with open(file_path) as f:
                template_query = f.read()
        else:
            raise NotImplementedError(f"{file_path} is not yet supported - must start with either 'dbfs:' or '/'")

        # Parsing the Query
        params = {"if_exist_flag": r"IF EXISTS" if if_exist_flag else r""}
        final_query = apply_sql_template(template_query, params)

        # Create Table
        result = execute_query(final_query)
        return result
    except Exception as e:
        print("Exception occurred while dropping the table : ", e)
        return False
