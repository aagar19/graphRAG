"""Create multiple tables given a directory of all sql files."""

import os

from unifai_core.data_management.create_table import main as create_table


def main(directory: str, location: str, if_not_exist_flag=True):  # noqa: C901
    """Function to generate tables on the basis of CREATE DDL sqls stored in directory."""
    if directory.startswith("dbfs:"):
        from pyspark.dbutils import DBUtils  # type: ignore
        from pyspark.sql import SparkSession  # type: ignore

        spark = SparkSession.builder.getOrCreate()
        dbutils = DBUtils(spark)
        for file in dbutils.fs.ls(directory):
            try:
                if file.name.endswith(".sql"):
                    result = create_table(file.path, location, if_not_exist_flag)
                    if result is False:
                        return False
            except Exception as e:
                print(f"Exception Occurred while creating the table for file : {file} -> : {e}")
                return False
        return True
    elif directory.startswith("/"):
        for file in os.listdir(directory):
            try:
                if file.endswith(".sql"):
                    result = create_table(os.path.join(directory, file), location, if_not_exist_flag)
                    if result is False:
                        return False
            except Exception as e:
                print(f"Exception Occurred while creating the table for file : {file} -> : {e}")
                return False
        return True
    else:
        raise NotImplementedError(f"{directory} is not yet supported - must start with either 'dbfs:' or '/'")
