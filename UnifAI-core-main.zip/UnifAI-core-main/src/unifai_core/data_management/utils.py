"""Utilites for all data management scripts."""

import os
import sys
from configparser import ConfigParser
from itertools import cycle

import numpy as np
import pandas as pd
from jinjasql import JinjaSql  # type: ignore


def generate_sample_dataframe(size, cols, col_names=None, intervals=None, seed=None):  # noqa: C901
    """Function to generate sample Dataframe dynamically.

    Args:
        size: Number of rows
        cols: type of col (c - categorical, i - int, d - date, f - float) eg.- 'cidfdfc'
        col_names: Names of Column ( Optional)
        intervals: Interval for relevant columns
        seed: Input same number if wants to generate same data each time

    Returns:
        pandas dataframe
    """
    categories_dict = {
        "animals": [
            "cow",
            "rabbit",
            "duck",
            "shrimp",
            "pig",
            "goat",
            "crab",
            "deer",
            "bee",
            "sheep",
            "fish",
            "turkey",
            "dove",
            "chicken",
            "horse",
        ],
        "names": [
            "James",
            "Mary",
            "Robert",
            "Patricia",
            "John",
            "Jennifer",
            "Michael",
            "Linda",
            "William",
            "Elizabeth",
            "Ahmed",
            "Barbara",
            "Richard",
            "Susan",
            "Salomon",
            "Juan Luis",
        ],
        "cities": [
            "Stockholm",
            "Denver",
            "Moscow",
            "Marseille",
            "Palermo",
            "Tokyo",
            "Lisbon",
            "Oslo",
            "Nairobi",
            "Río de Janeiro",
            "Berlin",
            "Bogotá",
            "Manila",
            "Madrid",
            "Milwaukee",
        ],
        "colors": [
            "red",
            "orange",
            "yellow",
            "green",
            "blue",
            "indigo",
            "purple",
            "pink",
            "silver",
            "gold",
            "beige",
            "brown",
            "grey",
            "black",
            "white",
        ],
    }
    default_intervals = {
        "i": (0, 10),
        "f": (0, 100),
        "c": ("names", 5),
        "d": ("2020-01-01", "2020-12-31"),
    }
    rng = np.random.default_rng(seed)

    first_c = default_intervals["c"][0]
    categories_names = cycle([first_c] + [c for c in categories_dict.keys() if c != first_c])
    default_intervals["c"] = (categories_names, default_intervals["c"][1])

    if isinstance(col_names, list):
        assert len(col_names) == len(  # noqa : S101
            cols
        ), f"The fake DataFrame should have {len(cols)} columns but col_names is a list with {len(col_names)} elements"
    elif col_names is None:
        suffix = {"c": "cat", "i": "int", "f": "float", "d": "date"}
        col_names = [f"column_{str(i)}_{suffix.get(col)}" for i, col in enumerate(cols)]

    if isinstance(intervals, list):
        assert len(intervals) == len(  # noqa : S101
            cols
        ), f"The fake DataFrame should have {len(cols)} columns but intervals is a list with {len(intervals)} elements"
    else:
        if isinstance(intervals, dict):
            assert (  # noqa : S101
                len(set(intervals.keys()) - set(default_intervals.keys())) == 0
            ), "The intervals parameter has invalid keys"
            default_intervals.update(intervals)
        intervals = [default_intervals[col] for col in cols]
    df = pd.DataFrame()
    for col, col_name, interval in zip(cols, col_names, intervals):  # noqa : B905
        if interval is None:
            interval = default_intervals[col]
        assert (len(interval) == 2 and isinstance(interval, tuple)) or isinstance(  # noqa : S101
            interval, list
        ), f"This interval {interval} is neither a tuple of two elements nor a list of strings."
        if col in ("i", "f", "d"):
            start, end = interval
        if col == "i":
            df[col_name] = rng.integers(start, end, size)
        elif col == "f":
            df[col_name] = rng.uniform(start, end, size)
        elif col == "c":
            if isinstance(interval, list):
                categories = np.array(interval)
            else:
                cat_family, length = interval
                if isinstance(cat_family, cycle):
                    cat_family = next(cat_family)
                assert (  # noqa : S101
                    cat_family in categories_dict.keys()
                ), f"There are no samples for category '{cat_family}'.\
                 Consider passing a list of samples or use one of the available categories: {categories_dict.keys()}"
                categories = rng.choice(categories_dict[cat_family], length, replace=False, shuffle=True)
            df[col_name] = rng.choice(categories, size, shuffle=True)
        elif col == "d":
            df[col_name] = rng.choice(pd.date_range(start, end), size)
    return df


def generate_sample_hierarchical_data():
    """Function to generate sample hierarchical df."""
    # Using dummy data to create a hierarchical schema
    data = [
        {
            "patient_details": {
                "id": 234567,
                "disease": "fever",
                "lab": {"x-ray": True, "ultrasound": False},
                "other": {"race": "hispanic", "medical_history": "asthma"},
            },
            "entity_id": 16233,
            "code": 12783,
        }
    ]
    df = pd.DataFrame(data)
    return df


def validate_file(filename):
    """Function to check whether file exists at provided location or not."""
    if filename.startswith("dbfs:"):
        try:
            from pyspark.dbutils import DBUtils  # type: ignore
            from pyspark.sql import SparkSession  # type: ignore

            spark = SparkSession.builder.getOrCreate()
            dbutils = DBUtils(spark)
            dbutils.fs.ls(filename)
            return filename
        except Exception as e:
            print(f"Exception occurred while reading the file : {filename} -> {e}")
            sys.exit(2)
    elif filename.startswith("/"):
        if not os.path.exists(filename):
            print(f"{filename} does not exist")
            sys.exit(2)
        return filename
    else:
        raise NotImplementedError(f"{filename} is not yet supported - must start with either 'dbfs:' or '/'")


def apply_sql_template(template, parameters):
    """Apply a JinjaSql template (string) substituting parameters (dict) and return the final SQL."""
    j = JinjaSql(param_style="pyformat")
    query, bind_params = j.prepare_query(template, parameters)
    if not bind_params:
        return query
    return query % bind_params


def execute_query(query, db=None):
    """Function to execute query on Databricks directly, if not then remotely."""
    from pyspark.sql import SparkSession

    config_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(config_dir, "config.ini")
    config = ConfigParser()
    config.read(config_path)
    db_name = config["db-config"]["database"]
    if db is None:
        db = db_name

    spark = SparkSession.builder.getOrCreate()
    try:
        spark.sql(f"USE {db}")
        result = spark.sql(query).collect()
        return result
    except Exception as e:
        print(f"Exception occured while executing the query - {query} : {e}")
        return False
        # Databricks SQL Connect Code
        # warnings.warn("Couldn't execute query directly , trying using remote configuration ... ")
        # with sql.connect(server_hostname=DATABRICKS_SERVER_HOSTNAME,
        #                  http_path=DATABRICKS_HTTP_PATH,
        #                  access_token=DATABRICKS_TOKEN) as connection:
        #     with connection.cursor() as cursor:
        #         cursor.execute(query)
        #         result = cursor.fetchall()
        # return result


def generate_create_sql_template(table_name, cols, seed=10):
    """Function to generate CREATE sql templates dynamically."""
    df = generate_sample_dataframe(10, cols, seed=seed)
    from pyspark.sql import SparkSession

    spark = SparkSession.builder.getOrCreate()
    df = spark.createDataFrame(df)

    schema = ""
    length = len(df.dtypes)
    for i, item in enumerate(df.dtypes):
        schema += f"{item[0]} {item[1]}"
        if i < length - 1:
            schema += ", "
    return (
        "CREATE TABLE {{ if_not_exist_flag }}"
        + f" {table_name} ({schema}) USING DELTA"
        + " LOCATION '{{ location }}/"
        + table_name
        + "'"
    )


def generate_drop_sql_template(table_name):
    """Function to generate DROP sql templates dynamically."""
    template = "DROP TABLE {{ if_exist_flag }} " + table_name
    return template


def change_db(db_name):
    """Function to change the name of db in config dynamically."""
    config_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(config_dir, "config.ini")
    config = ConfigParser()
    config.read(config_path)
    old_db_name = config["db-config"]["database"]
    config.set("db-config", "database", db_name)
    with open(config_path, "w") as f:
        config.write(f, space_around_delimiters=False)  # use flag in case case you need to avoid white space.
    return old_db_name
