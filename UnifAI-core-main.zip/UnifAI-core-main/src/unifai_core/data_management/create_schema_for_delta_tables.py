"""Create schema given list of table names."""

import os

import yaml

from unifai_core.data_management.utils import execute_query


def main(table_names, output_dir):
    """Create schema.yaml given list of tables present in hive metastore. You can change schema in config if needed.

    Args:
        table_names: list of table names
        output_dir: directory where you want to save your schema file

    Returns:
        Boolean Flag : True if file created successfully False otherwise
    """
    try:
        schema = {}
        for table_name in table_names:
            table_schema = []
            sql_query = f"describe table {table_name}"
            result = execute_query(sql_query)
            for row in result[:-3]:
                table_schema.append({row["col_name"]: row["data_type"]})
            schema[table_name] = table_schema
        with open(os.path.join(output_dir, "schema.yaml"), "w") as f:
            yaml.dump(schema, f)
        return True
    except Exception as e:
        print(e)
        return False
