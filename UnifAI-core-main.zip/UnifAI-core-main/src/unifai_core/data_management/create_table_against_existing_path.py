"""Create delta table against an existing path."""

from unifai_core.data_management.utils import execute_query


def main(data_path, table_name):
    """Function to create delta table against an existing path.

    Args:
        data_path: existing path
        table_name: name of the delta table

    Returns:
        Query Output if table created successfully otherwise False
    """
    try:
        conversion_query = f"CONVERT TO DELTA parquet.`{data_path}`"
        execute_query(conversion_query)
        query = f"CREATE TABLE {table_name} USING DELTA LOCATION '{data_path}'"
        result = execute_query(query)
        return result
    except Exception as e:
        print("Exception occurred while creating the table : ", e)
        return False
