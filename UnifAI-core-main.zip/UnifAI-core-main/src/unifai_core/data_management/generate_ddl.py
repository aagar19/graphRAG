"""Generate DDL from existing file."""

import traceback
from typing import Tuple


def create_table_ddl(data_path, table_name, location, table_format="DELTA", if_not_exist_flag=True) -> Tuple[bool, str]:
    """Function to retrieve the CREATE DDL statement from a parquet table.

    Args:
        data_path: path to the parquet table
        table_name: the name of the table we want to create
        location: Path where table data will be stored
        table_format: (Optional) format of the table like DELTA, PARQUET etc.  Default is DELTA
        if_not_exist_flag: (Optional) if we want to put IF NOT EXIST flag in our create query Default is True

    Returns:
        Boolean Flag (True if query is created successfully else False), CREATE DDL statement
    """
    try:
        # Starting a spark session
        from pyspark.sql.session import SparkSession  # type: ignore

        spark = SparkSession.builder.getOrCreate()
        df = spark.read.parquet(data_path)

        if if_not_exist_flag:
            if_not_exist = " IF NOT EXISTS"
        else:
            if_not_exist = ""

        schema = ""
        length = len(df.dtypes)
        for i, item in enumerate(df.dtypes):
            schema += f"{item[0]} {item[1]}"
            if i < length - 1:
                schema += ", "
        create_qry = f"""CREATE TABLE{if_not_exist} {table_name}
({schema})
USING {table_format}
LOCATION '{location}'"""

        return True, create_qry
    except Exception as e:
        print(traceback.format_exc())
        return False, str(e)
