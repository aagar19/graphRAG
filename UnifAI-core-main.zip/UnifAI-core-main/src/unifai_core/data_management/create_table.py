"""Create table given an sql file containing CREATE DDL command."""

import os
import re
import warnings
from configparser import ConfigParser

from unifai_core.data_management.utils import apply_sql_template
from unifai_core.data_management.utils import execute_query


def format_warning(message, category, filename, lineno, line="\n"):
    """Formatting warnings."""
    return f"{filename} : {lineno} : {category.__name__} : {message} {line}"


warnings.formatwarning = format_warning


def if_table_exists(query):
    """Function to check if table exists already."""
    regex = r"CREATE\s(EXTERNAL\s)?TABLE\s{{.*?}}\s([a-z].*)[\s\n\r\t]"
    match = re.search(regex, query, re.IGNORECASE)
    config_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(config_dir, "config.ini")
    config = ConfigParser()
    config.read(config_path)
    db_name = config["db-config"]["database"]
    if match:
        table_name = match.group(2)
        qry = f"show tables in {db_name}"
        result = execute_query(qry)
        if any([x["tableName"] == table_name for x in result]):
            print(f"{table_name} Table exists in the Database : {db_name}")
        else:
            print(f"{table_name} Table does not exists in the Database : {db_name}")
    else:
        warnings.warn("Couldn't Parse Table name from the query")  # noqa: B028


def main(file_path, root_location, if_not_exist_flag=True):
    """Function to create a table.

    Args:
        file_path: jinja sql template file containing CREATE DDL command
        root_location: location to give the table in blobstorage
        if_not_exist_flag: whether to keep IF NOT EXIST command in the query

    Returns:
        Query Output if table created successfully otherwise False

    Raises:
        NotImplementedError: when path doesn't begin with 'dbfs:' (filesystem on remote databricks server)
            or '/' (local file system)
    """
    try:
        if file_path.startswith("dbfs:"):
            from pyspark.sql import SparkSession  # type: ignore

            spark = SparkSession.builder.getOrCreate()
            template_query = spark.read.text(file_path, wholetext=True).collect()[0][0]
        elif file_path.startswith("/"):
            with open(file_path) as f:
                template_query = f.read()
        else:
            raise NotImplementedError(f"{file_path} is not yet supported - must start with either 'dbfs:' or '/'")

        # Checking if table exists
        if_table_exists(template_query)

        # Parsing the Query
        params = {"if_not_exist_flag": r"IF NOT EXISTS" if if_not_exist_flag else r"", "location": root_location}
        final_query = apply_sql_template(template_query, params)

        # Create Table
        result = execute_query(final_query)
        return result
    except Exception as e:
        print("Exception occurred while creating the table : ", e)
        return False
