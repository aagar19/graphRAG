"""Utilites for managing differences between local and remote filesystems."""

import os
from typing import Callable
from typing import List


DirectoryLister = Callable[[str], List[str]]


def filesystem_function(path: str) -> DirectoryLister:
    """Returns a tuple of functions to manage files based on the location of path.

    Args:
        path: path to be manipulated.

    Returns:
        Tuple of length 1 with a function for listing the files located at path

    Raises:
        NotImplementedError: when path doesn't begin with 'dbfs:' (filesystem on remote databricks server)
            or '/' (local file system)
    """
    if path.startswith("dbfs:"):
        return db_ls_wrapper
    elif path.startswith("/"):
        return os.listdir

    raise NotImplementedError(f"{path} is not yet supported - must start with either 'dbfs:' or '/'")


def db_ls_wrapper(path: str) -> List[str]:
    """Translates a list Databricks FileInfo objects to strings."""
    from pyspark.dbutils import DBUtils  # type: ignore
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    dbutils = DBUtils(spark)

    return [pe.path for pe in dbutils.fs.ls(path)]
