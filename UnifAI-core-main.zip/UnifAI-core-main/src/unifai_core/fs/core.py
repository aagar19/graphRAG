"""Implents basic file system functionality."""

from typing import List

from unifai_core.fs.utils import filesystem_function


def ls(path: str) -> List[str]:
    """Returns the directory contents of path regardless of physical location."""
    lister = filesystem_function(path)
    return lister(path)
