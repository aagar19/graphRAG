"""functionalities related to content_check."""

from datetime import datetime
from typing import Optional

from pyspark.sql import SparkSession

from unifai_core.app.conf import ApplicationConfiguration
from unifai_core.app.utils import clean_path
from unifai_core.app.utils import db_run_job
from unifai_core.cli.types import Settings
from unifai_core.data_quality.utils import _get_env_variables
from unifai_core.data_quality.utils import _get_output_path
from unifai_core.data_quality.utils import _insert_data
from unifai_core.data_quality.utils import _setup_job_cluster


def run_content_check(
    settings: Settings,
    app_name: str,
    extra_args: dict,
    orchestration_id: Optional[str] = None,
    orchestration_data: Optional[dict] = None,
) -> None:
    r"""Function to trigger spark submit job to run chimera.

    Args:
        settings: contains databricks host id, cluster id and schema name
        app_name: application name
        orchestration_id: airflow orchestration id
        orchestration_data: airflow orchestration data
        extra_args: extra arguments for content check run e.g. output_path etc.

    Raises:
        RuntimeError: if fetching of data fails from metadata tables
    """
    spark = SparkSession.builder.getOrCreate()
    # Load application configuration
    application = ApplicationConfiguration(app_name=app_name, spark=spark)

    # Prepare configuration
    run_name = f"UnifAI Data-Quality (Chimera) - {application.name}.content-check"
    config_location = clean_path(
        application.get(f"DATA_QUALITY_{extra_args.get('config_type')}_CONTENT_CHECK"), "file:/dbfs"
    )
    chimera_jar_location = clean_path(application.get("DATA_QUALITY_DEP_CHIMERA"), "/dbfs")
    start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Prepare ENV variables
    env_variables = _get_env_variables(extra_args)
    schema = env_variables.get("UNIFAI_SCHEMA")
    if not schema:
        schema = settings["SCHEMA_NAME"]
        env_variables["UNIFAI_SCHEMA"] = schema
    output_path = env_variables.get("OUTPUT_PATH")
    if not output_path:
        output_path = (
            _get_output_path(application.name, schema, orchestration_id)
            + f"/{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        env_variables["OUTPUT_PATH"] = output_path

    submit_body = {
        "run_name": run_name,
        "spark_submit_task": {
            "parameters": [
                "--conf",
                "spark.app.name=chimera",
                "--conf",
                "spark.chimera.config.provider=dbfs",
                "--conf",
                f"spark.chimera.config.sources={config_location}/sources.yaml",
                "--conf",
                f"spark.chimera.config.dataset={config_location}/dataset.yaml",
                "--conf",
                f"spark.chimera.config.checks={config_location}/checks.yaml",
                "--conf",
                f"spark.chimera.config.sinks={config_location}/sinks.yaml",
                "--conf",
                f"spark.chimera.config.app={config_location}/app.yaml",
                "--conf",
                f"spark.chimera.config.providers={config_location}/providers.yaml",
                "--conf",
                f"spark.chimera.config.env={config_location}/env.yaml",
                "--class",
                "com.optum.chimera.Application",
                chimera_jar_location,
                ",".join([f"{k}={v}" for k, v in env_variables.items()]),
            ],
        },
        "new_cluster": _setup_job_cluster(application, "Data-Quality (Chimera) content-check", {}),
    }
    status, job_id, run_id = db_run_job(run_name, f"{settings['DATABRICKS_HOST']}", submit_body)
    status_msg = None if status else f"Databricks failed to execute content-check for: {application.name}"
    _insert_data(
        settings,
        application,
        job_id,
        run_id,
        status_msg,
        "content_check_report.py",
        "chimera",
        config_location,
        start_time,
        ",".join([f"{k}={v}" for k, v in env_variables.items()]),
        orchestration_id,
        orchestration_data,
    )
    if not status:
        raise RuntimeError(status_msg)
