"""utitlity fucnctions for data quality submodule."""

import json
from datetime import datetime
from typing import Optional
from uuid import uuid4

from unifai_core.app.conf import ApplicationConfiguration
from unifai_core.app.utils import clean_path
from unifai_core.app.utils import db_run_job
from unifai_core.app.utils import retry_spark_sql
from unifai_core.cli.types import Settings
from unifai_core.cli.utils import JOB_CLUSTER_JSON


def _insert_data(
    settings: Settings,
    application: ApplicationConfiguration,
    databricks_job_id: Optional[str],
    databricks_run_id: Optional[str],
    databricks_status_msg: Optional[str],
    python_file: str,
    layer: str,
    config_location: str,
    start_time: str,
    additional_params: Optional[str] = None,
    orchestration_id: Optional[str] = None,
    orchestration_data: Optional[dict] = None,
):
    """Function to trigger a spark submit job to insert the data into DQ and metadata tables."""
    run_name = f"UnifAI Data-Quality (Metadata Insert) - {application.name}.{layer}"
    config_location = config_location.replace("file:", "")
    parameters = [
        "--app-name",
        application.name,
        "--start-time",
        start_time,
        "--end-time",
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "--databricks-host",
        settings["DATABRICKS_HOST"],
        "--databricks-job-id",
        databricks_job_id,
        "--databricks-run-id",
        databricks_run_id,
        "--job-status",
        ("1" if databricks_status_msg else "0"),
        "--job-status-message",
        str(databricks_status_msg),
        "--config-location",
        config_location,
        "--extra-args",
        additional_params,
        "--layer",
        layer,
        "--orchestration-id",
        orchestration_id,
        "--schema",
        settings["SCHEMA_NAME"],
    ]
    if orchestration_data:
        parameters.extend(["--orchestration-data", json.dumps(orchestration_data)])
    submit_body = {
        "run_name": run_name,
        "spark_python_task": {
            "python_file": (
                f"{clean_path(application.get('FILE_STORE_PATH'), 'dbfs:')}/code/unifai_core/remote/{python_file}"
            ),
            "parameters": parameters,
        },
        # TODO: should the get replaced with a job cluster ?
        "existing_cluster_id": settings["DATABRICKS_CLUSTER_ID"],
        # "new_cluster": _setup_job_cluster(application),
    }

    status, _, run_id = db_run_job(run_name, f"{settings['DATABRICKS_HOST']}", submit_body)
    print(run_id)
    if not status:
        raise RuntimeError(f"Databricks failed to complete the {layer} metadata insert job!")
    return run_id


def _get_env_variables(args: dict, exclude: Optional[list] = None) -> dict:
    """Filter the arguments, for items to be included as ENV variables."""
    return {str(k).upper(): v for k, v in args.items() if k not in (exclude or [])}


def _get_output_path(name: str, schema: str, run_id: Optional[str] = None):
    """Return the respective blob storage path for DQ run."""
    base_path = f"dbfs:/mnt/azureblobshare/output/{schema}/{name}"
    return base_path + (f"/{run_id}" if run_id else "")


def _setup_job_cluster(application: ApplicationConfiguration, job_name: str, env_variables: dict) -> dict:
    """Add the cluster definition to the SPARK json."""
    job_cluster = json.loads(application.parse_with_config(JOB_CLUSTER_JSON, {"JOB_NAME": job_name}))
    # Update INIT script
    if application.script_path:
        job_cluster["init_scripts"] = [{"workspace": {"destination": clean_path(application.script_path)}}]
    # Update ENV variables
    if application.env_variables:
        job_cluster["spark_env_vars"] = {**application.env_variables, **env_variables}
    # Update SPARK config
    if application.spark_config:
        job_cluster["spark_conf"] = {**job_cluster.get("spark_conf", {}), **application.spark_config}
    return job_cluster


def _update_runs(spark, run_id: str, runs_dict: dict):
    """Inserts into Data Quality Runs table."""
    status_message = runs_dict["jobs_status_message"].replace("'", "")

    insert_sql = f"""
    MERGE INTO unifai_core_data_quality_runs AS t
    USING (SELECT '{run_id}' AS id) AS s ON t.id = s.id WHEN NOT MATCHED THEN
        INSERT (id, application_id, databricks_id, orchestration_id, start_time, end_time, run_user_id, run_as_of,
                configuration, job_status, job_status_message, checks_passed, app_hash, unifai_hash)
        VALUES ('{run_id}',
                '{runs_dict['application_id']}',
                '{runs_dict['databricks_id']}',
                '{runs_dict['orchestration_id']}',
                CAST({runs_dict['start_time'].timestamp()} AS TIMESTAMP),
                CAST({runs_dict['end_time'].timestamp()} AS TIMESTAMP),
                current_user(),
                current_timestamp(),
                '{runs_dict['configuration']}',
                '{runs_dict['job_status']}',
                '{status_message}',
                '{runs_dict['checks_passed']}',
                '{runs_dict['app_hash']}',
                '{runs_dict['unifai_hash']}')
    """
    retry_spark_sql(spark, insert_sql, sleep=20)
    return run_id


def _update_results(spark, run_id: str, results_dict: dict, layer):
    """Inserts into Data Quality results table."""
    for _, result_dict in results_dict.items():
        insert_sql = f"""
            INSERT INTO unifai_core_data_quality_results
                (id, application_id, data_quality_run_id, orchestration_id, view_name, table_status, layer)
                VALUES (
                    '{str(uuid4())}',
                    '{result_dict['application_id']}',
                    '{run_id}',
                    '{result_dict['orchestration_id']}',
                    '{result_dict['view_name']}',
                    '{result_dict['accept']}',
                    '{layer}')
            """
        retry_spark_sql(spark, insert_sql, sleep=20)


def _update_summary(spark, run_id: str, summary_dicts: dict):
    """Inserts into Content check summary table."""
    for _, summary_dict in summary_dicts.items():
        insert_sql = f"""
            INSERT INTO unifai_core_data_quality_content_check_summary
                (id, application_id, data_quality_run_id, orchestration_id, view_name, check_name, actual_rows,
                total_joined_rows, eligible_rows, bad_rows, clean_rows)
            VALUES (
                '{str(uuid4())}',
                '{summary_dict['application_id']}',
                '{run_id}',
                '{summary_dict['orchestration_id']}',
                '{summary_dict['view_name']}',
                '{summary_dict['check_name']}',
                '{summary_dict['actual_rows']}',
                '{summary_dict['total_joined_rows']}',
                '{summary_dict['eligible_rows']}',
                '{summary_dict['bad_rows']}',
                '{summary_dict['clean_rows']}')
        """
        retry_spark_sql(spark, insert_sql, sleep=20)


def _update_dataset_summary(spark, run_id: str, dataset_summary_dicts: dict):
    """Inserts into content check dataset summary table."""
    for _, dataset_summary_dict in dataset_summary_dicts.items():
        insert_sql = f"""
            INSERT INTO unifai_core_data_quality_content_check_dataset_summary
                (id, application_id, data_quality_run_id, orchestration_id, view_name, total_rows, bad_rows,
                clean_rows, bad_rows_percentage, accept)
            VALUES (
                '{str(uuid4())}',
                '{dataset_summary_dict['application_id']}',
                '{run_id}',
                '{dataset_summary_dict['orchestration_id']}',
                '{dataset_summary_dict['view_name']}',
                '{dataset_summary_dict['total_rows']}',
                '{dataset_summary_dict['bad_rows']}',
                '{dataset_summary_dict['clean_rows']}',
                '{dataset_summary_dict['bad_row_percent']}',
                '{dataset_summary_dict['accept']}')
        """
        retry_spark_sql(spark, insert_sql, sleep=20)


def _update_bad_records(spark, run_id: str, bad_records_dict: dict):
    """Inserts into content check bad records table."""
    insert_sql = f"""
        INSERT INTO unifai_core_data_quality_content_check_bad_records
            (id, application_id, data_quality_run_id, orchestration_id, input_table, check, record_id,
            SEVERITY, ERROR_CODE, FAILURE_REASON)
        VALUES (
            '{str(uuid4())}',
            '{bad_records_dict['application_id']}',
            '{run_id}',
            '{bad_records_dict['orchestration_id']}',
            '{bad_records_dict['input_table']}',
            '{bad_records_dict['check']}',
            '{bad_records_dict['record_id']}',
            '{bad_records_dict['SEVERITY']}',
            '{bad_records_dict['ERROR_CODE']}',
            '{bad_records_dict['FAILURE_REASON']}')
        """
    retry_spark_sql(spark, insert_sql)


def _update_ai_check_summary(spark, run_id: str, dataset_summary_dicts: dict):
    """Inserts into content check dataset summary table."""
    for _, dataset_summary_dict in dataset_summary_dicts.items():
        insert_sql = f"""
                INSERT INTO unifai_core_data_quality_ai_check_summary
                (id, application_id, data_quality_run_id, orchestration_id, model_name, total_tests_ran, total_tests_failed,
                    total_tests_passed, total_fail_percentage)
                VALUES (
                    '{str(uuid4())}',
                    '{dataset_summary_dict['application_id']}',
                    '{run_id}',
                    '{dataset_summary_dict['orchestration_id']}',
                    '{dataset_summary_dict['model_name']}',
                    '{dataset_summary_dict['Total Tests Ran']}',
                    '{dataset_summary_dict['Total Tests Failed']}',
                    '{dataset_summary_dict['Total Tests Passed']}',
                    '{dataset_summary_dict['Test Fail Percentage']}')
        """
        retry_spark_sql(spark, insert_sql, sleep=20)
