from eval_rule_factory.eval_rule import EvalRule


class RateAnalysis(EvalRule):
    def get_eval_rule(self, rule_name, decision_logic, args):
        return self._get_eval_rule("rateanalysis", rule_name, decision_logic, args)

    class Factory:
        def create(self):
            return RateAnalysis()
