from eval_rule_factory.eval_rule import EvalRule


class TimeseriesAnalysis(EvalRule):
    def get_eval_rule(self, rule_name, decision_logic, args):
        return self._get_eval_rule("timeseriesanalysis", rule_name, decision_logic, args)

    class Factory:
        def create(self):
            return TimeseriesAnalysis()
