from eval_rule_factory.classdist_analysis import ClassDistAnalysis  # noqa: F401
from eval_rule_factory.rate_analysis import RateAnalysis


class LargeDistAnalysis(RateAnalysis):
    def get_eval_rule(self, rule_name, decision_logic, args):
        return self._get_eval_rule("classdistanalysis", rule_name, decision_logic, args, 5)

    class Factory:
        def create(self):
            return LargeDistAnalysis()
