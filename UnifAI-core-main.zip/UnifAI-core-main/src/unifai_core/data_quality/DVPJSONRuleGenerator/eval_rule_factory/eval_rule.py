from collections import namedtuple

from rule import Rule


class EvalRule(Rule):
    rule_def = namedtuple("ruledef", "args, name, evaluation, decision_logic, technique_args")

    def __init__(self):
        pass

    def _get_eval_rule(self, rule_type, rule_name, decision_logic, args, limit=None):
        guid = self.get_guid(rule_name)

        metric_rule_row, metric_rule_definition = args
        arg = self.get_arg("metric", metric_rule_row, metric_rule_definition)
        arg["limit"] = limit

        rule_row_record = self.rule_row(
            metric_rule_row.model_name,
            metric_rule_row.column_name,
            rule_name,
            metric_rule_row.entity_type,
            rule_type,
            None,
            guid,
        )

        rule_definition = self.rule_def([arg], rule_name, rule_type, decision_logic, None)
        return rule_row_record, rule_definition

    def get_arg(self, source, metric_rule_row, metric_rule_definition):
        arg = {}
        arg["limit"] = None
        arg["model"] = metric_rule_row.model_name
        arg["column"] = metric_rule_row.column_name
        arg["method"] = None
        arg["source"] = source
        arg["values"] = metric_rule_row.rule_type
        arg["rule_name"] = metric_rule_row.rule_name
        arg["entity_type"] = metric_rule_row.entity_type

        return arg
