from eval_rule_factory.rate_analysis import RateAnalysis


class ClassDistAnalysis(RateAnalysis):
    def get_eval_rule(self, rule_name, decision_logic, args):
        return self._get_eval_rule("classdistanalysis", rule_name, decision_logic, args)

    class Factory:
        def create(self):
            return ClassDistAnalysis()
