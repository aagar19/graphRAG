from eval_rule_factory.eval_rule import EvalRule


class NumdistAnalysis(EvalRule):
    def get_eval_rule(self, rule_name, decision_logic, args):
        output_args = []

        for measure in args:
            m_type, m_row, m_def = measure
            arg = self.get_arg("measure", m_row, m_def)
            arg["method"] = m_def.aggregate
            output_args.append(arg)

            guid = self.get_guid(rule_name)
            rule_row_record = self.rule_row(
                m_row.model_name, m_row.column_name, rule_name, m_row.entity_type, "numdistanalysis", None, guid
            )

        rule_definition = self.rule_def(output_args, rule_name, "numdistanalysis", decision_logic, None)

        return rule_row_record, rule_definition

    class Factory:
        def create(self):
            return NumdistAnalysis()
