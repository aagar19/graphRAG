import json
import os

from dvp_expr_file_map import ExprFiles
from file_io import FileIO
from rule_overrider import RuleOverrider


class JSONOutputAdaptor:
    run_id = "Dummy"

    def __init__(self, run_id, configfolder, userconfigfolder, defaultfolder="default"):
        self.run_id = str(run_id)
        self.rule_overrider = RuleOverrider(configfolder, userconfigfolder, defaultfolder)

    def get_eval_rule_type(self, rule_type):
        eval_rule_dict = {
            "fraction": "rateanalysis",
            "class_distribution": "classdistanalysis",
            "timeseries_distribution": "timeseriesanalysis",
            "mad_qreg": "mad_qreg_timeseriesanalysis",
            "largedist": "classdistanalysis",
            "numdist": "numdistanalysis",
        }
        return eval_rule_dict[rule_type]

    def get_partition_map(self, partition_file):
        with open(partition_file) as file:
            partition_map = json.load(file)
        for model, partition_list in partition_map.items():
            if not partition_list:
                partition_map[model] = None
            else:
                partition_map[model] = partition_list
        return partition_map

    def deduplicate_rules(self, rules):
        unique_rules_dict = {}
        for rule in rules:
            unique_rules_dict[rule["rule_name"]] = rule
        return unique_rules_dict.values()

    def save(self, partition_file, list_dvp_rules, list_expr_files, base_path, configfolder, level):
        partition_map = self.get_partition_map(partition_file)
        clients = []
        clients = os.listdir(configfolder)
        for client in clients:
            client_sub_folder = os.path.join(level, client)
            self.save_for_entity(
                partition_map, list_dvp_rules["measure"], "measure", base_path, client_sub_folder, client
            )
            self.save_for_entity(
                partition_map, list_dvp_rules["metric"], "metric", base_path, client_sub_folder, client
            )
            self.save_for_entity(
                partition_map, list_dvp_rules["eval"], "evaluation", base_path, client_sub_folder, client
            )
            self.save_expr_files(list_expr_files, level, base_path, client_sub_folder)

    def save_expr_files(self, list_expr_files, level, base_path, client_sub_folder):
        expr_files_map = ExprFiles().expression_files_per_layer
        for expr_file in list_expr_files:
            name = expr_file.split("/")[-1]
            for layer, expression_files in expr_files_map.items():
                if name in expression_files:
                    file_path = expr_file.split(level)[-1].lstrip("/")
                    if layer == "report_generator":
                        self.save_report_expression_files(
                            expr_file, file_path, layer, level, base_path, client_sub_folder
                        )
                    else:
                        file_name_to_write = self.format_output_path(base_path, client_sub_folder, layer, file_path)
                        self.write_expression_file(expr_file, file_name_to_write)

    def save_report_expression_files(self, expr_file, file_path, layer, level, base_path, client_sub_folder):
        comparator_folders = ExprFiles().comparators_per_layer[layer]
        if not self.check_comparator_in_path(file_path, comparator_folders):
            for comparator_folder in comparator_folders:
                name = expr_file.split("/")[-1]
                file_path = comparator_folder + "/" + name
                file_name_to_write = self.format_output_path(base_path, client_sub_folder, layer, file_path)
                self.write_expression_file(expr_file, file_name_to_write)
        else:
            file_name_to_write = self.format_output_path(base_path, client_sub_folder, layer, file_path)
            self.write_expression_file(expr_file, file_name_to_write)

    def check_comparator_in_path(self, expression_file_path, comparator_folders):
        for comparator_folder in comparator_folders:
            if comparator_folder in expression_file_path:
                return True
        return False

    def write_expression_file(self, expr_file, file_name_to_write):
        # Read the file as json and write it in the final location.
        # Throws error if the json schema is wrong
        if os.stat(expr_file).st_size == 0:
            empty_file_content = ""
            FileIO().write_file(empty_file_content, file_name_to_write)
        else:
            with open(expr_file) as file:
                file_content_json = json.load(file)
            FileIO().write_file(json.dumps(file_content_json, indent=4), file_name_to_write)

    def save_for_entity(self, partition_map, rule_list, module, base_path, client_sub_folder, client):
        rule_list = self.deduplicate_rules(rule_list)
        model_rules_mapping = {}
        for rule in rule_list:
            rule["partition_cols"] = partition_map[rule["model_name"]]
            if rule["model_name"] in model_rules_mapping.keys():
                model_rules_mapping[rule["model_name"]].append(rule)
            else:
                model_rules_mapping[rule["model_name"]] = [rule]

        for model_name, rules in model_rules_mapping.items():
            overrided_rules = self.rule_overrider.override_per_client_layer(rules, model_name, client, module)
            overrided_rules = (
                json.dumps(overrided_rules, indent=4).replace("#!", "{").replace("!#", "}").replace("##", ":")
            )
            file_name = self.format_output_path(base_path, client_sub_folder, module, model_name) + ".rules"
            rule_file_content = '{ "rules" : ' + overrided_rules + "}"
            FileIO().write_file(rule_file_content, file_name)

    def format_output_path(self, input_base_path, sub_folder, module, file_name):
        output_base_path = os.path.join(FileIO().get_parent_dir_path(input_base_path), "output")
        return os.path.join(output_base_path, sub_folder, module, file_name)
