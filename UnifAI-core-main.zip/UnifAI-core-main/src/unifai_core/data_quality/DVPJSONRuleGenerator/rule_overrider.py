import json
import os

from file_io import FileIO
from utils import UtilityMethods


class RuleOverrider:
    default_params = {}
    default_user_params = {}
    config_path = ""

    def __init__(self, config_path, userconfig_path, default_folder="default"):
        self.utility_methods = UtilityMethods()
        self.config_path = config_path
        self.userconfig_path = userconfig_path
        default_location = os.path.join(config_path, default_folder)
        files = FileIO().get_override_params(default_location).pop()
        with open(files) as file:
            self.default_params = json.load(file)
        if userconfig_path:
            default_userconfig_location = os.path.join(userconfig_path, default_folder)
            user_files = FileIO().get_override_params(default_userconfig_location).pop()
            with open(user_files) as file:
                self.default_user_params = json.load(file)

    def override_per_rule(self, rule_json, overrides_per_rule):
        for override in overrides_per_rule:
            rule_json = self.utility_methods.updateTemplate(rule_json, override["overrides"])
        return rule_json

    def override_per_rule_type(self, rule_json, overrides_per_rule_type):
        default_override = [x for x in overrides_per_rule_type if x["rule_name"] is None]
        rule_override = [x for x in overrides_per_rule_type if x["rule_name"] == rule_json["rule_name"]]
        rule_json = self.override_per_rule(rule_json, default_override)
        rule_json = self.override_per_rule(rule_json, rule_override)
        return rule_json

    def override_per_entity(self, rules, entity_override):
        overrided_rules = []
        for rule_json in rules:
            rule_type_override = [
                x["rule_metadata"] for x in entity_override if x["rule_type"] == rule_json["rule_type"]
            ]
            for override in rule_type_override:
                rule_json = self.override_per_rule_type(rule_json, override)
            overrided_rules.append(rule_json)
        return overrided_rules

    def override_per_client_layer(self, rules, entity, client, layer):
        overrided_rules = rules
        client_override_json = (
            [self.default_params, self.default_user_params]
            if len(self.default_user_params) != 0
            else [self.default_params]
        )
        if not client.endswith("default"):
            files = FileIO().get_override_params(os.path.join(self.config_path, client))
            for file in files:
                with open(file) as file:
                    params = json.load(file)
                    client_override_json.append(params)
        overrides_per_layer = []
        for overrides in client_override_json:
            layer_override = overrides.copy()
            layer_spec = [x["metadata"].copy() for x in overrides["specifications"] if layer == x["layer"]]
            if layer_spec:
                layer_override["specifications"] = layer_spec.copy().pop()
                overrides_per_layer.append(layer_override)
        default_override = [x["specifications"] for x in overrides_per_layer if x["entity"] == None]  # noqa: E711
        entity_override = [x["specifications"] for x in overrides_per_layer if x["entity"] == entity]
        for override in default_override:
            overrided_rules = self.override_per_entity(rules, override)
        for override in entity_override:
            overrided_rules = self.override_per_entity(rules, override)
        return overrided_rules
