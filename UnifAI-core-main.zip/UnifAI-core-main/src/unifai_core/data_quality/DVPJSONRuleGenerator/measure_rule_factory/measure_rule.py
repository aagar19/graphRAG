from collections import namedtuple  # noqa: F401

from rule import Rule


class MeasureRule(Rule):
    def get_rule_name(self, aggregate, entity, where_clause, segment_clause, timeseries_clause, lookup_clause):
        rule_name = aggregate.aggregate.upper() + "on" + entity.model_name.upper() + "."
        rule_name += (entity.column_name.upper()) if entity.column_name else ""
        rule_name += (" where " + where_clause) if where_clause else ""
        rule_name += (" on segment " + segment_clause) if segment_clause else ""
        rule_name += (
            (
                " on "
                + timeseries_clause.timeseries_interval
                + " timeseries "
                + timeseries_clause.start_entity.column_name
            )
            if timeseries_clause and timeseries_clause.start_entity
            else ""
        )
        # monthly rules will have the old rule naming convention for measure layer to avoid migration of cdr/oadw rules during Release 4.5.0
        rule_name = rule_name.replace("monthly ", "")
        rule_name += (
            (" end column as " + timeseries_clause.end_entity.column_name)
            if timeseries_clause and timeseries_clause.end_entity
            else ""
        )
        rule_name += (
            (
                " by lookup " + lookup_clause.entity.model_name.upper() + "." + lookup_clause.entity.column_name.upper()
                if lookup_clause.entity.column_name
                else ""
            )
            if lookup_clause
            else ""
        )
        rule_name += (" with additional criteria " + lookup_clause.additional_join_criteria) if lookup_clause else ""
        rule_name = rule_name.replace("\\", "#")
        return rule_name
