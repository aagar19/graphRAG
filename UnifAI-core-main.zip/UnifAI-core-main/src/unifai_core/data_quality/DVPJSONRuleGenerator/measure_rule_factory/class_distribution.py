from collections import namedtuple

from measure_rule_factory.measure_rule import MeasureRule


class ClassDistribution(MeasureRule):
    rule_def = namedtuple("rule_def", "on, aggregate, filter")

    def get_measure_rule(self, args):
        aggregate = args[0][1]
        entity = args[1][1]
        where_clause = None
        segment_clause = None
        if len(args) == 4:
            where_clause = args[2][1]
            segment_clause = (args[3][1]).split(",")
        else:
            segment_clause = (args[2][1]).split(",")

        rule_name = self.get_rule_name(aggregate, entity, where_clause, ",".join(segment_clause), None, None)

        guid = self.get_guid(rule_name)

        rule_row_record = self.rule_row(
            entity.model_name.upper(),
            entity.column_name.upper() if entity.column_name else None,
            rule_name,
            entity.entity_type,
            "class_distribution",
            None,
            guid,
        )
        rule_definition = self.rule_def(segment_clause, aggregate.aggregate.upper(), where_clause)

        return rule_row_record, rule_definition

    class Factory:
        def create(self):
            return ClassDistribution()
