from collections import namedtuple

from dvp_rule_definition import DVPRuleDefinition  # noqa: F401
from dvp_rule_type import DVPMeasureType
from measure_rule_factory.measure_rule import MeasureRule


class TimeseriesDistribution(MeasureRule):
    rule_def = namedtuple("rule_def", "on, endcolumn, onsegment, aggregate, intervals, filter")
    time_intervals = {
        "yearly": "year",
        "daily": "year|month|day",
        "weekly": "year|weekofyear",
        "quarterly": "year|quarter",
        "monthly": "month|year",
    }

    def get_measure_rule(self, args):
        # based on the grammar
        # , when there are 5 args , then text has where / segment and timeseries
        # when there are 4 args, then text has where and timeseries
        # when there are 3 args, then text has tiemseries
        aggregate = args[0][1]
        entity = args[1][1]
        where_clause = None
        segment_clause = None
        if len(args) == 5:
            where_clause = args[2][1]
            segment_clause = args[3][1].split(",")
            timeseries_clause = args[4][1]
        elif len(args) == 4:
            if args[2][0] == DVPMeasureType.class_distribution:
                segment_clause = args[2][1].split(",")
            else:
                where_clause = args[2][1]
            timeseries_clause = args[3][1]
        else:
            timeseries_clause = args[2][1]
        rule_name = self.get_rule_name(
            aggregate,
            entity,
            where_clause,
            ",".join(segment_clause) if segment_clause else None,
            timeseries_clause,
            None,
        )

        guid = self.get_guid(rule_name)

        rule_definition = self.rule_def(
            timeseries_clause.start_entity.column_name,
            timeseries_clause.end_entity.column_name if timeseries_clause.end_entity else None,
            segment_clause,
            aggregate.aggregate.upper(),
            self.time_intervals[timeseries_clause.timeseries_interval],
            where_clause,
        )

        rule_row_record = self.rule_row(
            entity.model_name.upper(),
            entity.column_name.upper() if entity.column_name else None,
            rule_name,
            entity.entity_type,
            "timeseries_distribution",
            None,
            guid,
        )
        return rule_row_record, rule_definition

    class Factory:
        def create(self):
            return TimeseriesDistribution()
