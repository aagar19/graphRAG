from collections import namedtuple

from measure_rule_factory.measure_rule import MeasureRule


class AggregateByLookup(MeasureRule):
    rule_def = namedtuple(
        "rule_def", "aggregate, lookup_model_name, lookup_column_name, additional_join_criteria, filter"
    )

    def get_measure_rule(self, args):
        aggregate = args[0][1]
        entity = args[1][1]
        where_clause = None

        if len(args) > 3:
            lookup_clause = args[3][1]
            where_clause = args[2][1]
        else:
            lookup_clause = args[2][1]

        rule_name = self.get_rule_name(aggregate, entity, where_clause, None, None, lookup_clause)

        guid = self.get_guid(rule_name)

        rule_row_record = self.rule_row(
            entity.model_name.upper(),
            entity.column_name.upper() if entity.column_name else None,
            rule_name,
            entity.entity_type,
            "aggregates_by_lookup",
            None,
            guid,
        )
        rule_definition = self.rule_def(
            aggregate.aggregate.upper(),
            lookup_clause.entity.model_name,
            lookup_clause.entity.column_name,
            lookup_clause.additional_join_criteria,
            where_clause,
        )

        return rule_row_record, rule_definition

    class Factory:
        def create(self):
            return AggregateByLookup()
