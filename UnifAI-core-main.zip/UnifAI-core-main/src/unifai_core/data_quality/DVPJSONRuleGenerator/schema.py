measure_schema = {
    "definitions": {},
    "$schema": "",
    "$id": "http://example.com/root.json",
    "type": "object",
    "title": "the root schema",
    "default": None,
    "minProperties": 1,
    "maxProperties": 5,
    "additionalProperties": False,
    "properties": {
        "aggregates": {
            "$id": "#/properties/aggregates",
            "type": "array",
            "title": "The Aggregates Schema",
            "items": {
                "$id": "#/properties/aggregates/items",
                "type": "string",
                "enum": ["COUNT_NOT_NULL", "COUNT_UNIQUE", "MIN", "MAX", "AVG", "SUM", "PERCENTILE"],
                "title": "the name schema",
                "examples": ["COUNT_NOT_NULL"],
                "pattern": "^(.*)$",
            },
        },
        "aggregates_with_filters": {
            "$id": "#/properties/aggregates_with_filters",
            "type": "array",
            "title": "The Aggregates_with_filters Schema",
            "items": {
                "$id": "#/properties/aggregates_with_filters/items",
                "type": "object",
                "title": "The Items Schema",
                "required": ["name", "row_filter_criteria", "aggregate"],
                "properties": {
                    "name": {
                        "$id": "#/properties/aggregates_with_filters/items/properties/name",
                        "type": "string",
                        "title": "The Name Schema",
                        "examples": ["CurrentPROV_AFFIL.LOCALPROVIDERID"],
                    },
                    "row_filter_criteria": {
                        "$id": "#/properties/aggregates_with_filters/items/properties/row_filter_criteria",
                        "type": "string",
                        "title": "The Row_filter_criteria Schema",
                        "examples": ["'END_DATE >= {DATA_AS_OF_DATE}'"],
                    },
                    "aggregate": {
                        "$id": "#/properties/aggregates_with_filters/items/properties/aggregate",
                        "type": "string",
                        "enum": ["COUNT_NOT_NULL", "COUNT_UNIQUE", "MIN", "MAX", "AVG", "SUM", "PERCENTILE"],
                        "title": "The Aggregate Schema",
                        "examples": ["COUNT_UNIQUE"],
                    },
                },
            },
        },
        "aggregates_by_lookup": {
            "$id": "#/properties/aggregates_by_lookup",
            "type": "array",
            "title": "The Aggregates_by_lookup Schema",
            "items": {
                "$id": "#/properties/aggregates_by_lookup/items",
                "type": "object",
                "title": "The Items Schema",
                "required": ["name", "aggregate", "lookup_model_name", "additional_join_criteria"],
                "properties": {
                    "name": {
                        "$id": "#/properties/aggregates_by_lookup/items/properties/name",
                        "type": "string",
                        "title": "The Name Schema",
                        "examples": ["PROV_AFFIL.LOCALPROVIDERIDlinkagetoZH_PROVIDER"],
                    },
                    "aggregate": {
                        "$id": "#/properties/aggregates_by_lookup/items/properties/aggregate",
                        "type": "string",
                        "enum": ["COUNT_NOT_NULL", "COUNT_UNIQUE", "MIN", "MAX", "AVG", "SUM", "PERCENTILE"],
                        "title": "The Aggregate Schema",
                        "examples": ["COUNT_NOT_NULL"],
                    },
                    "lookup_model_name": {
                        "$id": "#/properties/aggregates_by_lookup/items/properties/lookup_model_name",
                        "type": "string",
                        "title": "The Lookup_model_name Schema",
                        "examples": ["ZH_PROVIDER"],
                    },
                    "lookup_column_name": {
                        "$id": "#/properties/aggregates_by_lookup/items/properties/lookup_column_name",
                        "type": "string",
                        "title": "The Lookup_column_name Schema",
                        "examples": ["LOCALPROVIDERID"],
                    },
                    "additional_join_criteria": {
                        "$id": "#/properties/aggregates_by_lookup/items/properties/additional_join_criteria",
                        "type": "string",
                        "title": "The Additional_join_criteria Schema",
                        "examples": [
                            "PROV_AFFIL.GROUPID = ZH_PROVIDER.GROUPID AND PROV_AFFIL.CLIENT_DS_ID = ZH_PROVIDER.CLIENT_DS_ID"
                        ],
                    },
                    "filter": {
                        "$id": "#/properties/aggregates_by_lookup/items/properties/filter",
                        "type": "string",
                        "title": "The filter Schema",
                        "examples": ["Allergy.sourceID = 7234"],
                    },
                },
            },
        },
        "timeseries_distribution": {
            "$id": "#/properties/timeseries_distribution",
            "type": "array",
            "title": "The Timeseries_distribution Schema",
            "items": {
                "$id": "#/properties/timeseries_distribution/items",
                "type": "object",
                "title": "The Items Schema",
                "required": ["on", "name", "filter", "aggregate", "intervals", "onsegment"],
                "properties": {
                    "on": {
                        "$id": "#/properties/timeseries_distribution/items/properties/on",
                        "type": "string",
                        "title": "The On Schema",
                        "examples": ["EFF_DATE"],
                    },
                    "endcolumn": {
                        "$id": "#/properties/timeseries_distribution/items/properties/endcolumn",
                        "type": "string",
                        "title": "The Endcolumn Schema",
                        "examples": ["END_DATE"],
                    },
                    "name": {
                        "$id": "#/properties/timeseries_distribution/items/properties/name",
                        "type": "string",
                        "title": "The Name Schema",
                        "examples": ["INT_TIME_SERIES of PROV_AFFIL"],
                    },
                    "filter": {
                        "$id": "#/properties/timeseries_distribution/items/properties/filter",
                        "type": ["string", "null"],
                        "title": "The Filter Schema",
                        "examples": ["PROV_AFFIL_ID IS NOT NULL"],
                    },
                    "aggregate": {
                        "$id": "#/properties/timeseries_distribution/items/properties/aggregate",
                        "type": "string",
                        "enum": ["COUNT_NOT_NULL", "COUNT_UNIQUE", "MIN", "MAX", "AVG", "SUM", "PERCENTILE"],
                        "title": "The Aggregate Schema",
                        "examples": ["COUNT_NOT_NULL"],
                    },
                    "intervals": {
                        "$id": "#/properties/timeseries_distribution/items/properties/intervals",
                        "type": "array",
                        "title": "The Intervals Schema",
                        "items": {
                            "$id": "#/properties/timeseries_distribution/items/properties/intervals/items",
                            "type": "string",
                            "enum": ["day", "month", "year"],
                            "title": "The Items Schema",
                            "examples": ["month", "year"],
                        },
                    },
                    "onsegment": {
                        "$id": "#/properties/timeseries_distribution/items/properties/onsegment",
                        "type": ["string", "null"],
                        "title": "The Onsegment Schema",
                    },
                },
            },
        },
        "class_distribution": {
            "$id": "#/properties/class_distribution",
            "type": "array",
            "title": "The Class_distribution Schema",
            "items": {
                "$id": "#/properties/class_distribution/items",
                "type": "object",
                "title": "The Items Schema",
                "required": ["on", "name", "filter", "aggregate"],
                "properties": {
                    "on": {
                        "$id": "#/properties/class_distribution/items/properties/on",
                        "type": "array",
                        "title": "The On Schema",
                        "items": {
                            "$id": "#/properties/class_distribution/items/properties/on/items",
                            "type": "string",
                            "title": "The Items Schema",
                            "examples": ["PROV_AFFIL_ID"],
                        },
                    },
                    "name": {
                        "$id": "#/properties/class_distribution/items/properties/name",
                        "type": "string",
                        "title": "The Name Schema",
                        "examples": ["CLASSDISTofPROV_AFFIL.PROV_AFFIL_ID"],
                    },
                    "filter": {
                        "$id": "#/properties/class_distribution/items/properties/filter",
                        "type": ["string", "null"],
                        "title": "The Filter Schema",
                        "examples": ["'END_DATE >= {DATA_AS_OF_DATE}'"],
                    },
                    "aggregate": {
                        "$id": "#/properties/class_distribution/items/properties/aggregate",
                        "type": "string",
                        "enum": ["COUNT_NOT_NULL", "COUNT_UNIQUE", "MIN", "MAX", "AVG", "SUM", "PERCENTILE"],
                        "title": "The Aggregate Schema",
                        "examples": ["COUNT_NOT_NULL"],
                    },
                },
            },
        },
    },
}

metric_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "array",
    "items": [
        {
            "type": "object",
            "properties": {
                "rate": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "numerator": {
                            "type": "object",
                            "properties": {
                                "rule": {"type": "string"},
                                "column": {
                                    "type": ["string", "null"],
                                },
                                "entity": {"type": "string"},
                                "source": {"type": "string"},
                                "rule_name": {
                                    "type": ["string", "null"],
                                },
                                "aggregates": {"type": "string"},
                                "entity_type": {"type": "string"},
                            },
                            "required": [
                                "rule",
                                "column",
                                "entity",
                                "source",
                                "rule_name",
                                "aggregates",
                                "entity_type",
                            ],
                        },
                        "denominator": {
                            "type": "object",
                            "properties": {
                                "rule": {"type": "string"},
                                "column": {
                                    "type": ["string", "null"],
                                },
                                "entity": {"type": "string"},
                                "source": {"type": "string"},
                                "rule_name": {
                                    "type": ["string", "null"],
                                },
                                "aggregates": {"type": "string"},
                                "entity_type": {"type": "string"},
                            },
                            "required": [
                                "rule",
                                "column",
                                "entity",
                                "source",
                                "rule_name",
                                "aggregates",
                                "entity_type",
                            ],
                        },
                    },
                    "required": ["name", "numerator", "denominator"],
                }
            },
        },
        {
            "type": "object",
            "properties": {
                "classdist": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "numerator": {
                            "type": "object",
                            "properties": {
                                "rule": {"type": "string"},
                                "column": {
                                    "type": ["string", "null"],
                                },
                                "entity": {"type": "string"},
                                "source": {"type": "string"},
                                "rule_name": {
                                    "type": ["string", "null"],
                                },
                                "aggregates": {"type": "string"},
                                "entity_type": {"type": "string"},
                            },
                            "required": [
                                "rule",
                                "column",
                                "entity",
                                "source",
                                "rule_name",
                                "aggregates",
                                "entity_type",
                            ],
                        },
                        "denominator": {
                            "type": "object",
                            "properties": {
                                "rule": {"type": "string"},
                                "column": {
                                    "type": ["string", "null"],
                                },
                                "entity": {"type": "string"},
                                "source": {"type": "string"},
                                "rule_name": {
                                    "type": ["string", "null"],
                                },
                                "aggregates": {"type": "string"},
                                "entity_type": {"type": "string"},
                            },
                            "required": [
                                "rule",
                                "column",
                                "entity",
                                "source",
                                "rule_name",
                                "aggregates",
                                "entity_type",
                            ],
                        },
                    },
                    "required": ["name", "numerator", "denominator"],
                }
            },
        },
        {
            "type": "object",
            "properties": {
                "rateofchange": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "rule": {"type": "string"},
                        "column": {
                            "type": ["string", "null"],
                        },
                        "entity": {"type": "string"},
                        "source": {"type": "string"},
                        "rule_name": {"type": "string"},
                        "aggregates": {"type": "string"},
                        "entity_type": {"type": "string"},
                    },
                    "required": [
                        "name",
                        "rule",
                        "column",
                        "entity",
                        "source",
                        "rule_name",
                        "aggregates",
                        "entity_type",
                    ],
                }
            },
        },
    ],
}


eval_schema = {
    "definitions": {},
    "$schema": "",
    "$id": "http://example.com/root.json",
    "type": "array",
    "title": "The Root Schema",
    "items": {
        "$id": "#/items",
        "type": "object",
        "title": "The Items Schema",
        "required": ["args", "name", "evaluation", "decision_logic", "technique_args"],
        "properties": {
            "args": {
                "$id": "#/items/properties/args",
                "type": "array",
                "title": "The Args Schema",
                "items": {
                    "$id": "#/items/properties/args/items",
                    "type": "object",
                    "title": "The Items Schema",
                    "required": ["limit", "model", "column", "method", "source", "values", "rule_name", "entity_type"],
                    "properties": {
                        "limit": {
                            "$id": "#/items/properties/args/items/properties/limit",
                            "type": ["integer", "null"],
                            "title": "The Limit Schema",
                            "examples": [5],
                        },
                        "model": {
                            "$id": "#/items/properties/args/items/properties/model",
                            "type": "string",
                            "title": "The Model Schema",
                            "examples": ["ENCOUNTER_GRP"],
                        },
                        "column": {
                            "$id": "#/items/properties/args/items/properties/column",
                            "type": ["string", "null"],
                            "title": "The Column Schema",
                            "examples": [None],
                        },
                        "method": {
                            "$id": "#/items/properties/args/items/properties/method",
                            "type": ["string", "null"],
                            "title": "The Method Schema",
                            "examples": [None],
                        },
                        "source": {
                            "$id": "#/items/properties/args/items/properties/source",
                            "type": "string",
                            "title": "The Source Schema",
                            "examples": ["metric"],
                        },
                        "values": {
                            "$id": "#/items/properties/args/items/properties/values",
                            "type": "string",
                            "title": "The Values Schema",
                            "examples": ["classdist"],
                        },
                        "rule_name": {
                            "$id": "#/items/properties/args/items/properties/rule_name",
                            "type": "string",
                            "title": "The Rule_name Schema",
                            "examples": ["LARGEDISTofEDDischargesbyProcedureDescription"],
                        },
                        "entity_type": {
                            "$id": "#/items/properties/args/items/properties/entity_type",
                            "type": "string",
                            "title": "The Entity_type Schema",
                            "examples": ["TABLE"],
                        },
                    },
                },
            },
            "name": {
                "$id": "#/items/properties/name",
                "type": "string",
                "title": "the name schema",
                "examples": ["LARGEDISTofEDDischargesbyProcedureDescription"],
            },
            "evaluation": {
                "$id": "#/items/properties/evaluation",
                "type": "string",
                "enum": ["rateanalysis", "classdistanalysis", "timeseriesanalysis", "numdistanalysis"],
                "title": "The Evaluation Schema",
                "examples": ["classdistanalysis"],
            },
            "decision_logic": {
                "$id": "#/items/properties/decision_logic",
                "type": "string",
                "title": "The Decision_logic Schema",
                "default": "",
                "examples": ["ASSERT_STABLE"],
            },
            "technique_args": {
                "$id": "#/items/properties/technique_args",
                "type": "array",
                "title": "The Technique_args Schema",
                "items": {
                    "$id": "#/items/properties/technique_args/items",
                    "type": "object",
                    "title": "The Items Schema",
                    "properties": {
                        "values": {
                            "$id": "#/items/properties/technique_args/items/properties/values",
                            "type": "object",
                            "title": "The Values Schema",
                            "properties": {
                                "max": {
                                    "$id": "#/items/properties/technique_args/items/properties/values/properties/max",
                                    "type": "number",
                                    "title": "The Max Schema",
                                    "examples": [0.99],
                                },
                                "min": {
                                    "$id": "#/items/properties/technique_args/items/properties/values/properties/min",
                                    "type": "number",
                                    "title": "The Min Schema",
                                    "examples": [0.01],
                                },
                            },
                        },
                        "technique": {
                            "$id": "#/items/properties/technique_args/items/properties/technique",
                            "type": "string",
                            "title": "The Technique Schema",
                            "default": "",
                            "examples": ["beta_bayesian"],
                        },
                    },
                },
            },
        },
    },
}
