import hashlib
from collections import namedtuple


class Rule:
    rule_row = namedtuple(
        "rule_row", "model_name, column_name, rule_name, entity_type, rule_type, partition_cols, guid"
    )

    def get_guid(self, str_to_hash):
        return hashlib.sha1(str_to_hash.encode()).hexdigest()
