from dvp_rule_type import DVPEvalType
from eval_rule_factory.classdist_analysis import ClassDistAnalysis  # noqa: F401
from eval_rule_factory.largedist_analysis import LargeDistAnalysis  # noqa: F401
from eval_rule_factory.mad_qreg_timeseries_analysis import (  # noqa: F401
    MadQregTimeseriesAnalysis,
)
from eval_rule_factory.numdist_analysis import NumdistAnalysis  # noqa: F401
from eval_rule_factory.rate_analysis import RateAnalysis  # noqa: F401
from eval_rule_factory.timeseries_analysis import TimeseriesAnalysis  # noqa: F401


class EvalRuleFactory:
    # A Template Method: i expect a comment here
    @staticmethod
    def get_eval_rule_creator(eval_type):
        if eval_type == DVPEvalType.numdist_analysis:
            return eval("NumdistAnalysis.Factory()").create()
        elif eval_type == DVPEvalType.classdist_analysis:
            return eval("ClassDistAnalysis.Factory()").create()
        elif eval_type == DVPEvalType.timeseries_analysis:
            return eval("TimeseriesAnalysis.Factory()").create()
        elif eval_type == DVPEvalType.mad_qreg_timeseries_analysis:
            return eval("MadQregTimeseriesAnalysis.Factory()").create()
        elif eval_type == DVPEvalType.largedist_analysis:
            return eval("LargeDistAnalysis.Factory()").create()
        else:
            return eval("RateAnalysis.Factory()").create()
