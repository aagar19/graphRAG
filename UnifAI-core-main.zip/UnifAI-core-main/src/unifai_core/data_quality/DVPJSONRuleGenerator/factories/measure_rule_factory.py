from dvp_rule_type import DVPMeasureType
from measure_rule_factory.aggregate import Aggregate  # noqa: F401
from measure_rule_factory.aggregate_by_lookup import AggregateByLookup  # noqa: F401
from measure_rule_factory.aggregate_with_filters import (  # noqa: F401
    AggregateWithFilters,
)
from measure_rule_factory.class_distribution import ClassDistribution  # noqa: F401
from measure_rule_factory.timeseries_distribution import (  # noqa: F401
    TimeseriesDistribution,
)


class MeasureRuleFactory:
    factories = {}

    @staticmethod
    def add_factory(id, comparatorFactory):
        MeasureRuleFactory.factories.put[id] = compaoratorFactory  # noqa: F821

    @staticmethod
    def get_measure_rule_creator(measure_type):
        if measure_type == DVPMeasureType.timeseries_distribution:
            MeasureRuleFactory.factories[measure_type] = eval("TimeseriesDistribution" + ".Factory()")

        elif measure_type == DVPMeasureType.class_distribution:
            MeasureRuleFactory.factories[measure_type] = eval("ClassDistribution" + ".Factory()")

        elif measure_type == DVPMeasureType.aggregates_by_lookup:
            MeasureRuleFactory.factories[measure_type] = eval("AggregateByLookup" + ".Factory()")

        elif measure_type == DVPMeasureType.aggregates_with_filters:
            MeasureRuleFactory.factories[measure_type] = eval("AggregateWithFilters" + ".Factory()")

        else:
            MeasureRuleFactory.factories[measure_type] = eval("Aggregate" + ".Factory()")

        return MeasureRuleFactory.factories[measure_type].create()
