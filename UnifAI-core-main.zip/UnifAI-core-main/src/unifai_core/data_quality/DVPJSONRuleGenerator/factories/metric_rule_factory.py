from dvp_rule_type import DVPMetricType
from metric_rule_factory.class_distribution import ClassDistribution  # noqa: F401
from metric_rule_factory.rate import Rate  # noqa: F401
from metric_rule_factory.rate_of_change import RateOfChange  # noqa: F401


class MetricRuleFactory:
    factories = {}

    @staticmethod
    def add_factory(id, comparatorFactory):
        MetricRuleFactory.factories.put[id] = comparatorFactory

    # A Template Method: i expect a comment here
    @staticmethod
    def get_metric_rule_creator(metric_type):
        if metric_type == DVPMetricType.rateofchange:
            return eval("RateOfChange.Factory()").create()
        elif metric_type == DVPMetricType.classdist:
            return eval("ClassDistribution.Factory()").create()
        else:
            return eval("Rate.Factory()").create()
