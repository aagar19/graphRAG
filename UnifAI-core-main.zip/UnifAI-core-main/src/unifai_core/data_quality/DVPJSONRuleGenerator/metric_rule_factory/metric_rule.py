from rule import Rule


class MetricRule(Rule):
    def __init__(self):
        pass
