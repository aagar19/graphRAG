from collections import namedtuple

from metric_rule_factory.metric_rule import MetricRule


class Rate(MetricRule):
    rule_def = namedtuple("rule_def", "numerator, denominator")

    def get_metric_rule(self, rule_name, args):
        model_name, column_name, entity_type, numerator, denominator, guid = self.get_numerator_denominator(
            rule_name, args
        )
        rule_row_record = self.rule_row(model_name, column_name, rule_name, entity_type, "rate", None, guid)
        rule_definition = self.rule_def(numerator, denominator)

        return rule_row_record, rule_definition

    def get_numerator_denominator(self, rule_name, args):
        num_measure_type, num_rule_row, num_rule_def = args[0]
        denom_measure_type, denom_rule_row, denom_rule_def = args[1]
        numerator = {}
        denominator = {}

        guid = self.get_guid(rule_name)

        numerator["rule"] = num_rule_row.rule_type
        numerator["column"] = num_rule_row.column_name
        numerator["entity"] = num_rule_row.model_name
        numerator["source"] = "measure"
        numerator["rule_name"] = num_rule_row.rule_name
        numerator["aggregates"] = num_rule_def.aggregate
        numerator["entity_type"] = num_rule_row.entity_type

        denominator["rule"] = denom_rule_row.rule_type
        denominator["column"] = denom_rule_row.column_name
        denominator["entity"] = denom_rule_row.model_name
        denominator["source"] = "measure"
        denominator["rule_name"] = denom_rule_row.rule_name
        denominator["aggregates"] = denom_rule_def.aggregate
        denominator["entity_type"] = denom_rule_row.entity_type

        return num_rule_row.model_name, num_rule_row.column_name, num_rule_row.entity_type, numerator, denominator, guid

    class Factory:
        def create(self):
            return Rate()
