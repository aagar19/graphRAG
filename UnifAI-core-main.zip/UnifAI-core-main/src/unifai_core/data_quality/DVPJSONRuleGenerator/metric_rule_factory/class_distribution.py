from collections import namedtuple  # noqa: F401

from metric_rule_factory.rate import Rate


class ClassDistribution(Rate):
    def get_metric_rule(self, rule_name, args):
        model_name, column_name, entity_type, numerator, denominator, guid = self.get_numerator_denominator(
            rule_name, args
        )
        rule_row_record = self.rule_row(model_name, column_name, rule_name, entity_type, "classdist", None, guid)
        rule_definition = self.rule_def(numerator, denominator)

        return rule_row_record, rule_definition

    class Factory:
        def create(self):
            return ClassDistribution()
