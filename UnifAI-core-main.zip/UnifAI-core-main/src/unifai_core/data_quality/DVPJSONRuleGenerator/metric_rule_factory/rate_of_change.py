from collections import namedtuple

from metric_rule_factory.metric_rule import MetricRule


class RateOfChange(MetricRule):
    rule_def = namedtuple("rule_def", "rule, column, entity, source, rule_name, aggregates, intervals,entity_type")

    def get_metric_rule(self, rule_name, args):
        measure_type, measure_rule_row, measure_rule_def = args[0]
        guid = self.get_guid(rule_name)

        rule_row_record = self.rule_row(
            measure_rule_row.model_name,
            measure_rule_row.column_name,
            rule_name,
            measure_rule_row.entity_type,
            "rateofchange",
            None,
            guid,
        )
        rule_definition = self.rule_def(
            measure_rule_row.rule_type,
            measure_rule_row.column_name,
            measure_rule_row.model_name,
            "measure",
            measure_rule_row.rule_name,
            measure_rule_def.aggregate,
            measure_rule_def.intervals,
            measure_rule_row.entity_type,
        )
        return rule_row_record, rule_definition

    class Factory:
        def create(self):
            return RateOfChange()
