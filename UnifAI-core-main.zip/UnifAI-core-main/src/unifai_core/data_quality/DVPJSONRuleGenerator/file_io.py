import glob
import os
from pathlib import Path


class FileIO:
    def get_txt_files(self, directory_path):
        return glob.glob(directory_path + "/**/*.txt", recursive=True)

    def get_expr_files(self, directory_path):
        return glob.glob(directory_path + "/**/*.expr", recursive=True)

    def get_partition_files(self, directory_path):
        return glob.glob(directory_path + "/**/partition_column.expr", recursive=True)

    def get_override_params(self, directory_path):
        return glob.glob(directory_path + "/**/*.json", recursive=True)

    def get_rules(self, directory_path):
        return glob.glob(directory_path + "/*.rules", recursive=False)

    def get_file_content(self, file_path):
        with open(file_path) as f:
            content = f.readlines()
        content = [x.strip() for x in content if x.strip()]
        return content

    def write_file(self, file_content, file_path):
        folder_path = Path(file_path).parent
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        with open(file_path, "w") as f:
            f.write(file_content)

    def get_parent_dir_path(self, path):
        return Path(path).parent

    def is_exists(self, file):
        return os.path.exists(file)
