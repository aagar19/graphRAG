from collections import namedtuple


class DVPRuleDefinition:
    measure_timeseries = namedtuple(
        "timeseries_distribution", "name, aggregate, on, interval, filter, onsegment, endcolumn"
    )
    measure_agg_by_lookup = namedtuple(
        "aggregate_by_lookup", "name, aggregate, lookup_model_name, lookup_column_name, additional_join_criteria"
    )
    lookup_clause = namedtuple("lookup_clause", "entity, additional_join_criteria")
    timeseries_clause = namedtuple("timeseries_clause", "timeseries_interval, start_entity, end_entity")
    measure_classdist = namedtuple("class_distribution", "on, aggregate, filter, name")
    measure_agg_with_filter = namedtuple("aggregate_with_filter", "name, aggregate, row_filter_criteria")
    measure_agg = namedtuple("measure_agg", "name, aggregate")

    arg = namedtuple("result_reference", "source, model, column, entity_type, rule, aggregates, rule_name, limit")

    metric_rate = namedtuple("rate", "numerator, denominator, name")
    metric_classdist = namedtuple("classdist", "numerator, denominator, name")
    metric_rateofchange = namedtuple(
        "rateofchange", "name, entity_type, column, rule, source, rule_name, aggregates, entity"
    )

    eval = namedtuple("eval_rate", "evaluation, decision_logic, args, name, technique_args")

    entity = namedtuple("entity", "model_name, column_name, entity_type")

    obj_wrapper = namedtuple("object", "obj_type, obj")

    measure_properties = namedtuple(
        "measure_prop", "aggregate, entity, where_clause, segment_clause, timeseries_clause, lookup_clause"
    )

    rule_properties = namedtuple("rule_prop", "entity, rule_def, rule_type, dvp_module")

    def get_rule_prop(self, entity, rule_def, rule_type, dvp_module):
        return self.rule_properties(entity, rule_def, rule_type, dvp_module)

    def get_measure_prop(self, aggregate, entity, where_clause, segment_clause, timeseries_clause, lookup_clause):
        return self.measure_properties(
            aggregate, entity, where_clause, segment_clause, timeseries_clause, lookup_clause
        )

    def get_measure_timeseries(self, name, aggregate, on, interval, filter_criteria, onsegment, endcolumn):
        out_name = agrregate + on + filter_criteria + onsegment + endcolumn + interval  # noqa: F821
        return self.measure_timeseries(out_name, aggregate, on, interval, filter_criteria, onsegment, endcolumn)

    def get_measure_agg_by_lookup(
        self, name, aggregate, lookup_model_name, lookup_column_name, additional_join_criteria
    ):
        out_name = aggregate + lookup_model_name + lookup_column_name
        return self.measure_agg_by_lookup(
            out_name, aggregate, lookup_model_name, lookup_column_name, additional_join_criteria
        )

    def get_measure_classdist(self, on, aggregate, filter, name):
        out_name = on + aggregate + filter
        return self.measure_classdist(on, aggregate, filter, out_name)

    def get_measure_agg_with_filter(self, name, aggreage, row_filter_criteria):
        out_name = aggregate + row_filter_criteria  # noqa: F821
        return self.measure_agg_with_filter(out_name, aggreage, row_filter_criteria)

    def get_measure_agg(self, aggregate):
        out_name = aggregate
        return self.measure_agg(out_name, aggregate)

    def get_reference(self, source, model, column, entity_type, rule, aggregates, rule_name):
        return self.arg(source, model, column, entity_type, rule, aggregates, rule_name, None)

    def get_metric_rate(self, numerator, denominator, name):
        return self.metric_rate(numerator, denominator, name)

    def get_metric_classdist(self, numerator, denominator, name):
        return self.metric_classdist(numerator, denominator, name)

    def get_metric_rateofchange(self, name, entity_type, column, rule, source, rule_name, aggregates, entity):
        return self.metric_rateofchange(name, entity_type, column, rule, source, rule_name, aggregates, entity)

    def get_eval(self, evaluation, decision_logic, args, name, technique_args):
        return self.eval(evaluation, decision_logic, args, name, technique_args)

    def update_name(self, tup, name_value):
        tup.name = name_value
        return tup

    def get_entity(self, model_name, column_name, entity_type):
        return self.entity(model_name, column_name, entity_type)

    def wrap_object(self, obj_type, tup):
        return self.obj_wrapper(obj_type, tup)

    def get_lookup_clause(self, entity, additional_join_criteria):
        return self.lookup_clause(entity, additional_join_criteria)

    def get_timeseries_clause(self, ts_interval, start_entity, end_entity):
        return self.timeseries_clause(ts_interval, start_entity, end_entity)
