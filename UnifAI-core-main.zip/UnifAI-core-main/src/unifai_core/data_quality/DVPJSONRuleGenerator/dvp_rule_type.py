from enum import Enum


class DVPRuleType(Enum):
    fraction = 1
    class_distribution = 2
    timeseries_distribution = 3
    largedist = 4
    numdist = 5


class DVPEvalType(Enum):
    rate_analysis = 1
    classdist_analysis = 2
    timeseries_analysis = 3
    numdist_analysis = 4
    largedist_analysis = 5
    mad_qreg_timeseries_analysis = 6


class DVPMeasureType(Enum):
    aggregates = 1
    aggregates_with_filters = 2
    class_distribution = 3
    aggregates_by_lookup = 4
    timeseries_distribution = 5


class DVPMetricType(Enum):
    rate = 1
    classdist = 2
    rateofchange = 3


class DVPTypes(Enum):
    agg = 1
    agg_with_filter = 2
    class_distribution = 3
    agg_by_lookup = 4
    timeseries_distribution = 5
    rate = 6
    numdist = 7
    largedist = 8
    rateofchange = 9
    condition = 10
    entity = 11
