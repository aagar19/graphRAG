class UtilityMethods:
    def updateTemplate(self, template, data):
        for ref in data:
            keys = ref.split(".")
            temp = template
            for key_part in keys[:-1]:
                temp = temp[key_part]
            temp[keys[-1]] = data[ref]  # Because dictionaries are mutable, this updates template too
        return template
