from dvp_rule_definition import DVPRuleDefinition
from dvp_rule_type import *  # noqa: F403
from factories.eval_rule_factory import EvalRuleFactory
from factories.measure_rule_factory import MeasureRuleFactory
from factories.metric_rule_factory import MetricRuleFactory
from lark import Lark
from lark import Transformer


class Grammar:
    def get(self):
        return Lark(
            r"""
                start: rule_name ":" expression

                rule_name: /[^:]+/

                expression: "assert" metric_trend "to be" expected_trend "on" metric | "compute rate_of_change on" measure

                metric_trend: /fraction|class_distribution|timeseries_distribution|largedist|numdist|mad_qreg/

                metric: measure ("over" measure)*
                expected_trend: /not_high|not_low|stable/
                measure: aggregate "of" entity (where_clause)* (segment_clause)* (timeseries_clause)* (lookup_clause)*
                join_conditions: "{" string_in_bracket "}"
                aggregate: /count_not_null|count_unique|min|max|avg|sum|percentile|COUNT_NOT_NULL|COUNT_UNIQUE|MIN|MAX|AVG|SUM|PERCENTILE/
                entity: table ("." column)*
                lookup_clause: "lookup" entity "on" join_conditions
                where_clause: "where" condition
                segment_clause: "segment by" "{" string_in_bracket "}"
                timeseries_interval: /daily|monthly|yearly|weekly|quarterly/
                timeseries_clause: timeseries_interval "timeseries by" entity ("with endcolumn" entity)*
                condition: "{" string_in_bracket "}"
                table: CNAME
                column: /[^\s]+/
                string_in_bracket: /[^}]+/
                %import common.WORD
                %import common.CNAME
                %ignore " "
                """
        )

    def parse_line(self, single_line_rule):
        grammar = self.get()
        return grammar.parse(single_line_rule)


class DVPRuleTransformer(Transformer):
    def __init__(self):
        self.metric_trend_to_metric_type = {
            "fraction": DVPMetricType.rate,  # noqa: F405
            "class_distribution": DVPMetricType.classdist,  # noqa: F405
            "timeseries_distribution": DVPMetricType.rateofchange,  # noqa: F405
            "mad_qreg": DVPMetricType.rateofchange,  # noqa: F405
            "largedist": DVPMetricType.classdist,  # noqa: F405
            "numdist": None,
        }
        self.metric_trend_to_eval_type = {
            "fraction": DVPEvalType.rate_analysis,  # noqa: F405
            "class_distribution": DVPEvalType.classdist_analysis,  # noqa: F405
            "timeseries_distribution": DVPEvalType.timeseries_analysis,  # noqa: F405
            "mad_qreg": DVPEvalType.mad_qreg_timeseries_analysis,  # noqa: F405
            "largedist": DVPEvalType.largedist_analysis,  # noqa: F405
            "numdist": DVPEvalType.numdist_analysis,  # noqa: F405
        }
        self.decision_logic_dic = {
            "stable": "ASSERT_STABLE",
            "not_low": "ASSERT_NOT_LOW",
            "not_high": "ASSERT_NOT_HIGH",
        }

    def start(self, args):
        rule_name = args[0]
        measures, metric_type, eval_type, decision_logic = args[1]
        rule_dict = {"measure": [], "metric": [], "eval": []}

        for measure in measures:
            m_type, m_row, m_def = measure
            m_row_dict = m_row._asdict()
            m_row_dict["rule_def"] = m_def._asdict()
            rule_dict["measure"].append(m_row_dict)

        if metric_type:
            metric_rule_creator = MetricRuleFactory().get_metric_rule_creator(metric_type)
            metric_rule_row, metric_rule_definition = metric_rule_creator.get_metric_rule(rule_name, measures)
            metric_row_dict = metric_rule_row._asdict()
            metric_row_dict["rule_def"] = metric_rule_definition._asdict()
            rule_dict["metric"].append(metric_row_dict)

            eval_rule_creator = EvalRuleFactory().get_eval_rule_creator(eval_type)
            eval_row, eval_def = eval_rule_creator.get_eval_rule(
                rule_name, decision_logic, [metric_rule_row, metric_rule_definition]
            )
            eval_row_dict = eval_row._asdict()
            eval_row_dict["rule_def"] = eval_def._asdict()
            rule_dict["eval"].append(eval_row_dict)

        elif eval_type:
            eval_rule_creator = EvalRuleFactory().get_eval_rule_creator(eval_type)
            eval_row, eval_def = eval_rule_creator.get_eval_rule(rule_name, decision_logic, measures)
            eval_row_dict = eval_row._asdict()
            eval_row_dict["rule_def"] = eval_def._asdict()
            rule_dict["eval"].append(eval_row_dict)

        return rule_dict

    def rule_name(self, args):
        return str(args[0])

    def expression(self, args):
        if len(args) > 1:
            rule_type = args[0]
            decision_logic = self.decision_logic_dic[args[1]]
            measures = args[2].children
            metric_type = self.metric_trend_to_metric_type[rule_type]
            eval_type = self.metric_trend_to_eval_type[rule_type]
            return measures, metric_type, eval_type, decision_logic
        else:
            return [args[0]], None, None, None

    def measure(self, args):
        clauses_array, objs = zip(*args)
        measure_type = self.find_measure_type(clauses_array)

        measure_rule_creator = MeasureRuleFactory().get_measure_rule_creator(measure_type)

        rule_row, rule_definition = measure_rule_creator.get_measure_rule(args)
        return measure_type, rule_row, rule_definition

    def entity(self, args):
        """return model_name, column_name, entity_type"""
        model, column, e_type = (
            (str(args[0]), str(args[1]), "COLUMN") if len(args) == 2 else (str(args[0]), None, "TABLE")
        )
        return None, DVPRuleDefinition().get_entity(model, column, e_type)

    def aggregate(self, args):
        return DVPMeasureType.aggregates, DVPRuleDefinition().get_measure_agg(str(args[0]))  # noqa: F405

    def lookup_clause(self, args):
        return DVPMeasureType.aggregates_by_lookup, DVPRuleDefinition().get_lookup_clause(
            args[0][1], args[1]
        )  # noqa: F405

    def where_clause(self, args):
        return DVPMeasureType.aggregates_with_filters, args[0]  # noqa: F405

    def segment_clause(self, args):
        return DVPMeasureType.class_distribution, str(args[0].children[0])  # noqa: F405

    def timeseries_clause(self, args):
        ts_interval = str(args[0])
        endcolumn_entity = args[2][1] if len(args) == 3 else None
        return DVPMeasureType.timeseries_distribution, DVPRuleDefinition().get_timeseries_clause(  # noqa: F405
            ts_interval, args[1][1], endcolumn_entity
        )

    def timeseries_interval(self, args):
        return str(args[0])

    def table(self, args):
        return str(args[0])

    def metric_trend(self, args):
        return str(args[0])

    def column(self, args):
        return str(args[0])

    def expected_trend(self, args):
        return str(args[0])

    def join_conditions(self, args):
        return str(args[0].children[0])

    def condition(self, args):
        return str(args[0].children[0])

    def find_measure_type(self, clauses_array):
        if DVPMeasureType.timeseries_distribution in clauses_array:  # noqa: F405
            return DVPMeasureType.timeseries_distribution  # noqa: F405
        elif DVPMeasureType.aggregates_by_lookup in clauses_array:  # noqa: F405
            return DVPMeasureType.aggregates_by_lookup  # noqa: F405
        elif DVPMeasureType.class_distribution in clauses_array:  # noqa: F405
            return DVPMeasureType.class_distribution  # noqa: F405
        elif DVPMeasureType.aggregates_with_filters in clauses_array:  # noqa: F405
            return DVPMeasureType.aggregates_with_filters  # noqa: F405
        else:
            return DVPMeasureType.aggregates  # noqa: F405
