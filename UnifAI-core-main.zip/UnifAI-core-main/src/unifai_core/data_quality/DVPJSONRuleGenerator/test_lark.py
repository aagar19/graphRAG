from lark import Lark


grammar = r"""
    start: rule_name ":" expression

                rule_name: /[^:]+/

                expression: "assert" metric_trend "to be" expected_trend "on" metric | "compute rate_of_change on" measure

                metric_trend: /fraction|class_distribution|timeseries_distribution|largedist|numdist/

                metric: measure ("over" another_measure)*
                expected_trend: /not_high|not_low|stable/
                measure: aggregate "of" entity (where_clause)* (segment_clause)* (timeseries_clause)* (lookup_clause)*
                another_measure: measure
                another_entity: entity
                join_conditions: "{" string_in_bracket "}"
                aggregate: /count_not_null|count_unique|min|max|avg|sum|percentile|COUNT_NOT_NULL|COUNT_UNIQUE|MIN|MAX|AVG|SUM|PERCENTILE/
                entity: table ("." column)*
                lookup_clause: "lookup" another_entity "on" join_conditions
                where_clause: "where" condition
                segment_clause: "segment by" "{" string_in_bracket "}"
                timeseries_clause: "timeseries by" entity ("with endcolumn" entity)*
                condition: "{" string_in_bracket "}"
                table: CNAME
                column: /[^\s]+/
                string_in_bracket: /[^}]+/
                %import common.WORD
                %import common.CNAME
                %ignore " "
"""

parser = Lark(grammar)


def test():
    test_str = """Rate_of_grp_mpi_over_labresult: assert fraction to be stable on count_unique of labresult.grp_,+()mpi$ over count_not_null of labresult"""  # noqa: F841

    test_ts_str = "TS_on_labresult_ts_by_date: assert timeseries_distribution to be stable on count_not_null of labresult timeseries by labresult.DATECOLLECTED,,()$"  # noqa: F841

    count_increment = "count_increment_of labresults: compute rate_of_change on count_not_null of labresult"

    j = parser.parse(count_increment)
    print(j.pretty())


if __name__ == "__main__":
    test()
