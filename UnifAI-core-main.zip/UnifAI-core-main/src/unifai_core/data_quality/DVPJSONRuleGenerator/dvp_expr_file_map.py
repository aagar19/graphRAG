class ExprFiles:
    expression_files_per_layer = {
        "measure": ["computed_column.expr", "temp_table.expr", "partition_column.expr", "user_defined_function.expr"],
        "metric": ["partition_column.expr", "user_defined_function.expr"],
        "evaluation": ["partition_column.expr", "user_defined_function.expr"],
        "resultdb_hive": ["partition_column.expr"],
        "create_hive_tables": ["partition_column.expr"],
        "summariser": ["anomaly_config.expr", "summariser_filter.expr"],
        "report_generator": ["core_rules.expr", "partition_column.expr", "report_filter.expr", "rule_description.expr"],
    }
    comparators_per_layer = {"report_generator": ["periodicrefresh", "implementation"]}
