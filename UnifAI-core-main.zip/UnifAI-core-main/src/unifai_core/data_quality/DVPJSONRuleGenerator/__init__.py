import json
import os
import sys
import uuid
from pathlib import Path
from typing import Optional


def rulegenerator(
    rulefolder: str, configfolder: str, userconfigfolder: Optional[str] = None, defaultconfig: Optional[str] = "default"
) -> None:
    run_id = uuid.uuid1()
    parent_folder = Path(rulefolder)
    sys.path.append(os.path.realpath(os.path.dirname(__file__)))
    from dvp_output_adaptor import JSONOutputAdaptor
    from dvp_rule_transformer import DVPRuleTransformer
    from dvp_rule_transformer import Grammar
    from file_io import FileIO

    dirs = [str(f) for f in parent_folder.iterdir() if f.is_dir()]
    error_content = []
    for dir_path in dirs:
        # Rule files
        txt_file_list = FileIO().get_txt_files(dir_path)
        # Computed Column, Temp table files
        expr_file_list = FileIO().get_expr_files(dir_path)
        # Partition Column files
        partition_file = FileIO().get_partition_files(dir_path).pop()

        rules = {"measure": [], "metric": [], "eval": []}

        for f in txt_file_list:
            for line in FileIO().get_file_content(f):
                try:
                    expr_tree = Grammar().parse_line(line)
                    rule_dict = DVPRuleTransformer().transform(expr_tree)
                    for key, values in rule_dict.items():
                        for v in values:
                            rules[key].append(v)
                    # all_rules.append(DVPRuleTransformer().transform(expr_tree))
                except Exception as e:
                    error_content.append(
                        ("Error Processing: " + f + " for rule '" + line + "'. Skipping the rule.", str(e))
                    )

        jsonOutputAdapterobj = JSONOutputAdaptor(run_id, configfolder, userconfigfolder, defaultconfig)
        jsonOutputAdapterobj.save(
            partition_file, rules, expr_file_list, rulefolder, configfolder, str(os.path.basename(dir_path))
        )
    FileIO().write_file(json.dumps(error_content, sort_keys=True, indent=4), "error" + str(run_id) + ".txt")


# python3 DVPJSONRuleGenerator/__init__.py --rulefolder ./Rules --configfolder ./Config
