"""functionalities related to ai-check."""

from datetime import datetime
from typing import List
from typing import Optional
from typing import Tuple

from pyspark.sql import SparkSession

from unifai_core.app.conf import ApplicationConfiguration
from unifai_core.app.utils import clean_path
from unifai_core.app.utils import db_fs_copy
from unifai_core.app.utils import db_run_job
from unifai_core.cli.types import Settings
from unifai_core.data_quality.utils import _get_env_variables
from unifai_core.data_quality.utils import _get_output_path
from unifai_core.data_quality.utils import _insert_data
from unifai_core.data_quality.utils import _setup_job_cluster


ENV_EXCLUDE_LIST: List[str] = []


def run_ai_check(
    settings: Settings,
    app_name: str,
    extra_args: dict,
    orchestration_id: Optional[str] = None,
    orchestration_data: Optional[dict] = None,
) -> None:
    """Function to trigger spark submit job to run ai_check.

    Args:
        settings: contains databricks host id, cluster id and schema name
        app_name: application name
        extra_args: level for ai check run eg. unifai
        orchestration_id: run version(YYYYMM)
        orchestration_data: client name for the ai check run eg. local

    Raises:
        RuntimeError: the process fails at any point
    """
    spark = SparkSession.builder.getOrCreate()
    # Load application configuration
    application = ApplicationConfiguration(app_name=app_name, spark=spark)

    # Prepare configuration
    config_location = clean_path(
        application.get(f"DATA_QUALITY_{extra_args.get('config_type')}_AI_CHECK"), "file:/dbfs"
    )
    rules_location = f"{config_location}/DVP_Rules/output/{extra_args.get('level', 'unifai')}/default"
    start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Prepare ENV variables
    env_variables = _get_env_variables(extra_args, ENV_EXCLUDE_LIST)
    schema = env_variables.get("UNIFAI_SCHEMA")
    if not schema:
        schema = settings["SCHEMA_NAME"]
        env_variables["UNIFAI_SCHEMA"] = schema
    output_path = env_variables.get("OUTPUT_PATH")
    print("output_path", output_path)
    if not output_path:
        output_path = _get_output_path(application.name, schema)
        env_variables["OUTPUT_PATH"] = output_path
    if not env_variables.get("INPUT_DATA_PATH"):
        input_path = f"dbfs:/mnt/azureblobshare/{schema}"
        env_variables["INPUT_DATA_PATH"] = input_path
    if not env_variables.get("DVP_REPORT_PATH"):
        env_variables["DVP_REPORT_PATH"] = f"{clean_path(output_path, '')}/report_final"
    if not env_variables.get("DVP_RESULT_PATH"):
        env_variables["DVP_RESULT_PATH"] = f"{output_path}/result_final"
    if not env_variables.get("LOG_PATH"):
        env_variables["LOG_PATH"] = f"{output_path}/logs"
    if not env_variables.get("SNOOP_RESULT_PATH"):
        env_variables["SNOOP_RESULT_PATH"] = f"{output_path}/snoop"

    # Copy over default DVP measure, metric, etc. parquet files
    db_fs_copy(
        clean_path(f"{application.get('FILE_STORE_PATH')}/code/unifai_core_app/data_quality", "dbfs:"),
        clean_path(env_variables["LOG_PATH"], "dbfs:"),
        True,
        False,
    )

    # DVP Measure Job
    status, job_id, run_id = __dvp_run_measure_metric(
        settings, application, "measure", config_location, rules_location, env_variables, extra_args
    )
    __insert_data(
        settings,
        application,
        "measure",
        status,
        job_id,
        run_id,
        config_location,
        start_time,
        {**extra_args, **env_variables},
        orchestration_id,
        orchestration_data,
    )

    # DVP Metric Job
    status, job_id, run_id = __dvp_run_measure_metric(
        settings, application, "metric", config_location, rules_location, env_variables, extra_args
    )
    __insert_data(
        settings,
        application,
        "metric",
        status,
        job_id,
        run_id,
        config_location,
        start_time,
        {**extra_args, **env_variables},
        orchestration_id,
        orchestration_data,
    )

    # DVP Evaluation Job
    status, job_id, run_id = __dvp_run_evaluation(
        settings, application, config_location, rules_location, env_variables, extra_args
    )
    eval_run_id = __insert_data(
        settings,
        application,
        "evaluation",
        status,
        job_id,
        run_id,
        config_location,
        start_time,
        {**extra_args, **env_variables},
        orchestration_id,
        orchestration_data,
    )

    # DVP Report-Generator Job
    status = __dvp_run_report(settings, application, config_location, rules_location, env_variables, extra_args)[0]
    print(eval_run_id)
    if not status:
        raise RuntimeError(f"Databricks failed to execute DVP report step for: {application.name}")


def __build_parameters(
    config_location: str,
    rules_location: str,
    result_sink: str,
    env_variables: dict,
    extra_args: dict,
    extra_params: Optional[list] = None,
) -> list:
    parameters = [
        "--conf",
        "spark.app.name=dvp",
        "--conf",
        "spark.dvp.config.provider=dbfs",
        "--conf",
        f"spark.dvp.config.env={config_location}/env.yaml",
        "--conf",
        f"spark.dvp.config.sources={config_location}/sources.yaml",
        "--conf",
        f"spark.dvp.config.dataset={config_location}/dataset.yaml",
        "--conf",
        f"spark.dvp.config.sinks={config_location}/sinks.yaml",
        "--conf",
        f"spark.dvp.config.providers={config_location}/providers.yaml",
        "--conf",
        f"spark.dvp.rules.path={rules_location}",
        "--conf",
        "spark.dvp.log.sink=dvp-log-sink",
        "--conf",
        f"spark.dvp.result.sink={result_sink}",
    ]
    parameters.extend(extra_params or [])
    parameters.extend(
        [
            "--dataversion",
            extra_args.get("dataversion", "1"),
            "--comparatortype",
            "periodicrefresh",
            "--client",
            extra_args["client"],
            "--env",
            extra_args["env"],
            "--level",
            extra_args["level"],
            "--sequence_number",
            extra_args["version"],
            "--version",
            extra_args["version"],
            "--extra_args",
            ",".join([f"{k}={v}" for k, v in env_variables.items()]),
        ]
    )
    return parameters


def __dvp_run_measure_metric(
    settings: Settings,
    application: ApplicationConfiguration,
    layer: str,
    config_location: str,
    rules_location: str,
    env_variables: dict,
    extra_args: dict,
) -> Tuple[bool, Optional[str], Optional[str]]:
    run_name = f"UnifAI Data-Quality (DVP) - {application.name}.{layer}"
    dvp_jar_location = clean_path(application.get("DATA_QUALITY_DEP_DVP"), "/dbfs")
    submit_body = {
        "run_name": run_name,
        "spark_submit_task": {
            "parameters": __build_parameters(
                f"{config_location}/{layer}",
                f"{rules_location}/{layer}/*",
                "dvp-result-sink",
                env_variables,
                extra_args,
                [
                    "--class",
                    "com.optum.dvp.Application",
                    dvp_jar_location,
                    "--layer",
                    layer,
                    "--repartitionsize",
                    "2",
                    "--username",
                    "DVP",
                ],
            ),
        },
        "new_cluster": _setup_job_cluster(application, f"Data-Quality (DVP) {layer}", env_variables),
    }
    return db_run_job(run_name, f"{settings['DATABRICKS_HOST']}", submit_body)


def __dvp_run_evaluation(
    settings: Settings,
    application: ApplicationConfiguration,
    config_location: str,
    rules_location: str,
    env_variables: dict,
    extra_args: dict,
) -> Tuple[bool, Optional[str], Optional[str]]:
    layer = "evaluation"
    run_name = f"UnifAI Data-Quality (DVP) - {application.name}.{layer}"
    dvp_jar_location = clean_path(application.get("DATA_QUALITY_DEP_DVP"), "/dbfs")
    dvp_zip_location = clean_path(application.get("DATA_QUALITY_DEP_DVP_ZIP"), "/dbfs")
    submit_body = {
        "run_name": run_name,
        "spark_submit_task": {
            "parameters": __build_parameters(
                f"{config_location}/{layer}",
                f"{rules_location}/{layer}/*",
                "dvp-result-sink",
                env_variables,
                extra_args,
                [
                    "--jars",
                    dvp_jar_location,
                    "--py-files",
                    f"{dvp_zip_location}/eval/DataQuality_Evaluation.zip",
                    f"{dvp_zip_location}/eval/__init__.py",
                    "--username",
                    "DVP",
                ],
            ),
        },
        "new_cluster": _setup_job_cluster(application, f"Data-Quality (DVP) {layer}", env_variables),
    }
    return db_run_job(run_name, f"{settings['DATABRICKS_HOST']}", submit_body)


def __dvp_run_report(
    settings: Settings,
    application: ApplicationConfiguration,
    config_location: str,
    rules_location: str,
    env_variables: dict,
    extra_args: dict,
) -> Tuple[bool, Optional[str], Optional[str]]:
    layer = "report"
    run_name = f"UnifAI Data-Quality (DVP) - {application.name}.{layer}"
    dvp_jar_location = clean_path(application.get("DATA_QUALITY_DEP_DVP"), "/dbfs")
    dvp_zip_location = clean_path(application.get("DATA_QUALITY_DEP_DVP_ZIP"), "/dbfs")
    submit_body = {
        "run_name": run_name,
        "spark_submit_task": {
            "parameters": __build_parameters(
                f"{config_location}/{layer}",
                f"{rules_location}/report_generator/*",
                "dvp-report-sink",
                env_variables,
                extra_args,
                [
                    "--archives",
                    f"{dvp_zip_location}/report_generator/custom_config.json,"
                    f"{dvp_zip_location}/report_generator/generate_report_js.js,"
                    f"{dvp_zip_location}/report_generator/generate_reports.css,"
                    f"{dvp_zip_location}/report_generator/html_reports_template.html.template,"
                    f"{dvp_zip_location}/report_generator/index.html.template",
                    "--jars",
                    dvp_jar_location,
                    "--py-files",
                    f"{dvp_zip_location}/report_generator/DataQuality_Report_Generator.zip",
                    f"{dvp_zip_location}/report_generator/__init__.py",
                    "--delivery_mode",
                    "email",
                    "--baseURL",
                    "dummy",
                    "--report_metadata_path",
                    f"{rules_location}/report_generator/periodicrefresh/",
                ],
            ),
        },
        "new_cluster": _setup_job_cluster(application, f"Data-Quality (DVP) {layer}", env_variables),
    }
    return db_run_job(run_name, f"{settings['DATABRICKS_HOST']}", submit_body)


def __insert_data(
    settings: Settings,
    application: ApplicationConfiguration,
    layer: str,
    status: bool,
    databricks_job_id: Optional[str],
    databricks_run_id: Optional[str],
    config_location: str,
    start_time: str,
    extra_args: dict,
    orchestration_id: Optional[str],
    orchestration_data: Optional[dict],
):
    additional_params = [f"{k}={v}" for k, v in extra_args.items()]
    status_msg = None if status else f"Databricks failed to execute DVP {layer} step for: {application.name}"
    run_id = _insert_data(
        settings,
        application,
        databricks_job_id,
        databricks_run_id,
        status_msg,
        "ai_check_report.py",
        layer,
        config_location,
        start_time,
        ",".join(additional_params),
        orchestration_id,
        orchestration_data,
    )
    if not status:
        raise RuntimeError(status_msg)
    return run_id
