"""Utilities for schema management."""

import json
from collections.abc import Sequence
from re import search
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import yaml
from pyspark.sql import Catalog
from pyspark.sql import SparkSession


ADVANCED_DBRICKS_VERS = ["11.3", "12.2"]


class UpdateSchemaStatements(Sequence):
    """List-like (Sequence) to parse files into Spark / Databricks create/update statements."""

    def __init__(
        self, yaml_file: str, location_root: str, version: str, dbricks_vers: str, app_id: Optional[str] = None
    ) -> None:
        """Creates a CreateTableStatmenets Object using the file(s) at path, a schema_name and a storage location."""
        self.spark = SparkSession.builder.getOrCreate()
        self.schema_name = Catalog(self.spark).currentDatabase() + "."
        self.schemas = {}
        self.statements: List[Tuple[str, Optional[List[str]]]] = []

        self.location_root = location_root
        if self.location_root[-1] == "/":
            self.location_root = self.location_root[:-1]

        # Process each schema defined in the yaml file
        with open(yaml_file) as f:
            schemas = yaml.safe_load(f)
            for name, config in schemas.items():
                config = self._convert_schema_format(config, yaml_file)
                self.statements.append((name, self._load_table_definition(name, config, version, dbricks_vers, app_id)))
                self.schemas[name] = config

    def _convert_schema_format(self, config: Any, yaml_file: str) -> dict:
        """Convert old schema formated files to new structure."""
        columns: Dict[str, Any] = {}
        partitioned_by: List[str] = []
        type = "delta"
        allow_empty = "false"

        if isinstance(config, dict):
            columns = config["columns"]
            partitioned_by = partitioned_by if not config.get("partitioned_by") else config["partitioned_by"]
            type = type if not config.get("type") else config["type"]
            allow_empty = allow_empty if not config.get("allow_empty") else config["allow_empty"]
        elif isinstance(config, list):
            for col in config:
                col_name = list(col.keys())[0]
                columns[list(col.keys())[0]] = col[col_name]
        else:
            raise RuntimeError(f"Unsupported schema format in {yaml_file}")
        # Loop over config list
        for col_name, col_cfg in columns.items():
            # config is a dict
            if isinstance(col_cfg, dict):
                data_type = col_cfg.get("data_type", "STRING")
                auto_increment = col_cfg.get("auto_increment", False)
                not_null = col_cfg.get("not_null", False)
                comment = col_cfg.get("comment", None)
            else:
                data_type = f"{col_cfg}"
                auto_increment = False
                not_null = False
                comment = None
            columns[col_name] = {
                "data_type": data_type,
                "auto_increment": auto_increment,
                "not_null": not_null,
                "comment": comment,
            }
        return {"type": type, "partitioned_by": partitioned_by, "columns": columns, "allow_empty": allow_empty}

    def _load_table_definition(
        self, name: str, new_config: dict, version: str, dbricks_vers: str, app_id: Optional[str] = None
    ) -> List[str]:
        """Get the table schema from UnifAI."""
        old_config: Optional[dict] = None
        try:
            sql_app_id = "NULL" if not app_id else f"'{app_id}'"
            schema_def = self.spark.sql(
                f"""
                SELECT s.*
                  FROM {self.schema_name}unifai_core_schemas s
                 WHERE nvl(s.application_id, '---') = nvl({sql_app_id}, '---')
                   AND s.name = '{name}'
                   AND s.status = 0
                """
            ).collect()[0]
            # Return if there were no release changes
            if schema_def.version == version:
                return []
            old_config = json.loads(schema_def.configuration)
        except Exception:  # noqa: S110
            pass

        if not old_config:
            old_config = self._describe_schema(name)

        # Compare old and new schemas
        result = None

        if old_config and (new_config["type"] != "view") and (new_config["type"] == old_config["type"]):
            result = self._alter_table_schema(name, new_config, old_config, dbricks_vers)
        # No existing valid schema found or unable to alter, then create/replace
        if result is None:
            result = self._create_replace_schema(name, new_config, dbricks_vers)
        return result

    def _describe_schema(self, name: str) -> Optional[dict]:
        """Get the schema from DeltaLake."""
        try:
            out: Dict[str, Any] = {
                "type": "delta",
                "columns": {},
                "sql": "",
            }
            sql_block = False
            # Extract schema definition
            schema_info = (
                self.spark.sql(
                    f"""
                    SHOW TABLE EXTENDED
                        FROM {self.schema_name.replace('.', '')}
                        LIKE '{name}'
                    """
                )
                .collect()[0]
                .information
            )
            # Read definition line by line
            for line in schema_info.split("\n"):
                # End of SQL block
                if line.startswith("View Original Text:"):
                    sql_block = False
                # Start SQL Block
                elif sql_block or line.startswith("View Text:"):
                    out["sql"] += line.replace("View Text:", "")
                    sql_block = True
                # Is View nased on Type
                elif line == "Type: VIEW":
                    out["type"] = "view"
                # Is Table (delta,csv, parquet) based on provider
                elif line.startswith("Provider:"):
                    out["type"] = line.replace("Provider: ", "").lower()
                # Extract column definition
                elif line.startswith(" |--"):
                    match = search(r"-- (.+?): (.+?) \(nullable = (.+?)\)$", line)
                    if match:
                        out["columns"][f"{match.group(1)}"] = {
                            "data_type": (match.group(2).upper()),
                            "not_null": (match.group(3) == "false"),
                            "comment": None,
                        }
            return out
        except Exception:
            return None

    def _alter_table_schema(
        self, name: str, new_config: dict, old_config: dict, dbricks_vers: str
    ) -> Optional[List[str]]:
        """Alter schema based on config differances."""
        # match new to old columns
        matched_cols = self._match_columns(new_config["columns"], old_config["columns"], new_config["type"])
        # track generated statements
        alter_strings: List[str] = []
        first_after = "FIRST"
        for col_name, col_config, state in matched_cols:
            new_state = self.__alter_table_schema_states(
                state, name, col_name, col_config, new_config["type"], first_after, dbricks_vers, alter_strings
            )
            # Exit unsupported dbversion (state is null)
            if not new_state:
                return None
            # alter column -- comment
            if "/comment" in new_state:
                comment = "" if not col_config.get("comment") else f"COMMENT '{col_config['comment']}'"
                alter_strings.append(
                    f"""
                    ALTER TABLE {self.schema_name}{name}
                    ALTER COLUMN `{col_name}`
                    {comment}
                    """
                )
            # alter column -- not null
            if "/not_null" in new_state:
                self.__alter_table_schema_nullable(name, col_name, col_config, alter_strings)
            # if add column will be after current
            first_after = f"AFTER `{col_name}`"

        if new_config.get("allow_empty", False) != old_config.get("allow_empty", False):
            alter_strings.append(
                f"""
                ALTER TABLE {self.schema_name}{name}
                SET TBLPROPERTIES ('unifai.allow_empty' = {new_config["allow_empty"]})
                """
            )
        return alter_strings

    def __alter_table_schema_states(
        self,
        state: str,
        table_name: str,
        col_name: str,
        col_config: dict,
        type: str,
        first_after: str,
        dbricks_vers: str,
        alter_strings: list,
    ) -> Optional[str]:
        # add column

        if state == "add":
            alter_strings.append(
                f"""
                ALTER TABLE {self.schema_name}{table_name}
                    ADD COLUMN {self._describe_column(col_name, col_config, type, dbricks_vers, True)}
                {first_after}
                """
            )
            state = "add/not_null"
        # drop column
        elif state == "drop":
            # Unsupported operation (Drop not supported, so making the column nullable)
            if dbricks_vers not in ADVANCED_DBRICKS_VERS:
                alter_strings.append(
                    f"""
                    ALTER TABLE {self.schema_name}{table_name}
                    ALTER COLUMN `{col_name}`
                        DROP NOT NULL
                    """
                )
            else:
                alter_strings.append(
                    f"""
                    ALTER TABLE {self.schema_name}{table_name}
                        DROP COLUMN `{col_name}`
                    """
                )
        # rename column
        elif state.startswith("rename"):
            # Unsupported operation (will recreate the schema instead)
            if dbricks_vers not in ADVANCED_DBRICKS_VERS:
                return None
            alter_strings.append(
                f"""
                ALTER TABLE {self.schema_name}{table_name}
                RENAME COLUMN `{col_config["renamed_from"]}` TO `{col_name}`
                """
            )
        return state

    def __alter_table_schema_nullable(
        self, table_name: str, col_name: str, col_config: dict, alter_strings: list
    ) -> None:
        col_default = col_config.get("default")
        # Drop not null
        if col_config.get("not_null", False) is False:
            alter_strings.append(
                f"""
                ALTER TABLE {self.schema_name}{table_name}
                ALTER COLUMN `{col_name}`
                    DROP NOT NULL
                """
            )
        # Set not null (only if there is a default value)
        elif col_default:
            # ensure any nulls are updated with default value
            col_type = col_config.get("data_type", "STRING").upper()
            if col_type in ["BOOLEAN", "BIGINT", "DOUBLE", "INT"]:
                sql_default = col_default
            elif col_default in ["current_user()", "current_timestamp()"]:
                sql_default = col_default
            else:
                sql_default = f"'{col_default}'"
            alter_strings.append(
                f"""
                UPDATE {self.schema_name}{table_name}
                    SET `{col_name}`={sql_default}
                    WHERE `{col_name}` IS NULL
                """
            )
            # make column not null
            alter_strings.append(
                f"""
                ALTER TABLE {self.schema_name}{table_name}
                ALTER COLUMN `{col_name}`
                    SET NOT NULL
                """
            )

    def _match_columns(self, new_cols: dict, old_cols: dict, type: str) -> List[Tuple[str, dict, str]]:
        """Match new with old columns."""
        # match new to old columns
        matched_cols = []
        for ncol_name, ncol in new_cols.items():
            ncol_old_name = ncol.get("renamed_from")
            # find matching column
            rcol_name = None
            state = "add"
            for ocol_name, ocol in old_cols.items():
                if ncol_name == ocol_name:
                    rcol_name = ocol_name
                    state = self._filter_unchanged_column("alter", ncol, ocol, type)
                    break
                elif type == "delta" and ncol_old_name == ocol_name:
                    rcol_name = ocol_name
                    state = self._filter_unchanged_column("rename", ncol, ocol, type)
                    break
            # only include column if new, changed or renamed
            if state == "add" or state.startswith("alter/") or state.startswith("rename"):
                matched_cols.append((ncol_name, ncol, state))
            # remove matched old column
            if rcol_name:
                old_cols.pop(rcol_name)
        # match old (removed) columns
        for ocol_name, ocol in old_cols.items():
            matched_cols.append((ocol_name, ocol, "drop"))
        return matched_cols

    def _filter_unchanged_column(self, state: str, ncol: dict, ocol: dict, type: str) -> str:
        # change to comments
        if ncol.get("comment") != ocol.get("comment"):
            state += "/comment"

        # change to data-type
        if ncol["data_type"] != ocol["data_type"]:
            state += "/data_type"

        # change to nullability
        if type == "delta" and ncol.get("not_null") != ocol.get("not_null"):
            state += "/not_null"

        return state

    def _create_replace_schema(self, name: str, config: dict, dbricks_vers: str) -> List[str]:
        """Generate new schema SQL based on YAML deffinition."""
        # from unifai_core.app.utils import db_fs_remove
        try:
            # convert column definition into SQL
            partitioned = ""
            type = config["type"]
            allow_empty = config.get("allow_empty", "false")
            col_strings = []
            if isinstance(config["columns"], dict):
                for col_name, col_config in config["columns"].items():
                    col_strings.append(f"{self._describe_column(col_name, col_config, type, dbricks_vers, False)}")
            else:
                raise TypeError(f"{name!r} doesn't not appear to be a valid schema definition!")
            # Define the location based on the type
            if type == "view":
                sql_type = "VIEW"
                location = f"AS {config['sql'].replace('{schema_name}', self.schema_name)}"
            else:
                sql_type = "TABLE"
                location = f"USING {type.upper()} LOCATION '{self.location_root}/{name}'"
                # db_fs_remove(f"{self.location_root}/{name}", True)
                # Define partitioning information
                partitioned = ", ".join(config.get("partitioned_by", []))
                if len(partitioned) > 0:
                    partitioned = f" PARTITIONED BY({partitioned})"
            # Generate create/replace SQL statement
            sql_cols = ", ".join(col_strings)
            out = [
                f"DROP {sql_type} IF EXISTS {self.schema_name}{name}",
                f"""
                CREATE {sql_type} {self.schema_name}{name}(
                    {sql_cols}
                ) {location}{partitioned}
                """,
            ]

            if sql_type == "TABLE":
                out.append(
                    f"""
                    ALTER {sql_type} {self.schema_name}{name}
                    SET TBLPROPERTIES (
                        'delta.columnMapping.mode' = 'name',
                        'delta.minReaderVersion' = '2',
                        'delta.minWriterVersion' = '5',
                        'unifai.allow_empty' = '{allow_empty}'
                    )
                    """
                )
            return out
        except AttributeError as exc:
            raise TypeError(f"{name!r} doesn't not appear to contain a valid schema definition!") from exc

    def _describe_column(
        self, col_name: str, col_config: dict, type: str, dbricks_vers: str, no_null: bool = False
    ) -> str:
        """Takes a column definition and turns it into sql.

        Converts it into a string of col_name, data_type, not_null and comment
        """
        data_type = ""
        comment = ""
        not_null = ""
        auto_increment = ""
        default_expr = ""
        # parse configuration for supported table properties
        if type != "view":
            data_type = f" {col_config.get('data_type', 'STRING')}".upper()
            if col_config.get("auto_increment"):
                data_type = " BIGINT"
                auto_increment = " GENERATED BY DEFAULT AS IDENTITY(START WITH 1001 INCREMENT BY 1)"
                if not no_null:
                    not_null = " NOT NULL"

            elif col_config.get("not_null") and not no_null:
                not_null = " NOT NULL"

            # Optionally set column default (version specific)
            # if dbricks_vers in ADVANCED_DBRICKS_VERS and col_config.get("default"):
            #     default_expr = f" DEFAULT {col_config['default']}"

        if col_config.get("comment"):
            comment = f" COMMENT '{col_config['comment']}'"

        return f"`{col_name}`{data_type}{not_null}{auto_increment}{default_expr}{comment}"

    def get_schema_details(self, table_name: str) -> dict:
        """Returns the schema representation object."""
        return self.schemas[table_name]

    def __getitem__(self, index) -> Tuple[str, List[str]]:
        """Returns index item from list of statements."""
        return self.statements[index]

    def __len__(self):
        """Returns length of statements list (i.e. number of statements available)."""
        return len(self.statements)
