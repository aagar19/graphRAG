"""Support for managing unifai-core and unifai-application schemas."""
