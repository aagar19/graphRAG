"""Utilities to support legacy (pre-UnifAI pipelines).

Includes path-to-table-adapter (DataIO) class and config helpers.
"""
