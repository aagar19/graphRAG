"""Utilities for updating placeholder values in nested dictionary."""

import os
import re
from typing import Any
from typing import Dict
from typing import Optional


def _replace_template(to_replace: str, replacements: Dict[str, str], base_string: Optional[str] = None) -> str:
    """Replaces placeholder values with provided replacements."""
    key = to_replace.lstrip("{").rstrip("}")
    if key in replacements:
        replacement = replacements[key]
        if base_string is not None:
            updated_value = base_string.replace(to_replace, str(replacement))
            if "path" in to_replace.lower():
                return os.path.abspath(updated_value) + "/"  # Preserve trailing slash for existing pipeline path `+`
            else:
                return updated_value
        else:
            return replacement
    else:
        return to_replace


def _templates(base_string: str):
    """Finds instances of templates (`{...}`) in a given string."""
    templates = re.findall(r"\{.*?\}", base_string)
    return templates


def replace_templates(templated_dict: Dict[str, Optional[Any]], **kwargs):
    """Recursively replaces placeholder values in dictionary."""
    d = templated_dict.copy()
    templates = dict({k.upper(): v for k, v in kwargs.items()})

    # Replace all {STRING} placeholders in nested dictionary
    for key, value in d.items():
        if isinstance(value, dict):
            d[key] = replace_templates(value, **templates)
        elif isinstance(value, str) and value is not None:
            templated_values = _templates(value)
            if any(templated_values):
                if len(templated_values) == 1 and len(templated_values[0]) == len(value):
                    # 1-1 replace templated value and preserve replacement datatype
                    updated_value = _replace_template(templated_values[0], templates)
                else:
                    # Replace each templated value, formatting as string
                    updated_value = value
                    for template in templated_values:
                        updated_value = _replace_template(template, templates, updated_value)
                d[key] = updated_value
    return d
