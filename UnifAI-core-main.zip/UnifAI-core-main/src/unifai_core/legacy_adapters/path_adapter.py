"""tbc."""

import os
import pickle  # noqa: S403
import re
from fnmatch import fnmatch
from typing import Optional

import pandas
from pyspark.sql import DataFrame as pyspark_DataFrame


DEFAULT_PATH = "/tmp/__UNIFAI_APP__/"  # noqa: S108
SUPPORTED_FILETYPES = ("csv", "dict", "excel", "html", "json", "orc", "parquet", "pickle", "text")  # Superset


def _infer_filetype_from_load():
    pass


def _infer_filetype_from_path(path):
    """Infers filetype from path."""
    base, extension = os.path.splitext(path)
    if "/" in base:
        if extension in (".csv", ".txt"):  # Spark writes csv to directory
            return "csv"
        elif extension in (".xlsx", ".xlsm", ".xls"):
            return "excel"
        elif extension in ("", ".parquet", ".pq"):  # Pandas writes parquet as file
            return "parquet"
    elif "." in path or not extension:
        return "table"
    return None


def _validate_path(path):
    """Validates path.

    Path is considered valid if doesn't start with the UnifAI config placeholder value ('/tmp/__UNIFAI_APP__/').
    (Any FileNotFound errors will be raised and handled in data load/write calls.)
    """
    if path.startswith(DEFAULT_PATH):
        raise ValueError(f"No table mapping found for path `{path}`; path should not start with `{DEFAULT_PATH}`")
    return path


def _validate_table(table_dict):
    """Validates table config.

    Table config is considered valid if either "table" (schema.table name is specified), o
        or the config contains a UnifAI output store mapping.
    """
    if table_dict["table"] is None and "output_store_mapping" not in table_dict:
        raise ValueError("Table mapping must contain either table name, or output_store_mapping")
    return table_dict


def infer_filetype(path):
    """Given a path, try to guess the filetype.

    Detects Excel, parquet, and csv filetypes by looking at the extension in the path.
    Detects SQL tables when there are no directories involved in the path.

    Possible outputs are "excel", "csv", "parquet", "table".

    Raises an error in all other cases.

    Examples:
    infer_filetype("/path/to/a.xls") => "excel"
    infer_filetype("spark_users") => "table"
    infer_filetype("music/bad_romance.mp3") => Raises ValueError
    """
    inferred_from_path = _infer_filetype_from_path(path)
    if inferred_from_path is not None:
        return inferred_from_path
    else:
        raise ValueError("Unable to infer file type; please specify `filetype={csv,parquet,...}`")


def find_matching_tables(path, mappings):
    """Matches keys from table_mappings to path's basename.

    Matches keys from table_mappings to path's basename.
    Recursively searches nested table_mapping dictionaries.
    Uses `fnmatch` module for key-basename match to support Unix shell-style expressions in keys.

    Args:
        path: provided path from dataio call (e.g., /path/to/file.csv)
        mappings: key-table_definition mapping (full self.table_mappings or nested key dictionary)

    Returns:
        List of table definitions (key->value, dictionaries), matched from path
    """
    tables = []
    for key, value in mappings.items():
        if isinstance(value, dict):
            if "table" not in value:
                tables.extend(find_matching_tables(path, value))
            elif fnmatch(os.path.basename(path), key):
                tables.append(value)
    unique_tables = [x for n, x in enumerate(tables) if tables.index(x) == n]
    return unique_tables


def map_path_to_target(path, table_mappings):
    """Retrieves matching entries from table_mappings for the given path.

    Retrieves matching entries from table_mappings for the given path.
    Validates returned matching table dictionary (if single unique match) or path if no matches are returned.
    Otherwise raises a ValueError if more than one matching table is found.

    Args:
        path: provided path from dataio call (e.g., /path/to/file.csv)
        table_mappings: a dictionary that maps filenames to hive metastore tables.
            Expects convention, {
                file_basename: {
                    table: hive metastore table name (e.g., deltalake table name)
                    schema (optional): table's schema (defaults to spark session's current db, e.g., UnifAI schema)
                    output_store_mapping (optional): {
                        calc_column_mappings: {...},
                        data_link_columns: [...]
                    }
                }
            }
            `table` can be None if `output_store_mapping` is specified.
            Supports Unix shell-style expressions in file basename (via fnmatch).

    Returns:
        table_config (if single unique match) or path (if path-validation is met)
        boolean indicator for whether the first returned value is a table config.

    Raises:
        ValueError: if multiple unique table mappings are found
    """
    # Find matching basenames --> table lookup match
    tables = find_matching_tables(path, table_mappings)

    # Return target
    if len(tables) == 1:
        _validate_table(tables[0])
        return tables[0], True  # Return table dict and is_table=True
    elif len(tables) == 0:
        _validate_path(path)
        return path, False  # Return path and is_table=False
    else:
        # TODO: add table mapping validation
        raise ValueError(f"Found multiple table mappings for path `{os.path.basename(path)}`")


class DataIO:
    """Wrapper class for handling I/O.

    Dispatches read/write operations to whichever pandas/spark methods are appropriate.
    Initializer optionally take a spark argument (a spark session), and spark-oriented
    operations require this to be present.

    Initializer inputs:
    spark: a spark session -- needed if dealing with spark dataframes
    table_mappings: a structure that maps filenames and config options
                    to deltalake tables
    unifai_job_instance (optional): a UnifaiJob (or child) object; required for read/writes from tables.

    Examples of use:
    dataio = DataIO(spark)

    dataio.read_csv(<path>) => use pandas to read the csv
    dataio.read.csv(<path>) => use spark to read the csv
    dataio.read_parquet(<path>) => use pandas to read the parquet
    dataio.read.parquet(<path>) => use spark to read the parquet

    dataio(df).to_csv(<path>) => write df to a csv, using pandas

    Generally,
    - dataio.read is a DataFrameReader
    - method calls to read_* are dispatched to pandas, when possible
    - dataio(df) returns df
    """

    def __init__(self, spark=None, table_mappings=None, unifai_job_instance=None):
        """Initializes DataIO.

        Args:
            spark: spark session; required if interacting with spark dataframes or tables
            table_mappings: a dictionary that maps filenames to hive metastore tables.
                Expects convention, {
                    file_basename: {
                        table: hive metastore table name (e.g., deltalake table name)
                        schema (optional): table's schema (defaults to spark session's current db, e.g., UnifAI schema)
                        output_store_mapping (optional): {
                            calc_column_mappings: {...},
                            data_link_columns: [...]
                        }
                    }
                }
                `table` can be None if `output_store_mapping` is specified.
                Supports Unix shell-style expressions in file basename (via `fnmatch`).
            unifai_job_instance (optional): a UnifaiJob (or child) object; required for read/writes from tables.

        Also creates attributes
            `read` with DataFrameReader initialized with spark, table_mappings, and unifai_job
            `model` with initialized ModelIO
        """
        self.spark = spark
        self.unifai_job = unifai_job_instance
        self.table_mappings = table_mappings or {}
        self.read = DataFrameReader(spark, self.table_mappings, self.unifai_job)
        self.model = ModelIO()
        self.map_path_to_target = map_path_to_target
        self.infer_filetype = infer_filetype

    def __call__(self, obj):
        """Returns DataFrameWrapper instance initialized with table_mappings, unifai_job, and spark."""
        if isinstance(obj, pandas.DataFrame) or isinstance(obj, pyspark_DataFrame):
            return self.dataframe_wrapper(obj)
        else:
            raise TypeError(f"DataIO not callable for object {type(obj)}")

    def __getattr__(self, attr):
        """Returns pandas callable.

        Currently allows attribute starting with `read_`
        and for limited pandas `read_{filetype}` and ExcelFile.
        Otherwise raises an Attribute error.
        """
        if (attr.startswith("read_") and re.sub("^read_", "", attr) in SUPPORTED_FILETYPES) or attr == "ExcelFile":

            def read_pandas_callable(*args, **kwargs):
                return self.read(filetype=re.sub("^read_", "", attr), dest="pandas", *args, **kwargs)  # noqa: B026

            return read_pandas_callable
        else:
            raise AttributeError(f"'DataIO' object has no attribute attribute '{attr}'")

    def dataframe_wrapper(self, df):
        """Returns DataFrameWrapper instance initialized with table_mappings, unifai_job, and spark."""
        return DataFrameWrapper(df, self.table_mappings, self.unifai_job, self.spark)


class DataFrameReader:
    """A dataframe reader.

    To provide a unified interface to read in either pandas or spark dataframes.
    Must be initialized with spark (a spark session), and table_mappings.

    Once initialized, the instance can be used as a function -- see the read method
    docstring for details.

    A core function of a class instance is to behave like the read attribute of a
    spark session. Thus, dataframe_reader.parquet(<args>) and dataframe_reader.csv(<args>)
    can be used in place of spark.read.parquet and spark.read.csv, respectively.
    """

    def __init__(self, spark, table_mappings, unifai_job):
        """Initializes DataFrameReader.

        Args:
            spark: spark session; required if interacting with spark dataframes or tables
            table_mappings: a dictionary that maps filenames to hive metastore tables.
                Expects convention, {
                    file_basename: {
                        table: hive metastore table name (e.g., deltalake table name)
                        schema (optional): table's schema (defaults to spark session's current db, e.g., UnifAI schema)
                        output_store_mapping (optional): {
                            calc_column_mappings: {...},
                            data_link_columns: [...]
                        }
                    }
                }
                `table` can be None if `output_store_mapping` is specified.
                Supports Unix shell-style expressions in file basename (via `fnmatch`).
            unifai_job (optional): a UnifaiJob (or child) object; required for read/writes from tables.

        Once initialized, can be used as a function -- see read method docstring for details.
        """
        self.spark = spark
        self.table_mappings = table_mappings
        self.unifai_job = unifai_job

    def __call__(self, path, filetype=None, dest="spark", **kwargs):
        """Returns result of self.read_from_table_or_path(...)."""
        return self.read_from_table_or_path(path, filetype, dest, **kwargs)

    def __getattr__(self, attr):
        """Returns `self.read` callable.

        Supports `dataio.read.{filetype}` for generic filetypes.
        """
        if attr in SUPPORTED_FILETYPES:

            def read_callable(*args, **kwargs):
                return self.read_from_table_or_path(filetype=attr, *args, **kwargs)

            return read_callable
        else:
            raise AttributeError(f"DataIO 'DataFrameReader' object has no attribute attribute '{attr}'")

    def read_from_table_or_path(self, path, filetype=None, dest="spark", **kwargs):
        """All-purpose method for reading dataframes.

        Inputs:
            path: self-explanatory.
                  Required argument.
            filetype: if `None` will try to automatically detect the filetype
                      (c.f. this module's infer_filetype docstring).
                      Otherwise, any supported spark/pandas filetype. Defaults to None.
            dest: `pandas` or `spark`. Defaults to `spark`.
            kwargs: passed through as arguments to spark/pandas readers.
        """
        # Get target (table reference or path)
        target_name, is_table = map_path_to_target(path, self.table_mappings)

        if is_table:
            df = self.read_from_table(f'{target_name["schema"]}.{target_name["table"]}')
            if dest == "pandas":
                df = df.toPandas()
        else:
            df = self.read_from_path(target_name, filetype, dest, **kwargs)
        return df

    def read_from_path(self, path, filetype: Optional[str] = None, dest: str = "spark", **kwargs):
        """Load data from provided path.

        Args:
            path: provided path to data, from dataio call (e.g., /path/to/file.csv)
            filetype: (str) type of file on given path, e.g., 'csv' or 'parquet'
                Defaults to `None` and attempts to infer filetype from path.
            dest: value in ['spark', 'pandas'] to indicate destination object type; defaults to `spark`
            kwargs: passed through as arguments to spark/pandas readers.

        Returns:
            pyspark or pandas dataframe, given `dest`

        Raises:
            ValueError: if `dest` is not in ['spark', 'pandas']

        """
        if filetype is None:
            filetype = infer_filetype(path)
        if dest == "spark":
            return self._read_spark_from_path(path, filetype, **kwargs)
        elif dest == "pandas":
            return self._read_pandas_from_path(path, filetype, **kwargs)
        else:
            raise ValueError("`dest` must be in (spark, pandas)")

    def read_from_table(self, tablename):
        """Calls UnifaiJob object's `load_table` method to load data from table.

        Args:
            tablename: table name (schema.table, or table) from which to load data

        Returns:
            spark DataFrame
        """
        # This will be updated based on Data SDK (just loading table now)
        return self.unifai_job.load_table(self.spark, tablename).drop(
            "orchestration_id", "run_id", "run_as_of", "run_type"
        )

    def _read_spark_from_path(self, path, filetype: Optional[str] = None, **kwargs):
        """Loads data to spark dataframe via spark DataFrameReader.

        Args:
            path: provided path to data, from dataio call (e.g., /path/to/file.csv)
            filetype: (str) type of file on given path, e.g., 'csv' or 'parquet';
                used in spark.read.format(filetype)
            kwargs: generic spark DataFrameReader kwargs

        Returns:
            spark DataFrame
        """
        spark_reader = self.spark.read.format(filetype)
        for _, value in kwargs.items():
            if isinstance(value, dict) and value is not None:
                spark_reader.options(**value)
        return spark_reader.load(path, **kwargs)

    @staticmethod
    def _read_pandas_from_path(path, filetype=None, **kwargs):
        """Loads data to pandas dataframe via pandas DataFrameReader.

        Args:
            path: provided path to data, from dataio call (e.g., /path/to/file.csv)
            filetype: (str) type of file on given path, e.g., 'csv' or 'parquet';
                used in pandas.read_{filetype} or pandas.ExcelFile if filetype == 'ExcelFile'
            kwargs: generic pandas DataFrameReader kwargs

        Returns:
            pandas DataFrame
        """
        return getattr(pandas, "ExcelFile" if filetype == "ExcelFile" else f"read_{filetype}")(path, **kwargs)


class DataFrameWrapper:
    """Class which wraps existing object (e.g., dataframe) into DataIO object.

    Currently used to support write-operations for dataframes.

    Args:
        dataframe: dataframe object (pandas or spark)
        table_mappings: a dictionary that maps filenames to hive metastore tables.
        unifai_job (optional): a UnifaiJob (or child) object; required for read/writes from tables.
        spark: spark session; required if interacting with spark dataframes or tables
    """

    def __init__(self, dataframe, table_mappings, unifai_job, spark):
        """Initializes DataFrameWrapper.

        Adds initialized DataFrameWriter as attribute `write`.
        """
        self._df = dataframe
        self.table_mappings = table_mappings
        self.unifai_job = unifai_job
        self.write = DataFrameWriter(dataframe, table_mappings, unifai_job, spark)
        self.spark = spark

    def __getattr__(self, attr):
        """Returns callable for initialized DataFrameWriter."""
        if attr.startswith("to_") and re.sub("^to_", "", attr) in SUPPORTED_FILETYPES:

            def write_callable(*args, **kwargs):
                writer = DataFrameWriter(self._df, self.table_mappings, self.unifai_job, self.spark)
                return writer(filetype=re.sub("^to_", "", attr), *args, **kwargs)  # noqa: B026

            return write_callable
        else:
            raise AttributeError(f"DataIO 'DataFrameWrapper' object has no attribute '{attr}'")


class DataFrameWriter:
    """DataFrame writer.

    Provides a unified interface for writing dataframes (whether pandas or spark)
    to path or table (if table is found in path-to-table mapping).

    Attempts to map provided paths to hive table (e.g., delta table).

    Once initialized, can be used as a function -- see write method docstring
    for details.
    """

    def __init__(self, dataframe, table_mappings, unifai_job, spark, _filetype=None):
        """Initializes DataFrameWriter.

        Args:
            dataframe: dataframe object (pandas or spark)
            table_mappings: a dictionary that maps filenames to hive metastore tables.
            unifai_job (optional): a UnifaiJob (or child) object; required for read/writes from tables.
            spark: spark session; required if interacting with spark dataframes or tables
            _filetype: (str) type of file on given path, e.g., 'csv' or 'parquet'
                Defaults to `None` and attempts to infer filetype from path.
        """
        self._df = dataframe
        self.table_mappings = table_mappings
        self.unifai_job = unifai_job
        self.spark = spark
        self._filetype = _filetype

    def __getattr__(self, attr):
        """Returns generic write callable.

        Currently allows attribute in SUPPORTED_FILETYPES
            (generic types for pandas and spark, e.g. "csv" or "parquet")
        Write callable attempts to map path to table and write from table instead of path.
        """
        if attr in SUPPORTED_FILETYPES:

            def write_callable(*args, **kwargs):
                return self.write_df(filetype=attr, *args, **kwargs)

            return write_callable
        else:
            raise AttributeError(f"DataIO 'DataFrameWriter' object has no attribute '{attr}'")

    def __call__(self, path, filetype=None, **kwargs):
        """Returns generic write callable.

        Attempts to map path to table and load from table instead of path.
        """
        return self.write_df(path, filetype=filetype, **kwargs)

    def write_df(self, path, filetype, **kwargs):
        """All-purpose method for writing dataframes.

        Attempts to map provided path to table and write to table instead of path.

        If path maps to table, then call `write_to_table` to write to table.
        If path does not map to table (and is otherwise validated in `map_path_to_target`),
            then call `write_to_path` to write to path.

        Args:
            path: the path to which df should be written (required)
            filetype: (str) type of file on given path, e.g., 'csv' or 'parquet';
                used if writing to path.
            kwargs: passed through to spark/pandas writer methods

        """
        # Get target (table reference or path)
        target_name, is_table = map_path_to_target(path, self.table_mappings)

        if is_table:
            self.write_to_table(target_name, kwargs.get("mode", "overwrite"))
        else:
            self.write_to_path(target_name, filetype, **kwargs)

    def write_to_table(self, target_name, mode):
        """Writes DataFrameWriter's dataframe to a table via UnifAI Job functions.

        If `table` is specified, then write to that table.
        If `output_store_mapping` specified, then write data to the output store.

        Args:
            target_name: dictionary containing table mapping
                (e.g., `table` {schema.table} or output store mapping config)
            mode: spark write mode (e.g., "overwrite" or "append");
                defaults to "overwrite" in UnifAI `write_to_table`
        """
        if target_name["table"] is not None:
            self.unifai_job.write_table(
                self.spark, self._df, target_name["table"], mode, target_name.get("update_to_match_schema", False)
            )
            # But choose a better key name
        if "output_store_mapping" in target_name:
            self.unifai_job.add_multi_bulk_output(data=self._df, **target_name["output_store_mapping"])

    def write_to_path(self, path, filetype=None, **kwargs):
        """All-purpose method for writing dataframes.

        Args:
            path: the path to which df should be written (required)
            filetype: (str) type of file on given path, e.g., 'csv' or 'parquet';
                used if writing to path.
            kwargs: passed through to spark/pandas writer methods

        Raises:
            ValueError: if write-to-UnifAI-default-path is detected
        """
        if path.startswith(DEFAULT_PATH):
            raise ValueError(
                f"Attempting to write to UnifAI-App default path {DEFAULT_PATH}; " "please specify non-default path"
            )
        if filetype is None:
            filetype = infer_filetype(path)
        if isinstance(self._df, pandas.DataFrame):
            self._write_pandas_to_path(path, filetype, **kwargs)
        else:
            self._write_spark_to_path(path, filetype, **kwargs)

    def _write_pandas_to_path(self, path, filetype, **kwargs):
        """Writes dataframe to path using pandas DataFrameWriter; `df.to_{filetype}(...))`."""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        getattr(self._df, f"to_{filetype}")(path, **kwargs)

    def _write_spark_to_path(self, path, filetype, **kwargs):
        """Writes dataframe to path using spark DataFrameWriter.

        Mimics df.write.{filetype}(...)) or df.write.format(filetype).mode(...).options...
        """
        dataframe_writer = self._df.write.format(filetype)

        # Specify write options
        for keyword, value in kwargs.items():
            if keyword == "mode":
                dataframe_writer.mode(value)
            elif isinstance(value, dict):
                dataframe_writer.options(**value)
            else:
                dataframe_writer.option(keyword, value)

        # Save data
        if filetype == "table":
            dataframe_writer.saveAsTable(path)
        else:
            dataframe_writer.save(path)


class ModelIO:
    """Placeholder class for MLFlow integration."""

    @staticmethod
    def load_csv(path):
        """Uses pandas to read the csv at the given path."""
        return pandas.read_csv(path)

    @staticmethod
    def load_pickle(path):
        """Loads the pickle file at the given path."""
        with open(path, "rb") as f:
            obj = pickle.load(f)  # noqa: S301
        return obj
