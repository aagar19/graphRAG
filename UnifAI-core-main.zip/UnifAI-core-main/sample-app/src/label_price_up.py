"""UnifAI job to calcuate n-day forward price change %."""

from datetime import date

from pyspark.sql import SparkSession

from unifai_core.app.output import add_bulk_output


def run_batch(n: int, run_as_of: date, ticker: str, batch_size: int = 1, **kwargs):
    """Calculate forward price change over the next 'n' days from 'run_as_of'."""
    spark = SparkSession.builder.getOrCreate()

    df = spark.table("sample_app_raw_historical_price")

    df = (
        df.orderBy(df.date_pk, ascending=False)
        .filter(df.date_pk <= run_as_of)
        .filter(df.ticker == ticker)
        .limit(batch_size + n)
    )

    df.createOrReplaceTempView("batch_price_chg")

    chgs = spark.sql(
        f"""select ticker, date_pk,
(last(close) Over (order by date_pk desc rows between current row and {n-1} following) - close) / close as value
from batch_price_chg"""
    )

    add_bulk_output(f"price_chg_in_{n}_days", chgs, {"data_link_value": "ticker", "run_as_of": "date_pk"}, **kwargs)
