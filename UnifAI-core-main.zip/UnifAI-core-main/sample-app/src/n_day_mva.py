"""Job to calculate 'n' day MVA for closing prices."""

from datetime import date

from pyspark.sql import SparkSession

from unifai_core.app.output import add_bulk_output
from unifai_core.app.output import add_output


def run(n: int, run_as_of: date, ticker: str, **kwargs):
    """Calculates a single 'n' day trailing MVA of closing price from run_as_of."""
    spark = SparkSession.builder.getOrCreate()

    df = spark.sql("select * from sample_app_raw_historical_price")

    mva = (
        df.orderBy(df.date_pk, ascending=False)
        .filter(df.date_pk <= run_as_of)
        .filter(df.ticker == ticker)
        .limit(n)
        .agg({"close": "sum"})
        .collect()[0][0]
    ) / n
    add_output(calculation_name=f"{n}_day_mva", value=mva, data_link_value=ticker, **kwargs)


def run_batch(n: int, run_as_of: date, ticker: str, batch_size: int = 1, **kwargs):
    """Calculates a multiple 'n' day trailing MVA of closing price from run_as_of."""
    spark = SparkSession.builder.getOrCreate()

    df = spark.table("sample_app_raw_historical_price")

    df = (
        df.orderBy(df.date_pk, ascending=False)
        .filter(df.date_pk <= run_as_of)
        .filter(df.ticker == ticker)
        .limit(batch_size + n)
    )

    df.createOrReplaceTempView("batch_n_day_mva")

    mvas = spark.sql(
        f"""select ticker, date_pk,
avg(close) Over (order by date_pk desc rows between current row and {n-1} following) as value
from batch_n_day_mva"""
    )

    add_bulk_output(f"{n}_day_mva", mvas, {"data_link_value": "ticker", "run_as_of": "date_pk"}, **kwargs)
