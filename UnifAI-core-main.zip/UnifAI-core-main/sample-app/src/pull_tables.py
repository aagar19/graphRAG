"""Pulls historical price data for UNH stock."""

import os

import pandas as pd

from unifai_core.jobs.base import UnifaiJob


class PullTablesJob(UnifaiJob):
    """PullTables UnifaiJob."""

    def load_data(self):
        """Loads data from static csv.

        To avoid external API calls or internet to download stock history
        for sample app, this function loads data from csv - sample-app/resources/UNH.csv.
        This is required as we have some restrictions in Optum network and
        limitations in yfinance module.
        """
        static_data_path = os.path.join(self.app_path, "resources", "UNH.csv")
        return pd.read_csv(static_data_path, index_col=[0])

    def execute(self, spark, **kwargs) -> None:
        """Execute pull of historical price data for stock."""
        unh_history = self.load_data()

        unh_df = spark.createDataFrame(unh_history.reset_index(level=0))
        unh_df.createOrReplaceTempView("unh_history")
        spark.sql("insert overwrite table sample_app_raw_historical_price select 'UNH', * from unh_history")
