[![Deploy static content to Pages](https://github.com/optum-labs/unifai-core/actions/workflows/pages.yml/badge.svg)][read the docs]
[![Tests](https://github.com/optum-labs/unifai-core/workflows/Tests/badge.svg)][tests]

<!-- start-import -->

[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)][pre-commit]
[![Black](https://img.shields.io/badge/code%20style-black-000000.svg)][black]

[read the docs]: https://fluffy-train-5f612406.pages.github.io/
[tests]: https://github.com/optum-labs/unifai-core/actions?workflow=Tests
[pre-commit]: https://github.com/pre-commit/pre-commit
[black]: https://github.com/psf/black

# Overview

UnifAI is a Python framework which unifies data science tools such as Databricks, Airflow and MLFlow. This centralized
solution empowers data scientists to deploy, train, version, parameterize and reproduce their AI/ML models seamlessly
through UnifAI CLI commands and the Airflow UI.

The UnifAI framework, through capturing metadata associated with model runs, enables insights in cost reduction in
running and training AI/ML models on Databricks clusters, enhances reporting capabilities through an abstracted and
centralized model output store and improves the speed of development for data scientists creating new AI/ML models.

## Prerequisites

### Databricks

At the moment, UnifAI only supports Databricks. If there is demand, UnifAI may support open source
Apache Spark in the future. The easiest way to get access to Databricks is via
[United-AI-Studio](https://unitedaistudio.uhg.com).

#### Workspace

For a first-time experience with United-AI-Studio, refer to [United-AI-Studio Create a Project](https://app.unitedaistudio.uhg.com/projects/create) and ensure the activation of Databricks in the 'Workspace Setup'. After creating a Databricks environment, generate a [Databricks Personal Access Token](https://learn.microsoft.com/en-us/azure/databricks/dev-tools/api/latest/authentication).

#### Bring your own data (B.Y.O.D)

After setting up a Databricks Workspace via United-AI-Studio, one might consider importing personal data into this Workspace. For guidance on this process, consult United-AI-Studio's [BYOD documentation](<https://github.com/optum-labs/unitedai-studio-documentation/wiki/How-to-bring-your-own-dataset-(BYOD)>).

For additional questions related to United-AI-Studio, refer to the [documentation site](https://github.com/optum-labs/unitedai-studio-documentation/wiki).

### Python

UnifAI core requires Python 3.8 or 3.9 (due to Databricks requirements). Utilizing the Homebrew installer simplifies Unifai-core setup on a MacOS laptop. This approach ensures the availability and correct configuration of the required version of Python to run UnifAI-core effectively.

## Installing UnifAI-core on MacOS

MacOS installation can be done through Homebrew. The steps to install UnifAI-core are: -

- Adding the UnifAI-core TAP

  ```{code-block}
  $ brew tap optum-labs/unifai-core
  ```

- Installing the `unifai-admin` command is done by running

  ```{code-block}
  $ brew install unifai-admin
  ```

Installing this will result in the latest version of UnifAI-core being present on the system, making the unifai-admin command available on the CLI.

- For downloading a previous version of UnifAI-core or querying available versions, employ the search option:

  ```{code-block}
  $ brew search unifai-admin
  ```

- Specific version installation occurs as follows:

  ```{code-block}
  $ brew install unifai-admin@0.3
  ```

````{admonition} Note
Tagged releases become available when new features reach readiness. Executing the `brew update` command updates TAPS to include these latest releases. Running a search (as indicated above) displays the updated list of available versions.```
````

## Installing UnifAI-core on Windows

TBD ...

## Configuration

UnifAI is designed to allow for installation into any Databricks environment and also to allow
multiple instances of itself within a single Databricks environment. See
[Configuration](configuration.md) for more detail.

To configure a default UnifAI profile, run the following:

```{code-block}
$ unifai-admin configure
```

A set of values for entry will appear:

```{code-block}
Databricks Host (should begin with https://)  []: <enter the databricks host here>
Databricks Token: <enter your databricks token here>
Schema Name  []: <enter a schema name to use - to allow for multiple installations in an environment>
Shared Cluster  []: <enter the name of a cluster to use if one is not specified on the command line>
Airflow Host (should begin with http://) []: <enter the airflow token here>
Airflow User []: <enter the airflow username here>
Airflow Token : <enter the airflow custom api key here>
```

Multiple profiles can be configured for specific UnifAI environments that correspond to a Databricks Workspace and an Airflow server unique to each environment. In other words, configuration of, for example, a 'dev' profile maps to a 'dev' Databricks Workspace and Airflow server. Similarly, a 'prod' profile corresponds to a 'prod' Databricks Workspace and Airflow server.

For more details on how-to configure UnifAI profiles, see [here](https://unifai-docs.optum.com/configuration/profiles.html).

## Deploying UnifAI into the Databricks Environment

After client configuration for Databricks environment access, environment bootstrapping becomes necessary for job execution within the UnifAI setting. Execute the following command to accomplish this:

```{code-block}
$ unifai-admin bootstrap <storage-location> [--wheel <custom-unifai-package> | --git <branch-or-tag>] [--restart]
```

```{admonition} Note
The `storage-location` is used to define the respective blob, file and repository storage locations.
This value should only contain alphanumeric characters and only the following two special characters - _
See the [Command Line Documentation](usage) for more details.
```

Successful installation can be validated using the following command:

```{code-block}
$ unifai-admin apps list
```

and should see the following in the output:

```{code-block}
+--------+-----------+--------------+--------+---------------+
| Name   | Version   | Repository   | Path   | Description   |
+========+===========+==============+========+===============+
+--------+-----------+--------------+--------+---------------+
```

showing that the deployment was successful, but nothing has yet been run.

## Running the `sample-app`

The UnifAI core is packaged with a sample application (see [Concepts]() for more details) that can
be used to demonstrate the UnifAI functionality. To run the app so the following

### Publishing the `sample-app` to a UnifAI environment

In order to be able to track jobs and data apps have to be registered with UnifAI. Registering an
app creates any necessary tables that the app requires and will add metadata about the various jobs
in the apps used for managing job runs and to support linage and compliance.

Installing an app can be done via the _publish_ command.

```{code-block}
$ unifai-admin apps publish https://github.com/optum-labs/unifai-core sample-app
```

### Additional publishing options

When publishing the application (as shown above), the default code source becomes the main branch. Utilizing either of the two options below permits selection of code from a specific branch or tag.

- Using a BRANCH version

  ```{code-block}
  $ unifai-admin apps publish https://github.com/optum-labs/unifai-core sample-app --branch some-feature-branch
  ```

- Using a TAG version

  ````{code-block}
  $ unifai-admin apps publish https://github.com/optum-labs/unifai-core sample-app --tag v1.5.0
  ```**
  ````

## Usage

Please see the [Command-line Reference] for details.

## Contributing

Contributions are very welcome.
To learn more, see the [Contributor Guide].

## Issues

If you encounter any problems,
please [file an issue] along with a detailed description.

<!-- github-only -->

[license]: https://github.com/optum-labs/unifai-core/blob/main/LICENSE
[contributor guide]: https://github.com/optum-labs/unifai-core/blob/main/CONTRIBUTING.md
[command-line reference]: https://fluffy-train-5f612406.pages.github.io/en/latest/usage.html
[configuration documentation]: https://github.com/optum-labs/unifai-core/blob/main/CONFIGURATION.md
[file an issue]: https://github.com/optum-labs/unifai-core/issues
