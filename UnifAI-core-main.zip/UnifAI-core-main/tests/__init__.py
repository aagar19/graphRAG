"""Test suite for the unifai_core package."""
