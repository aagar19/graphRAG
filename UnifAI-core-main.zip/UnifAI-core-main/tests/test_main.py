"""Test cases for the __main__ module."""

import json
import os

from click.testing import CliRunner
from pytest_httpserver import HTTPServer

from tests.conftest import unit_test
from unifai_core import __main__
from unifai_core.airflow.api_config import API_ENDPOINTS


CONFIGURE_INPUT = (
    "https://adb-1234567890.1.azuredatabricks.net/\ntoken\n{schema}\n{cluster}\n"
    + "http://localhost:12345/\nusername\ntoken\n"
)


@unit_test
def test_main_succeeds(runner: CliRunner, base_unifai_home) -> None:
    """It exits with a status code of zero."""
    result = runner.invoke(
        __main__.main, ["configure"], input=CONFIGURE_INPUT.format_map({"schema": "schema", "cluster": "cluster"})
    )
    assert result.exit_code == 0


@unit_test
def test_configure_no_existing_file(runner: CliRunner, base_unifai_home) -> None:
    result = runner.invoke(
        __main__.main, ["configure"], input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""})
    )

    assert result.exit_code == 0

    p = f"{base_unifai_home}/.unifai/unifai-config"
    assert os.path.exists(p)

    with open(p) as f:
        j = json.load(f)

    assert j["default"]["DATABRICKS_HOST"] == "https://adb-1234567890.1.azuredatabricks.net/"
    assert j["default"]["DATABRICKS_TOKEN"] == "token"
    assert j["default"]["SCHEMA_NAME"] == "unifai_default"
    assert j["default"]["CLUSTER_NAME"] == "unifai_default_cluster"


@unit_test
def test_configure_empty_existing_file(runner: CliRunner, base_unifai_home) -> None:
    cf = """{}"""
    p = f"{base_unifai_home}/.unifai/unifai-config"

    with open(p, "w") as f:
        f.write(cf)

    result = runner.invoke(
        __main__.main, ["configure"], input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""})
    )

    assert result.exit_code == 0
    assert os.path.exists(p)

    with open(p) as f:
        j = json.load(f)

    assert j["default"]["DATABRICKS_HOST"] == "https://adb-1234567890.1.azuredatabricks.net/"
    assert j["default"]["DATABRICKS_TOKEN"] == "token"
    assert j["default"]["SCHEMA_NAME"] == "unifai_default"
    assert j["default"]["CLUSTER_NAME"] == "unifai_default_cluster"


@unit_test
def test_configure_env_style_file(runner: CliRunner, base_unifai_home) -> None:
    cf = """{
"default": {
"DATABRICKS_HOST": "not a host",
"DATABRICKS_TOKEN": "not a token"
}
}"""
    p = f"{base_unifai_home}/.unifai/unifai-config"

    with open(p, "w") as f:
        f.write(cf)

    result = runner.invoke(
        __main__.main, ["configure"], input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""})
    )

    assert result.exit_code == 0
    assert os.path.exists(p)

    with open(p) as f:
        j = json.load(f)

    assert j["default"]["DATABRICKS_HOST"] == "https://adb-1234567890.1.azuredatabricks.net/"
    assert j["default"]["DATABRICKS_TOKEN"] == "token"
    assert j["default"]["SCHEMA_NAME"] == "unifai_default"
    assert j["default"]["CLUSTER_NAME"] == "unifai_default_cluster"


@unit_test
def test_configure_env_style_file_new_env(runner: CliRunner, base_unifai_home) -> None:
    cf = """{
"default": {
"DATABRICKS_HOST": "not a host",
"DATABRICKS_TOKEN": "not a token"
}
}"""
    p = f"{base_unifai_home}/.unifai/unifai-config"

    with open(p, "w") as f:
        f.write(cf)

    result = runner.invoke(
        __main__.main,
        ["--profile", "test", "configure"],
        input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""}),
    )

    assert result.exit_code == 0
    assert os.path.exists(p)

    with open(p) as f:
        j = json.load(f)

    assert j["default"]["DATABRICKS_HOST"] == "not a host"
    assert j["default"]["DATABRICKS_TOKEN"] == "not a token"
    assert j["test"]["DATABRICKS_HOST"] == "https://adb-1234567890.1.azuredatabricks.net/"
    assert j["test"]["DATABRICKS_TOKEN"] == "token"
    assert j["test"]["SCHEMA_NAME"] == "unifai_test"
    assert j["test"]["CLUSTER_NAME"] == "unifai_test_cluster"


@unit_test
def test_configure_env_style_file_update_other(runner: CliRunner, base_unifai_home) -> None:
    cf = """{
"default": {
"DATABRICKS_HOST": "not a host",
"DATABRICKS_TOKEN": "not a token"
},
"new": {
"DATABRICKS_HOST": "not a host",
"DATABRICKS_TOKEN": "not a token"
}
}"""
    p = f"{base_unifai_home}/.unifai/unifai-config"

    with open(p, "w") as f:
        f.write(cf)

    result = runner.invoke(
        __main__.main,
        ["--profile", "test", "configure"],
        input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""}),
    )

    assert result.exit_code == 0
    assert os.path.exists(p)

    with open(p) as f:
        j = json.load(f)

    assert j["default"]["DATABRICKS_HOST"] == "not a host"
    assert j["default"]["DATABRICKS_TOKEN"] == "not a token"
    assert j["test"]["DATABRICKS_HOST"] == "https://adb-1234567890.1.azuredatabricks.net/"
    assert j["test"]["DATABRICKS_TOKEN"] == "token"
    assert j["test"]["SCHEMA_NAME"] == "unifai_test"
    assert j["test"]["CLUSTER_NAME"] == "unifai_test_cluster"


@unit_test
def test_configure_with_schema_cluster(runner: CliRunner, base_unifai_home) -> None:
    cf = """{
"default": {
"DATABRICKS_HOST": "not a host",
"DATABRICKS_TOKEN": "not a token"
}
}"""
    p = f"{base_unifai_home}/.unifai/unifai-config"

    with open(p, "w") as f:
        f.write(cf)

    result = runner.invoke(
        __main__.main,
        ["configure"],
        input=CONFIGURE_INPUT.format_map({"schema": "test_schema", "cluster": "unifai_test_cluster"}),
    )

    assert result.exit_code == 0
    assert os.path.exists(p)

    with open(p) as f:
        j = json.load(f)

    assert j["default"]["DATABRICKS_HOST"] == "https://adb-1234567890.1.azuredatabricks.net/"
    assert j["default"]["DATABRICKS_TOKEN"] == "token"
    assert j["default"]["SCHEMA_NAME"] == "test_schema"
    assert j["default"]["CLUSTER_NAME"] == "unifai_test_cluster"


@unit_test
def test_main_help(runner: CliRunner) -> None:
    result = runner.invoke(__main__.main, ["--help"])

    assert result.exit_code == 0


@unit_test
def test_main_version(runner: CliRunner) -> None:
    result = runner.invoke(__main__.main, ["--version"])

    assert result.exit_code == 0


@unit_test
def test_main_bootstrap_help(runner: CliRunner, base_unifai_home) -> None:
    # Need to configure UnifAI as CliRunner does not setup sys.argv correctly
    result = runner.invoke(
        __main__.main, ["configure"], input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""})
    )
    assert result.exit_code == 0

    result = runner.invoke(__main__.main, ["bootstrap", "--help"])
    assert result.exit_code == 0


@unit_test
def test_main_apps_help(runner: CliRunner, base_unifai_home) -> None:
    # Need to configure UnifAI as CliRunner does not setup sys.argv correctly
    result = runner.invoke(
        __main__.main, ["configure"], input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""})
    )
    assert result.exit_code == 0

    result = runner.invoke(__main__.main, ["apps", "--help"])
    assert result.exit_code == 0


@unit_test
def test_main_jobs_help(runner: CliRunner, base_unifai_home) -> None:
    # Need to configure UnifAI as CliRunner does not setup sys.argv correctly
    result = runner.invoke(
        __main__.main, ["configure"], input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""})
    )
    assert result.exit_code == 0

    result = runner.invoke(__main__.main, ["jobs", "--help"])
    assert result.exit_code == 0


@unit_test
def test_main_dags_publish(runner: CliRunner, base_unifai_home, httpserver: HTTPServer) -> None:
    # Need to configure UnifAI as CliRunner does not setup sys.argv correctly
    result = runner.invoke(
        __main__.main, ["configure"], input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""})
    )
    assert result.exit_code == 0

    dag_file = f"{base_unifai_home}/sample-dag.py"
    with open(dag_file, "w") as f:
        f.write(
            """
from airflow import DAG
with DAG(
    dag_id = "Sample_DAG",
    schedule_interval = None,
    start_date = datetime(2022, 1, 1),
    tags = ["unifai", "data-pipeline", "daily"],
    catchup = False,
    default_args = {},
    description = f"Sample_DAG",
    params = {}
) as dag:
    # Does Nothing
"""
        )

    endpoint = API_ENDPOINTS["PUBLISH"].format_map({"AIRFLOW_HOST": "/", "DAG_ID": "unifai_falls_model"})
    httpserver.expect_request(endpoint).respond_with_json({"success": True})

    result = runner.invoke(
        __main__.main, ["dags", "publish", "-f", dag_file, "-s", "/opt/airflow/dags/unifai"], input="password\n"
    )
    assert result.exit_code == 0


@unit_test
def test_main_dags_trigger(runner: CliRunner, base_unifai_home, httpserver: HTTPServer) -> None:
    # Need to configure UnifAI as CliRunner does not setup sys.argv correctly
    result = runner.invoke(
        __main__.main, ["configure"], input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""})
    )
    assert result.exit_code == 0

    endpoint = API_ENDPOINTS["TRIGGER"].format_map({"AIRFLOW_HOST": "/", "DAG_ID": "unifai_falls_model"})
    httpserver.expect_request(endpoint).respond_with_json({"success": True})

    result = runner.invoke(
        __main__.main,
        ["dags", "trigger", "-d", "unifai_falls_model", "-c", '{"sample_config": "sample value"}'],
        input="password\n",
    )
    assert result.exit_code == 0


@unit_test
def test_main_dags_list(runner: CliRunner, base_unifai_home, httpserver: HTTPServer) -> None:
    # Need to configure UnifAI as CliRunner does not setup sys.argv correctly
    result = runner.invoke(
        __main__.main, ["configure"], input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""})
    )
    assert result.exit_code == 0

    endpoint = API_ENDPOINTS["LIST"].format_map({"AIRFLOW_HOST": "/", "DAG_ID": "unifai_falls_model"})
    httpserver.expect_request(endpoint).respond_with_json({"success": True})

    result = runner.invoke(__main__.main, ["dags", "list", "-l", "100", "-t", "unifai", "--json"], input="password\n")
    assert result.exit_code == 0


@unit_test
def test_main_dag_runs_list(runner: CliRunner, base_unifai_home, httpserver: HTTPServer) -> None:
    # Need to configure UnifAI as CliRunner does not setup sys.argv correctly
    result = runner.invoke(
        __main__.main, ["configure"], input=CONFIGURE_INPUT.format_map({"schema": "", "cluster": ""})
    )
    assert result.exit_code == 0

    endpoint = API_ENDPOINTS["LIST_RUNS"].format_map({"AIRFLOW_HOST": "/", "DAG_ID": "unifai_falls_model"})
    httpserver.expect_request(endpoint).respond_with_json({"success": True})

    result = runner.invoke(
        __main__.main, ["dags", "runs", "-d", "unifai_falls_model", "-l", "100", "--json"], input="password\n"
    )
    assert result.exit_code == 0


@unit_test
def test_main_create_template(runner: CliRunner, base_unifai_home) -> None:

    result = runner.invoke(
        __main__.main,
        [
            "template",
            "create-template",
            "-d",
            "",
            "-f",
            "",
        ],
        input="password\n",
    )
    assert result.exit_code == 0


@unit_test
def test_main_review_todos(runner: CliRunner, base_unifai_home) -> None:

    result = runner.invoke(__main__.main, ["template", "review-todos", "-a" "test"], input="password\n")
    assert result.exit_code == 0
