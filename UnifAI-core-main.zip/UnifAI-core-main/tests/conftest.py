import os
import shutil
import sys
from tempfile import mkdtemp
from typing import Generator

from _pytest.monkeypatch import MonkeyPatch
from click.testing import CliRunner
from pytest import fixture
from pytest import mark
from pytest_httpserver import HTTPServer

from unifai_core.cli.utils import _ensure_databrick_connect_config
from unifai_core.cli.utils import ensure_schema
from unifai_core.cli.utils import setup_all


MOCK_PORT = 12345


# Custom annotations
smoke_test = mark.skipif(
    os.environ.get("CI_CD_SMOKE_TESTS", "") != "TRUE", reason="tests annotated to run as smoke tests"
)
unit_test = mark.skipif(
    os.environ.get("CI_CD_SMOKE_TESTS", "") == "TRUE", reason="tests annotated to run as unit tests"
)
unit_test38 = mark.skipif(
    os.environ.get("CI_CD_SMOKE_TESTS", "") == "TRUE" or sys.version_info >= (3, 9),
    reason="python 3.8 tests annotated to run as unit tests",
)
unit_test39 = mark.skipif(
    os.environ.get("CI_CD_SMOKE_TESTS", "") == "TRUE" or sys.version_info < (3, 9),
    reason="python 3.9 tests annotated to run as unit tests",
)


# Sets up pytest to automatically skip tests that are marked slow.
# Use --run-slow to run slow tests
def pytest_addoption(parser):
    parser.addoption("--run-slow", action="store_true", default=False, help="run slow tests")


def pytest_configure(config):
    config.addinivalue_line("markers", "slow: mark test as slow to run")


def pytest_collection_modifyitems(config, items):
    if config.getoption("--run-slow"):
        # --runslow given in cli: do not skip slow tests
        return
    skip_slow = mark.skip(reason="need --run-slow option to run")
    for item in items:
        if "slow" in item.keywords:
            item.add_marker(skip_slow)


@fixture(scope="session")
def monkeypatch_session() -> Generator[MonkeyPatch, None, None]:
    """A monkeypatch fixture for session scope.

    Can be included in function scoped fixtures
    Yields:
        monkeypatch fixture shared for entire session
    """
    # Ensure the databricks-connect config file exists in the current user home
    # Without this the tests will fail
    _ensure_databrick_connect_config()

    monkeypatch = MonkeyPatch()
    monkeypatch.setenv("DATABRICKS_HOST", os.environ["CI_CD_DATABRICKS_HOST"])
    monkeypatch.setenv("DATABRICKS_TOKEN", os.environ["CI_CD_DATABRICKS_TOKEN"])

    yield monkeypatch

    monkeypatch.undo()


@fixture
def base_unifai_home(monkeypatch_session):
    temp_dir = mkdtemp()
    monkeypatch_session.setenv("HOME", temp_dir)
    monkeypatch_session.setenv("UNIFAI_HOME", f"{temp_dir}/.unifai")
    os.mkdir(f"{temp_dir}/.unifai")

    yield temp_dir

    shutil.rmtree(temp_dir)


@fixture
def httpserver() -> Generator[HTTPServer, None, None]:
    """Fixture for invoking Mock API Server."""
    with HTTPServer("localhost", MOCK_PORT) as httpserver:
        yield httpserver
    # httpserver.stop()


@fixture
def original_sys_path(monkeypatch_session):
    """Saves sys.path before any manipulation takes place."""
    sys_path_save = [p for p in sys.path]
    monkeypatch_session.setattr(sys, "path", sys_path_save)

    yield sys_path_save


@fixture
def runner() -> CliRunner:
    """Fixture for invoking command-line interfaces."""
    return CliRunner()


@fixture
def setup_db_10_4(base_unifai_home, monkeypatch, original_sys_path) -> Generator[str, None, None]:
    """Ensure that environment variables and settings is setup correctly for testing a 10.4 Databricks Cluster.

    Function scoped fixture that utilizes the session scoped DB cluster and temp directory.  By resusing the common
    temporary directory, this fixture saves time by preventing reinstall of the pyspark libraries.

    Note that this is a function scoped fixture to automatically reset monkeypatch enabling tests that require
    an independant UNIFAI_HOME

    Args:
        base_unifai_home: session scoped temp directory (used to set UNIFAI_HOME)
        monkeypatch: function scoped monkeypatch
        original_sys_path: original sys.path to used to ensure that sys.path is reset after each test

    Yields:
        Name of session scoped cluster
    """
    ensure_schema(setup_all(profile="test-run"), True)

    yield "unifai_test_run_cluster"
