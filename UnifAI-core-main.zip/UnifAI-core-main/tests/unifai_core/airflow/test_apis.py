from typing import Generator

from pytest import fixture
from pytest import raises
from pytest_httpserver import HTTPServer

from tests.conftest import unit_test
from unifai_core.airflow.api_config import API_ENDPOINTS
from unifai_core.airflow.apis import list_dag_runs
from unifai_core.airflow.apis import list_dags
from unifai_core.airflow.apis import publish_dag
from unifai_core.airflow.apis import trigger_dag
from unifai_core.cli.types import Settings
from unifai_core.cli.utils import setup_all


TEST_MODEL = "unifai_falls_model"


def get_endpoint(endpoint: str) -> str:
    path = API_ENDPOINTS[endpoint].format_map(
        {
            "AIRFLOW_HOST": "/",
            "DAG_ID": TEST_MODEL,
            "RUN_ID": "9df8b841-25fc-4917-a75b-7e4826d088f7",
        }
    )
    return path


@fixture
def api_settings(base_unifai_home, httpserver: HTTPServer) -> Generator[Settings, None, None]:
    settings = setup_all()
    settings["UNIFAI_HOME"] = base_unifai_home
    settings["AIRFLOW_HOST"] = f"http://{httpserver.host}:{httpserver.port}/"
    settings["AIRFLOW_USER"] = "dummy_user"
    settings["AIRFLOW_TOKEN"] = "dummy_token"  # noqa: S105

    yield settings


@fixture
def dag_file(base_unifai_home) -> Generator[str, None, None]:
    dag_file = f"{base_unifai_home}/sample-dag.py"
    with open(dag_file, "w") as f:
        f.write(
            """
from airflow import DAG
with DAG(
    dag_id = "Sample_DAG",
    schedule_interval = None,
    start_date = datetime(2022, 1, 1),
    tags = ["unifai", "data-pipeline", "daily"],
    catchup = False,
    default_args = {},
    description = f"Sample_DAG",
    params = {}
) as dag:
    # Does Nothing
"""
        )

    yield dag_file


@unit_test
def test_publish_dag_success(api_settings: Settings, dag_file, httpserver: HTTPServer) -> None:
    httpserver.expect_request(get_endpoint("PUBLISH"), method="POST").respond_with_json({"success": True})

    publish_dag(api_settings, "dummy_auth_token", dag_file)


@unit_test
def test_publish_dag_failure1(api_settings: Settings, dag_file) -> None:
    with raises(RuntimeError) as ex:
        publish_dag(api_settings, "dummy_auth_token", dag_file)

    assert "Airflow Publish Error" in str(ex.value)


@unit_test
def test_publish_dag_failure2(api_settings: Settings, dag_file, httpserver: HTTPServer) -> None:
    httpserver.expect_request(get_endpoint("PUBLISH"), method="POST").respond_with_data("Bad Request", status=503)

    with raises(RuntimeError) as ex:
        publish_dag(api_settings, "dummy_auth_token", dag_file)

    assert "Airflow Publish Error" in str(ex.value)


@unit_test
def test_trigger_dag_success(api_settings: Settings, httpserver: HTTPServer) -> None:
    httpserver.expect_request(get_endpoint("TRIGGER")).respond_with_json({"success": True})

    trigger_dag(api_settings, "dummy_auth_token", TEST_MODEL, '{"sample_config": "sample value"}')


@unit_test
def test_trigger_dag_failure1(api_settings: Settings) -> None:
    with raises(RuntimeError) as ex:
        trigger_dag(api_settings, "dummy_auth_token", TEST_MODEL)

    assert "Airflow Trigger Error" in str(ex.value)


@unit_test
def test_trigger_dag_failure2(api_settings: Settings, httpserver: HTTPServer) -> None:
    httpserver.expect_request(get_endpoint("TRIGGER")).respond_with_data("Bad Request", status=503)

    with raises(RuntimeError) as ex:
        trigger_dag(api_settings, "dummy_auth_token", TEST_MODEL)

    assert "Airflow Trigger Error" in str(ex.value)


@unit_test
def test_list_dags_success1(api_settings: Settings, httpserver: HTTPServer) -> None:
    httpserver.expect_request(get_endpoint("LIST")).respond_with_json({"success": True})

    list_dags(api_settings, "dummy_auth_token", json_output=True)


@unit_test
def test_list_dags_success2(api_settings: Settings, httpserver: HTTPServer) -> None:
    httpserver.expect_request(get_endpoint("LIST")).respond_with_json(
        {
            "dags": [
                {
                    "is_active": True,
                    "is_paused": False,
                    "tags": [{"name": "unifai"}],
                    "dag_id": "unifai_falls_model",
                    "fileloc": "/opt/airflow/dags/unifai/unifai_falls_model.py",
                    "last_parsed_time": "2023-04-21 16:21:12",
                }
            ]
        }
    )

    list_dags(api_settings, "dummy_auth_token", json_output=False)


@unit_test
def test_list_dags_failure1(api_settings: Settings) -> None:
    with raises(RuntimeError) as ex:
        list_dags(api_settings, "dummy_auth_token")

    assert "Airflow List Error" in str(ex.value)


@unit_test
def test_list_dags_failure2(api_settings: Settings, httpserver: HTTPServer) -> None:
    httpserver.expect_request(get_endpoint("LIST")).respond_with_data("Bad Request", status=503)

    with raises(RuntimeError) as ex:
        list_dags(api_settings, "dummy_auth_token")

    assert "Airflow List Error" in str(ex.value)


@unit_test
def test_list_dag_runs_success1(api_settings: Settings, httpserver: HTTPServer) -> None:
    httpserver.expect_request(get_endpoint("LIST_RUNS")).respond_with_json({"success": True})

    list_dag_runs(api_settings, "dummy_auth_token", TEST_MODEL, json_output=True)


@unit_test
def test_list_dag_runs_success2(api_settings: Settings, httpserver: HTTPServer) -> None:
    httpserver.expect_request(get_endpoint("LIST_RUNS")).respond_with_json(
        {
            "dag_runs": [
                {
                    "dag_id": "unifai_falls_model",
                    "dag_run_id": "run-id-20230421153456",
                    "end_date": "2023-04-21T16:21:12.123000000",
                    "start_date": "2023-04-21T15:34:56.000000000",
                    "state": "success",
                },
                {
                    "dag_id": "unifai_falls_model",
                    "dag_run_id": "run-id-20230422184902",
                    "end_date": None,
                    "start_date": "2023-04-22T18:49:02.987654321",
                    "state": "success",
                },
            ]
        }
    )

    list_dag_runs(api_settings, "dummy_auth_token", TEST_MODEL, json_output=False)


@unit_test
def test_list_dag_runs_failure1(api_settings: Settings) -> None:
    with raises(RuntimeError) as ex:
        list_dag_runs(api_settings, "dummy_auth_token", TEST_MODEL)

    assert "Airflow List-Runs Error" in str(ex.value)


@unit_test
def test_list_dag_runs_failure2(api_settings: Settings, httpserver: HTTPServer) -> None:
    httpserver.expect_request(get_endpoint("LIST_RUNS")).respond_with_data("Bad Request", status=503)

    with raises(RuntimeError) as ex:
        list_dag_runs(api_settings, "dummy_auth_token", TEST_MODEL)

    assert "Airflow List-Runs Error" in str(ex.value)
