"""Module for unifai-admin tests CLI."""
