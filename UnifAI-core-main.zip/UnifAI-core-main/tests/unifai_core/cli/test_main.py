import sys

from click.testing import CliRunner

from tests.conftest import unit_test
from unifai_core.cli.main import print_python_path


@unit_test
def test_print_python_path(monkeypatch) -> None:
    mock_sys_path = ["dummy_path1", "dummy_path2", "dummy_path3"]
    monkeypatch.setattr(sys, "path", mock_sys_path)

    runner = CliRunner()
    result = runner.invoke(print_python_path)

    assert result.exit_code == 0
    assert str(mock_sys_path) in result.output
