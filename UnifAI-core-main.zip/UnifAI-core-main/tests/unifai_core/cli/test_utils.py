import logging
import os
from random import randint

from pytest import raises

from tests.conftest import unit_test
from unifai_core.cli.utils import _set_databricks_env
from unifai_core.cli.utils import get_unifai_config
from unifai_core.cli.utils import get_unifai_home
from unifai_core.cli.utils import init_settings
from unifai_core.cli.utils import setup_all
from unifai_core.cli.utils import setup_spark_env
from unifai_core.cli.utils import validate_cluster


@unit_test
def test_get_unifai_home_env_set(base_unifai_home) -> None:
    settings = init_settings()
    assert get_unifai_home(settings) == f"{base_unifai_home}/.unifai"


@unit_test
def test_get_unifai_home_env_set_twice(base_unifai_home) -> None:
    settings = init_settings()
    assert get_unifai_home(settings) == f"{base_unifai_home}/.unifai"
    assert get_unifai_home(settings) == f"{base_unifai_home}/.unifai"


@unit_test
def test_get_unifai_home_no_env_with_home(base_unifai_home, monkeypatch) -> None:
    monkeypatch.delenv("UNIFAI_HOME")
    settings = init_settings()
    assert get_unifai_home(settings) == f"{base_unifai_home}/.unifai"


@unit_test
def test_get_unifai_home_no_env_with_home_not_set(base_unifai_home, monkeypatch) -> None:
    assert os.path.expanduser("~") == base_unifai_home
    settings = init_settings()
    assert get_unifai_home(settings) == f"{base_unifai_home}/.unifai"


@unit_test
def test_no_unifai_config(base_unifai_home, caplog, monkeypatch) -> None:
    caplog.set_level(logging.DEBUG)
    settings = init_settings()
    assert get_unifai_config(settings) == {}
    assert "not found" in caplog.text


@unit_test
def test_bad_json_unifai_config(base_unifai_home, caplog, monkeypatch) -> None:
    config_file = "<invalid json structure>"
    os.makedirs(f"{base_unifai_home}/.unifai", exist_ok=True)
    with open(f"{base_unifai_home}/.unifai/unifai-config", "w") as f:
        f.write(config_file)

    caplog.set_level(logging.DEBUG)
    settings = init_settings()
    assert get_unifai_config(settings) == {}
    assert "is not a valid json" in caplog.text


@unit_test
def test_good_json_unifai_config_with_default(base_unifai_home, caplog, monkeypatch) -> None:
    config_file = '{"default":{"databricks_host":"https://adb-12345.6.7.8","databricks_token":"blahblah"}}'
    os.makedirs(f"{base_unifai_home}/.unifai", exist_ok=True)
    with open(f"{base_unifai_home}/.unifai/unifai-config", "w") as f:
        f.write(config_file)

    caplog.set_level(logging.DEBUG)
    settings = init_settings()
    assert "databricks_host" in get_unifai_config(settings).keys()
    assert "databricks_token" in get_unifai_config(settings).keys()
    assert get_unifai_config(settings)["databricks_token"] == "blahblah"
    assert caplog.messages == []


@unit_test
def test_good_json_unifai_config_with_alt_env(base_unifai_home, caplog, monkeypatch) -> None:
    config_file = """{
"default":{"databricks_host":"https://adb-123456.7.8.9","databricks_token":"blahblah"},
"test-run":{"databricks_host":"https://adb-987654.3.2.1","databricks_token":"halbhalb"}
}"""
    os.makedirs(f"{base_unifai_home}/.unifai", exist_ok=True)
    with open(f"{base_unifai_home}/.unifai/unifai-config", "w") as f:
        f.write(config_file)

    caplog.set_level(logging.DEBUG)
    settings = init_settings("test-run")
    assert "databricks_host" in get_unifai_config(settings).keys()
    assert "databricks_token" in get_unifai_config(settings).keys()
    assert get_unifai_config(settings)["databricks_token"] == "halbhalb"
    assert caplog.messages == []


@unit_test
def test_validate_cluster_no_cluster_name() -> None:
    settings = init_settings("incorrect_settings")
    settings["DATABRICKS_HOST"] = "https://optum.com"
    settings["DATABRICKS_TOKEN"] = "not_valid"  # noqa: S105
    settings["version"] = "10.4"

    with raises(ValueError):
        validate_cluster(settings)


@unit_test
def test_validate_cluster_bad_host(monkeypatch) -> None:
    monkeypatch.setenv("DATABRICKS_HOST", "https://optum.com")
    monkeypatch.setenv("DATABRICKS_TOKEN", "not_valid")

    settings = init_settings()
    settings["DATABRICKS_HOST"] = "https://optum.com"
    settings["DATABRICKS_TOKEN"] = "not_valid"  # noqa: S105
    settings["CLUSTER_NAME"] = "test"
    settings["version"] = "10.4"

    with raises(ValueError):
        _ = validate_cluster(settings)


@unit_test
def test_validate_cluster_good_host_bad_token(monkeypatch) -> None:
    monkeypatch.setenv("DATABRICKS_HOST", os.environ["CI_CD_DATABRICKS_HOST"])
    monkeypatch.setenv("DATABRICKS_TOKEN", "bad token")

    settings = init_settings()
    settings["version"] = "10.4"

    with raises(ValueError):
        _ = validate_cluster(settings)


@unit_test
def test_validate_cluster_valid(monkeypatch) -> None:
    monkeypatch.setenv("DATABRICKS_HOST", os.environ["CI_CD_DATABRICKS_HOST"])
    monkeypatch.setenv("DATABRICKS_TOKEN", os.environ["CI_CD_DATABRICKS_TOKEN"])

    settings = init_settings("test-run")
    settings["version"] = "10.4"

    cluster = validate_cluster(settings)
    assert cluster is not None
    assert cluster["cluster_name"] == "unifai_test_run_cluster"


@unit_test
def test_validate_cluster_does_not_exist(monkeypatch) -> None:
    monkeypatch.setenv("DATABRICKS_HOST", os.environ["CI_CD_DATABRICKS_HOST"])
    monkeypatch.setenv("DATABRICKS_TOKEN", os.environ["CI_CD_DATABRICKS_TOKEN"])

    settings = init_settings()
    settings["CLUSTER_NAME"] = f"does_not_exist_{randint(100000,999999)}"
    settings["version"] = "10.4"

    with raises(ValueError):
        _ = validate_cluster(settings)


@unit_test
def test_validate_cluster_valid_twice(monkeypatch) -> None:
    monkeypatch.setenv("DATABRICKS_HOST", os.environ["CI_CD_DATABRICKS_HOST"])
    monkeypatch.setenv("DATABRICKS_TOKEN", os.environ["CI_CD_DATABRICKS_TOKEN"])

    settings = init_settings("test-run")
    settings["version"] = "10.4"

    cluster = validate_cluster(settings)
    cluster = validate_cluster(settings)
    assert cluster is not None
    assert cluster["cluster_name"] == "unifai_test_run_cluster"


@unit_test
def test_env_setup_databricks_config(base_unifai_home, monkeypatch) -> None:
    host = "host"
    token = "token"  # noqa: S105
    monkeypatch.setenv("DATABRICKS_HOST", host)
    monkeypatch.setenv("DATABRICKS_TOKEN", token)

    settings = init_settings()
    _set_databricks_env(settings)

    assert settings["DATABRICKS_HOST"] == host
    assert settings["DATABRICKS_TOKEN"] == token


@unit_test
def test_config_setup_databricks_config(base_unifai_home, caplog, monkeypatch) -> None:
    try:
        monkeypatch.delenv("DATABRICKS_HOST")
    except KeyError:
        pass
    try:
        monkeypatch.delenv("DATABRICKS_TOKEN")
    except KeyError:
        pass
    try:
        monkeypatch.delenv("SCHEMA_NAME")
    except KeyError:
        pass
    try:
        monkeypatch.delenv("CLUSTER_NAME")
    except KeyError:
        pass

    host = "https://adb-987654.3.2.1"
    token = "kasdljf"  # noqa: S105
    schema = "schema"
    cluster = "cluster"
    config_file = f"""{{
  "default": {{
    "DATABRICKS_HOST": "{host}",
    "DATABRICKS_TOKEN": "{token}",
    "SCHEMA_NAME": "{schema}",
    "CLUSTER_NAME": "{cluster}"
  }}
}}"""
    caplog.set_level(logging.DEBUG)
    with open(f"{base_unifai_home}/.unifai/unifai-config", "w") as f:
        f.write(config_file)

    settings = init_settings()
    _set_databricks_env(settings)

    assert settings["DATABRICKS_HOST"] == host
    assert settings["DATABRICKS_TOKEN"] == token
    assert settings["SCHEMA_NAME"] == schema
    assert settings["CLUSTER_NAME"] == cluster


@unit_test
def test_config_setup_databricks_no_config_no_env(base_unifai_home, caplog, monkeypatch) -> None:
    try:
        monkeypatch.delenv("DATABRICKS_HOST")
    except KeyError:
        pass
    try:
        monkeypatch.delenv("DATABRICKS_TOKEN")
    except KeyError:
        pass
    try:
        monkeypatch.delenv("SCHEMA_NAME")
    except KeyError:
        pass
    try:
        monkeypatch.delenv("CLUSTER_NAME")
    except KeyError:
        pass

    caplog.set_level(logging.DEBUG)
    settings = init_settings()
    _set_databricks_env(settings)

    assert settings["DATABRICKS_HOST"] is None
    assert settings["DATABRICKS_TOKEN"] is None
    assert settings["SCHEMA_NAME"] == "unifai_default"
    assert settings["CLUSTER_NAME"] == "unifai_default_cluster"


@unit_test
def test_config_and_env_setup_databricks_config(base_unifai_home, caplog, monkeypatch) -> None:
    config_file = """{{
  "default": {{
    "DATABRICKS_HOST": "http://adb-987654.3.2.1",
    "DATABRICKS_TOKEN": "config_token",
    "SCHEMA_NAME": "config_schema",
    "CLUSTER_NAME": "config_cluster"
  }}
}}"""
    with open(f"{base_unifai_home}/.unifai-config", "w") as f:
        f.write(config_file)

    host = "http://adb-987654.3.2.1"
    token = "env_token"  # noqa: S105
    schema = "env_schema"
    cluster = "env_cluster"
    monkeypatch.setenv("DATABRICKS_HOST", host)
    monkeypatch.setenv("DATABRICKS_TOKEN", token)
    monkeypatch.setenv("SCHEMA_NAME", schema)
    monkeypatch.setenv("CLUSTER_NAME", cluster)

    caplog.set_level(logging.DEBUG)
    settings = init_settings()
    _set_databricks_env(settings)

    assert settings["DATABRICKS_HOST"] == host
    assert settings["DATABRICKS_TOKEN"] == token
    assert settings["SCHEMA_NAME"] == schema
    assert settings["CLUSTER_NAME"] == cluster


@unit_test
def test_env_setup_databricks_config_twice(base_unifai_home, monkeypatch) -> None:
    host = "http://adb-987654.3.2.1"
    token = "env_token"  # noqa: S105
    monkeypatch.setenv("DATABRICKS_HOST", host)
    monkeypatch.setenv("DATABRICKS_TOKEN", token)

    settings = init_settings()
    _set_databricks_env(settings)
    _set_databricks_env(settings)

    assert settings["DATABRICKS_HOST"] == host
    assert settings["DATABRICKS_TOKEN"] == token


@unit_test
def test_no_vars_setup_databricks_config(base_unifai_home, caplog, monkeypatch) -> None:
    try:
        monkeypatch.delenv("DATABRICKS_HOST")
    except KeyError:
        pass
    try:
        monkeypatch.delenv("DATABRICKS_TOKEN")
    except KeyError:
        pass

    config_file = """{{
  "default": {{
    "DATABRICKS_HOST-NOT": "https://adb-987654.3.2.1",
    "DATABRICKS_TOKEN-NOT": "kasdljf"
  }}
}}"""
    with open(f"{base_unifai_home}/.unifai-config", "w") as f:
        f.write(config_file)

    caplog.set_level(logging.DEBUG)
    settings = init_settings()
    _set_databricks_env(settings)

    assert settings["DATABRICKS_HOST"] is None
    assert settings["DATABRICKS_TOKEN"] is None


@unit_test
def test_setup_spark_env_valid_default_port_cluster(base_unifai_home, monkeypatch) -> None:
    monkeypatch.setenv("DATABRICKS_HOST", os.environ["CI_CD_DATABRICKS_HOST"])
    monkeypatch.setenv("DATABRICKS_TOKEN", os.environ["CI_CD_DATABRICKS_TOKEN"])

    settings = init_settings("test-run")
    settings["version"] = "10.4"
    _set_databricks_env(settings)

    assert settings["DATABRICKS_HOST"] == os.environ["CI_CD_DATABRICKS_HOST"]

    cluster = validate_cluster(settings)
    setup_spark_env(settings)

    assert cluster is not None
    assert cluster["cluster_name"] == "unifai_test_run_cluster"
    assert settings["DATABRICKS_ORG_ID"] is not None
    assert settings["DATABRICKS_CLUSTER_ID"] == cluster["cluster_id"]
    assert settings["DATABRICKS_PORT"] == 15001


@unit_test
def test_setup_spark_env_no_cluster_no_host_default_port_cluster(base_unifai_home, monkeypatch) -> None:
    try:
        monkeypatch.delenv("DATABRICKS_HOST")
    except KeyError:
        pass

    settings = init_settings()
    settings["version"] = "10.4"
    _set_databricks_env(settings)
    setup_spark_env(settings)

    assert settings["DATABRICKS_ORG_ID"] is None
    assert settings["DATABRICKS_CLUSTER_ID"] is None
    assert settings["DATABRICKS_PORT"] is None


@unit_test
def test_setup_spark_env_bad_host_default_port_cluster(base_unifai_home, monkeypatch) -> None:
    monkeypatch.setenv("DATABRICKS_HOST", "no org id")

    settings = init_settings()
    settings["version"] = "10.4"
    _set_databricks_env(settings)

    assert settings["DATABRICKS_HOST"] == "no org id"

    with raises(KeyError):
        setup_spark_env(settings)


@unit_test
def test_setup_from_scratch_happy_path(monkeypatch, setup_db_10_4) -> None:
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()

    spark.sql("show databases").show()


@unit_test
def test_setup_from_scratch_default_version(base_unifai_home, monkeypatch, setup_db_10_4) -> None:
    from pyspark.sql import SparkSession

    setup_all(profile="test-run", upgrade=False)

    spark = SparkSession.builder.getOrCreate()
    spark.sql("show databases").show()
