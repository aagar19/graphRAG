import shutil
import tempfile
from random import randint

from pytest import fixture

from tests.conftest import unit_test
from unifai_core.data_management.create_schema_for_delta_tables import main
from unifai_core.data_management.utils import change_db
from unifai_core.data_management.utils import execute_query


@fixture()
def create_test_data(setup_db_10_4):
    """Fixture to create test data dynamically."""
    # Creating a temp db to execute test cases
    db_name = f"a{randint(100000,999999)}"  # noqa : S311
    create_qry = f"create database {db_name}"
    execute_query(create_qry)

    # Changing the new db in config
    old_db = change_db(db_name)

    # Creating temp directories
    dir_path = tempfile.mkdtemp()
    # Creating tables files
    execute_query("create table admits (col1 int, col2 string) USING DELTA")
    execute_query("create table medclaims (col1 string, col2 date) USING DELTA")
    execute_query("create table ce_table (col1 float, col2 date) USING PARQUET")
    execute_query("create table code_table (col1 int, col2 date) USING DELTA")

    yield db_name, dir_path

    # Removing the temp directories
    shutil.rmtree(dir_path)

    # Changing the db back to default in config
    change_db(old_db)

    # Dropping the database
    drop_qry = f"drop database {db_name} cascade"
    execute_query(drop_qry)


@unit_test
def test_single_table(create_test_data):
    """Function to test single table."""
    output_location = create_test_data[1]
    assert main(["admits"], output_location) is True


@unit_test
def test_multiple_tables(create_test_data):
    """Function to test multiple tables."""
    output_location = create_test_data[1]
    assert main(["admits", "medclaims", "ce_table", "code_table"], output_location) is True


@unit_test
def test_empty_list(create_test_data):
    """Function to test empty argument tables."""
    output_location = create_test_data[1]
    assert main([], output_location) is True


@unit_test
def test_table_not_exist(create_test_data):
    """Function to test if table doesn't exist."""
    output_location = create_test_data[1]
    assert main(["member_attrib"], output_location) is False


@unit_test
def test_output_dir_not_exist(create_test_data):
    """Function to test if output directory doesn't exist."""
    assert main(["medclaims", "admits"], "test") is False
