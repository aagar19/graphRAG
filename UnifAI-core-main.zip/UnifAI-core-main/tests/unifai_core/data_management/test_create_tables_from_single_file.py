import os.path
import shutil
import tempfile
from random import randint

from pytest import fixture

from tests.conftest import unit_test
from unifai_core.data_management.create_tables_from_single_file import (
    main as create_tables_from_single_file,
)
from unifai_core.data_management.utils import change_db
from unifai_core.data_management.utils import execute_query
from unifai_core.data_management.utils import generate_create_sql_template


@fixture()
def create_test_data(setup_db_10_4):
    """Fixture to create test data dynamically."""
    from pyspark.dbutils import DBUtils  # type: ignore
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    dbutils = DBUtils(spark)

    # Creating a temp db to execute test cases
    db_name = f"a{randint(100000,999999)}"  # noqa: S311
    create_qry = f"create database {db_name}"
    execute_query(create_qry)

    # Changing the new db in config
    old_db = change_db(db_name)

    # Creating temp directories
    dir_path = tempfile.mkdtemp()
    location = f"dbfs:/mnt/azureblobshare/code/data_management_tests/location_{randint(100000,999999)}"  # noqa: S311
    dbutils.fs.mkdirs(location)

    yield dir_path, db_name, location

    # Removing the temp directories
    shutil.rmtree(dir_path)
    dbutils.fs.rm(location, recurse=True)

    # Changing the db back to default in config
    change_db(old_db)

    # Dropping the database
    drop_qry = f"drop database {db_name} cascade"
    execute_query(drop_qry)


@unit_test
def test_single_sql(create_test_data):
    """Function to test for a single sql without ;."""
    sql = generate_create_sql_template("admits", "cifddfc")
    file_path = os.path.join(create_test_data[0], "single.sql")
    location = create_test_data[2]
    with open(file_path, "w") as f:
        f.write(sql)
    assert create_tables_from_single_file(file_path, location) is True


@unit_test
def test_multiple_sql(create_test_data):
    """Function to test for multiple sql where last sql does not end with ;."""
    sql_1 = generate_create_sql_template("ce_table", "difcffc")
    sql_2 = generate_create_sql_template("code_table", "cifdficd")
    sql_3 = generate_create_sql_template("medclaims", "cfdifcdfi")
    location = create_test_data[2]
    combined_query = ";".join([sql_1, sql_2, sql_3])
    file_path = os.path.join(create_test_data[0], "multiple.sql")
    with open(file_path, "w") as f:
        f.write(combined_query)
    assert create_tables_from_single_file(file_path, location) is True


@unit_test
def test_multiple_sql_with_semicolon_in_last(create_test_data):
    """Function to test for multiple sql where last sql does end with ;."""
    sql_1 = generate_create_sql_template("admits", "difcffc")
    sql_2 = generate_create_sql_template("obsstays", "cifdficd")
    sql_3 = generate_create_sql_template("member_attrib", "cfdifcdfi")
    location = create_test_data[2]
    combined_query = ";".join([sql_1, sql_2, sql_3])
    combined_query += ";"
    file_path = os.path.join(create_test_data[0], "multiple_with_semi_colon.sql")
    with open(file_path, "w") as f:
        f.write(combined_query)
    assert create_tables_from_single_file(file_path, location) is True


@unit_test
def test_continue_on_failure_flag_false(create_test_data):
    """Function to test continue on failure flag when it's False."""
    sql_1 = generate_create_sql_template("admits", "difcffc")
    sql_2 = generate_create_sql_template("admits", "cifdficd")
    location = create_test_data[2]
    combined_query = ";".join([sql_1, sql_2])
    file_path = os.path.join(create_test_data[0], "continue_on_failure_false.sql")
    with open(file_path, "w") as f:
        f.write(combined_query)
    assert create_tables_from_single_file(file_path, location, if_not_exist_flag=False) is False


@unit_test
def test_continue_on_failure_flag_true(create_test_data):
    """Function to test continue on failure flag when it's True."""
    sql_1 = generate_create_sql_template("admits", "difcffc")
    sql_2 = generate_create_sql_template("ce_table", "cifdficd")
    location = create_test_data[2]
    combined_query = ";".join([sql_1, sql_2])
    file_path = os.path.join(create_test_data[0], "continue_on_failure_true.sql")
    with open(file_path, "w") as f:
        f.write(combined_query)
    assert (
        create_tables_from_single_file(file_path, location, if_not_exist_flag=False, continue_on_failure=True) is True
    )
