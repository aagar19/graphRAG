import os.path
from random import randint

from pytest import fixture

from tests.conftest import unit_test
from unifai_core.data_management.create_tables import main as create_tables
from unifai_core.data_management.utils import change_db
from unifai_core.data_management.utils import execute_query
from unifai_core.data_management.utils import generate_create_sql_template


@fixture()
def create_test_data(setup_db_10_4):
    """Fixture to create test data dynamically."""
    from pyspark.dbutils import DBUtils  # type: ignore
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    dbutils = DBUtils(spark)

    # Creating a temp db to execute test cases
    db_name = f"a{randint(100000,999999)}"  # noqa: S311
    create_qry = f"create database {db_name}"
    execute_query(create_qry)

    # Changing the new db in config
    old_db = change_db(db_name)

    # Creating temp directories
    dir_path_1 = f"dbfs:/mnt/azureblobshare/code/data_management_tests/directory_{randint(100000,999999)}"  # noqa: S311
    dbutils.fs.mkdirs(dir_path_1)
    dir_path_2 = f"dbfs:/mnt/azureblobshare/code/data_management_tests/directory_{randint(100000,999999)}"  # noqa: S311
    dbutils.fs.mkdirs(dir_path_2)
    location = f"dbfs:/mnt/azureblobshare/code/data_management_tests/location_{randint(100000,999999)}"  # noqa: S311
    dbutils.fs.mkdirs(location)

    # Creating sql files

    sql_1 = generate_create_sql_template("admits", "cidfcidf", seed=12)
    dbutils.fs.put(os.path.join(dir_path_1, "1.sql"), sql_1)

    sql_2 = generate_create_sql_template("medclaims", "cfdifdfc")
    dbutils.fs.put(os.path.join(dir_path_1, "2.sql"), sql_2)

    sql_3 = generate_create_sql_template("er_uc", "cfdifcfd")
    dbutils.fs.put(os.path.join(dir_path_1, "3.sql"), sql_3)

    sql_4 = generate_create_sql_template("member_attrib", "cfdifcd", seed=10)
    dbutils.fs.put(os.path.join(dir_path_2, "4.sql"), sql_4)

    sql_5 = generate_create_sql_template("member_attrib", "cfdifcd", seed=10)
    dbutils.fs.put(os.path.join(dir_path_2, "5.sql"), sql_5)

    yield dir_path_1, dir_path_2, db_name, location

    # Removing the temp directories
    dbutils.fs.rm(dir_path_1, recurse=True)
    dbutils.fs.rm(dir_path_2, recurse=True)
    dbutils.fs.rm(location, recurse=True)

    # Changing the db back to default in config
    change_db(old_db)

    # Dropping the database
    drop_qry = f"drop database {db_name} cascade"
    execute_query(drop_qry)


@unit_test
def test_generate_tables(create_test_data):
    dir_path_1 = create_test_data[0]
    location = create_test_data[3]
    assert create_tables(dir_path_1, location, if_not_exist_flag=True) is True


@unit_test
def test_generate_tables_fail(create_test_data):
    dir_path_2 = create_test_data[1]
    location = create_test_data[3]
    assert create_tables(dir_path_2, location, if_not_exist_flag=False) is False
