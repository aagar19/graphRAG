import os.path
from random import randint

from pytest import fixture

from tests.conftest import unit_test
from unifai_core.data_management.create_table_against_existing_path import (
    main as create_table_against_existing_path,
)
from unifai_core.data_management.utils import change_db
from unifai_core.data_management.utils import execute_query
from unifai_core.data_management.utils import generate_sample_dataframe


@fixture()
def create_test_data(setup_db_10_4):
    """Fixture to create test data dynamically."""
    from pyspark.dbutils import DBUtils  # type: ignore
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    dbutils = DBUtils(spark)

    # Creating a temp db to execute test cases
    db_name = f"a{randint(100000,999999)}"  # noqa: S311
    create_qry = f"create database {db_name}"
    execute_query(create_qry)

    # Changing the new db in config
    old_db = change_db(db_name)

    # Creating temp directories
    location = f"dbfs:/mnt/azureblobshare/code/data_management_tests/location_{randint(100000,999999)}"  # noqa: S311
    dbutils.fs.mkdirs(location)

    df = generate_sample_dataframe(size=1000, cols="cifdcff", seed=10)
    spark_df = spark.createDataFrame(df)
    spark_df.write.parquet(os.path.join(location, "test_1"))
    spark_df.write.parquet(os.path.join(location, "test_2.parquet"))
    spark_df.write.csv(os.path.join(location, "test_3"))
    spark_df.write.csv(os.path.join(location, "test_4.csv"))
    dbutils.fs.mkdirs(os.path.join(location, "test_5"))

    df1 = generate_sample_dataframe(size=500, cols="ciffcdff", seed=10)
    spark_df1 = spark.createDataFrame(df1)
    spark_df1.write.parquet(os.path.join(location, "test_6"))

    yield db_name, location

    # Removing the temp directories
    dbutils.fs.rm(location, recurse=True)

    # Changing the db back to default in config
    change_db(old_db)

    # Dropping the database
    drop_qry = f"drop database {db_name} cascade"
    execute_query(drop_qry)


@unit_test
def test_parquet_with_metadata(create_test_data):
    """Function to test for a parquet file with metadata."""
    location = create_test_data[1]
    assert create_table_against_existing_path(os.path.join(location, "test_1"), "test_1") is not False


@unit_test
def test_parquet(create_test_data):
    """Function to test for a parquet file without metadata."""
    location = create_test_data[1]
    assert create_table_against_existing_path(os.path.join(location, "test_2.parquet"), "test_2") is not False


@unit_test
def test_csv_with_metadata(create_test_data):
    """Function to test for a csv file with metadata."""
    location = create_test_data[1]
    assert create_table_against_existing_path(os.path.join(location, "test_3"), "test_3") is False


@unit_test
def test_csv(create_test_data):
    """Function to test for a csv file without metadata."""
    location = create_test_data[1]
    assert create_table_against_existing_path(os.path.join(location, "test_4.csv"), "test_4") is False


@unit_test
def test_empty_dir(create_test_data):
    """Function to test for a empty directory."""
    location = create_test_data[1]
    assert create_table_against_existing_path(os.path.join(location, "test_5"), "test_5") is False


@unit_test
def test_table_exist_already(create_test_data):
    """Function to test if table exist already."""
    location = create_test_data[1]
    create_table_against_existing_path(os.path.join(location, "test_6"), "test_6")
    assert create_table_against_existing_path(os.path.join(location, "test_6"), "test_6") is False
