"""Module for data-management scripts tests."""
