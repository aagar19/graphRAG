import os.path
from random import randint

from pytest import fixture

from tests.conftest import unit_test
from unifai_core.data_management.drop_tables import main as drop_tables
from unifai_core.data_management.utils import change_db
from unifai_core.data_management.utils import execute_query
from unifai_core.data_management.utils import generate_drop_sql_template


@fixture()
def create_test_data(setup_db_10_4):
    """Fixture to create test data dynamically."""
    from pyspark.dbutils import DBUtils  # type: ignore
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    dbutils = DBUtils(spark)

    # Creating a temp db to execute test cases
    db_name = f"a{randint(100000,999999)}"  # noqa : S311
    create_qry = f"create database {db_name}"
    execute_query(create_qry)

    # Changing the new db in config
    old_db = change_db(db_name)

    # Creating temp directories
    dir_path_1 = (
        f"dbfs:/mnt/azureblobshare/data_management_tests/drop_sql/directory_{randint(100000,999999)}"  # noqa: S311
    )
    dbutils.fs.mkdirs(dir_path_1)
    dir_path_2 = (
        f"dbfs:/mnt/azureblobshare/data_management_tests/drop_sql/directory_{randint(100000,999999)}"  # noqa: S311
    )
    dbutils.fs.mkdirs(dir_path_2)

    # Creating tables files
    execute_query("create table admits (col1 int, col2 string) USING DELTA")
    execute_query("create table medclaims (col1 string, col2 date) USING DELTA")
    execute_query("create table ce_table (col1 float, col2 date) USING PARQUET")
    execute_query("create table code_table (col1 int, col2 date) USING DELTA")

    # Generating Drop Query Templates
    sql_1 = generate_drop_sql_template("admits")
    dbutils.fs.put(os.path.join(dir_path_1, "1.sql"), sql_1)

    sql_2 = generate_drop_sql_template("medclaims")
    dbutils.fs.put(os.path.join(dir_path_1, "2.sql"), sql_2)

    sql_3 = generate_drop_sql_template("ce_table")
    dbutils.fs.put(os.path.join(dir_path_1, "3.sql"), sql_3)

    sql_4 = generate_drop_sql_template("code_table")
    dbutils.fs.put(os.path.join(dir_path_1, "4.sql"), sql_4)

    sql_5 = generate_drop_sql_template("elig_risk")
    dbutils.fs.put(os.path.join(dir_path_2, "5.sql"), sql_5)

    yield dir_path_1, dir_path_2, db_name

    # Removing the temp directories
    dbutils.fs.rm(dir_path_1, recurse=True)
    dbutils.fs.rm(dir_path_2, recurse=True)

    # Changing the db back to default in config
    change_db(old_db)

    # Dropping the database
    drop_qry = f"drop database {db_name} cascade"
    execute_query(drop_qry)


@unit_test
def test_drop_tables(create_test_data):
    """Function to test generate tables, eg test case is a directory."""
    dir_path_1 = create_test_data[0]
    assert drop_tables(dir_path_1, if_exist_flag=True) is True


@unit_test
def test_drop_tables_second(create_test_data):
    """Function for false test cases."""
    dir_path_2 = create_test_data[1]
    assert drop_tables(dir_path_2, if_exist_flag=False) is False
