import json
import os
from random import randint

from pytest import fixture

from tests.conftest import unit_test
from unifai_core.data_management.generate_ddl import create_table_ddl
from unifai_core.data_management.utils import generate_sample_dataframe
from unifai_core.data_management.utils import generate_sample_hierarchical_data


test_dir = os.path.dirname(os.path.abspath(__file__))
test_case_path = os.path.join(test_dir, "test_cases.json")


@fixture()
def create_sample_parquet_file(setup_db_10_4):
    """Fixture to create test data dynamically."""
    from pyspark.dbutils import DBUtils  # type: ignore
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    dbutils = DBUtils(spark)

    dirpath = f"dbfs:/mnt/azureblobshare/data_management_tests/generate_ddl_{randint(100000,999999)}"  # noqa: S311
    dbutils.fs.mkdirs(dirpath)
    df1 = generate_sample_dataframe(size=1000, cols="cifdcff", seed=10)
    df1 = spark.createDataFrame(df1)
    df1.write.parquet(os.path.join(dirpath, "table_1.parquet"))
    df2 = generate_sample_dataframe(size=2000, cols="dficddc", seed=10)
    df2 = spark.createDataFrame(df2)
    df2.write.parquet(os.path.join(dirpath, "table_2.parquet"))
    df3 = generate_sample_dataframe(size=5000, cols="cifdcifd", seed=10)
    df3 = spark.createDataFrame(df3)
    df3.write.parquet(os.path.join(dirpath, "table_3.parquet"))
    df4 = generate_sample_hierarchical_data()
    df4 = spark.createDataFrame(df4)
    df4.write.parquet(os.path.join(dirpath, "table_4.parquet"))

    yield dirpath

    dbutils.fs.rm(dirpath, recurse=True)


def pytest_generate_tests(metafunc):
    """Test Cases will be a list of test cases (Input dict of params, Output String)."""
    with open(test_case_path) as f:
        test_cases = json.load(f)
    fct_name = metafunc.function.__name__
    if fct_name in test_cases:
        params = test_cases[fct_name]
        metafunc.parametrize("test_case", params)


@unit_test
def test_create_table_ddl(test_case, create_sample_parquet_file):
    params = test_case["input"]
    params["data_path"] = os.path.join(create_sample_parquet_file, params["data_path"])
    output = test_case["output"]
    function_output = create_table_ddl(**params)[1]
    assert output == function_output


@unit_test
def test_create_table_ddl_fail(test_case, create_sample_parquet_file):
    params = test_case["input"]
    params["data_path"] = os.path.join(create_sample_parquet_file, params["data_path"])
    output = test_case["output"]
    flag, function_output = create_table_ddl(**params)
    assert (flag is False) or (function_output != output)
