from pytest import raises

from tests.conftest import unit_test
from unifai_core.schema.utils import UpdateSchemaStatements


@unit_test
def test_yaml_to_create_basic(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/schema.yaml", "w") as f:
        f.write(
            """
a:
    - b: c
"""
        )

    tables = UpdateSchemaStatements(f"{base_unifai_home}/schema.yaml", "/location", "test", "10.4")
    assert len(tables) == 1

    name, sql = tables[0]
    assert name == "a"
    assert "".join(sql[1].split()) == "CREATETABLEunifai_test_run.a(`b`C)USINGDELTALOCATION'/location/a'"


@unit_test
def test_yaml_to_create_two_tables(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/schema.yaml", "w") as f:
        f.write(
            """
a:
    - b: c
d:
    - e: f
"""
        )

    tables = UpdateSchemaStatements(f"{base_unifai_home}/schema.yaml", "/location", "test", "10.4")
    assert len(tables) == 2

    name, sql = tables[0]
    assert name == "a"
    assert "".join(sql[1].split()) == "CREATETABLEunifai_test_run.a(`b`C)USINGDELTALOCATION'/location/a'"

    name, sql = tables[1]
    assert name == "d"
    assert "".join(sql[1].split()) == "CREATETABLEunifai_test_run.d(`e`F)USINGDELTALOCATION'/location/d'"


@unit_test
def test_yaml_to_create_nullable_field(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/schema.yaml", "w") as f:
        f.write(
            """
a:
    - b:
        data_type: c
        not_null: false
        comment: 'd'
"""
        )

    tables = UpdateSchemaStatements(f"{base_unifai_home}/schema.yaml", "/location", "test", "10.4")
    assert len(tables) == 1

    name, sql = tables[0]
    assert name == "a"
    assert "".join(sql[1].split()) == "CREATETABLEunifai_test_run.a(`b`CCOMMENT'd')USINGDELTALOCATION'/location/a'"


@unit_test
def test_yaml_to_create_auto_increment_field(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/schema.yaml", "w") as f:
        f.write(
            """
a:
    - b:
        data_type: c
        auto_increment: true
"""
        )

    tables = UpdateSchemaStatements(f"{base_unifai_home}/schema.yaml", "/location", "test", "10.4")
    assert len(tables) == 1

    name, sql = tables[0]
    assert name == "a"
    assert (
        "".join(sql[1].split()) == "CREATETABLEunifai_test_run.a(`b`BIGINTNOTNULLGENERATEDBYDEFAULTASIDENTITY"
        "(STARTWITH1001INCREMENTBY1))USINGDELTALOCATION'/location/a'"
    )


@unit_test
def test_yaml_to_create_not_nullable_field_long_form(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/schema.yaml", "w") as f:
        f.write(
            """
a:
    - b:
        data_type: c
        not_null: true
"""
        )

    tables = UpdateSchemaStatements(f"{base_unifai_home}/schema.yaml", "/location", "test", "10.4")
    assert len(tables) == 1

    name, sql = tables[0]
    assert name == "a"
    assert "".join(sql[1].split()) == "CREATETABLEunifai_test_run.a(`b`CNOTNULL)USINGDELTALOCATION'/location/a'"


@unit_test
def test_yaml_to_create_multiple_nullable_field(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/schema.yaml", "w") as f:
        f.write(
            """
a:
    - b:
        data_type: c
        not_null: true
    - d: e
"""
        )

    tables = UpdateSchemaStatements(f"{base_unifai_home}/schema.yaml", "/location", "test", "10.4")
    assert len(tables) == 1

    name, sql = tables[0]
    assert name == "a"
    assert "".join(sql[1].split()) == "CREATETABLEunifai_test_run.a(`b`CNOTNULL,`d`E)USINGDELTALOCATION'/location/a'"


@unit_test
def test_yaml_to_create_non_dict_yaml(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/schema.yaml", "w") as f:
        f.write(
            """
- a
- b
"""
        )

    with raises(AttributeError) as exc:
        _ = UpdateSchemaStatements(f"{base_unifai_home}/schema.yaml", "/location", "test", "10.4")

    assert "'list' object has no attribute 'items'" in str(exc.value)


@unit_test
def test_yaml_to_create_non_list_fields(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/schema.yaml", "w") as f:
        f.write(
            """
a:
    b: c
    d: e
"""
        )

    with raises(KeyError) as exc:
        _ = UpdateSchemaStatements(f"{base_unifai_home}/schema.yaml", "/location", "test", "10.4")

    assert "'columns'" in str(exc.value)


@unit_test
def test_yaml_to_create_fields_not_dict(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/schema.yaml", "w") as f:
        f.write(
            """
a:
    - a
    - b
"""
        )

    with raises(AttributeError) as exc:
        _ = UpdateSchemaStatements(f"{base_unifai_home}/schema.yaml", "/location", "test", "10.4")

    assert "'str' object has no attribute 'keys'" in str(exc.value)


@unit_test
def test_yaml_to_create_field_not_dict(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/schema.yaml", "w") as f:
        f.write(
            """
a:
    b
"""
        )

    with raises(RuntimeError) as exc:
        _ = UpdateSchemaStatements(f"{base_unifai_home}/schema.yaml", "/location", "test", "10.4")

    assert "Unsupported schema format" in str(exc.value)
