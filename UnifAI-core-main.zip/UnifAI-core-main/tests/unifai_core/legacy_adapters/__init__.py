"""Module for unifai-admin tests LEGACY-ADAPTERS."""
