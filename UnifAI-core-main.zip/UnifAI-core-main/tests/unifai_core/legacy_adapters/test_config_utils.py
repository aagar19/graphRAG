import pytest
import yaml

from tests.conftest import unit_test
from unifai_core.legacy_adapters.config_utils import replace_templates


@pytest.fixture(scope="session")
def config_template():
    with open("tests/configs/config_template.yaml") as f:
        yield yaml.safe_load(f)


@unit_test
def test_replace_templates(config_template):
    result = replace_templates(config_template, CDO_LIST="'1','2','3'", RUN_DATE="2023-01-01")
    assert result["cdo_list"] == "'1','2','3'"
    assert result["pred_date"] == "2023-01-01"


@unit_test
def test_replace_templates_with_non_string(config_template):
    result = replace_templates(config_template, CDO_LIST=[], RUN_DATE=True)
    assert result["cdo_list"] == []
    assert result["pred_date"] is True
