from uuid import uuid4

import pytest
import yaml
from pandas.core.frame import DataFrame as PandasDataFrame
from pyspark.sql.dataframe import DataFrame

from tests.conftest import unit_test
from unifai_core.app.conf import ApplicationConfiguration
from unifai_core.app.conf import JobConfiguration
from unifai_core.jobs.legacy_adapter import UnifaiLegacyAdapterJob
from unifai_core.legacy_adapters.path_adapter import DataIO


class MockDataFrame:
    """Mock data-frame."""

    def __init__(self, output=None):
        """Mock constructor."""
        self.__output = output
        self.read = self

    def count(self, *args, **kwargs):
        """Mock count."""
        return len(self.__output)

    def drop(self, *args, **kwargs):
        """Mock drop."""
        return self

    def toPandas(self, *args, **kwargs):  # noqa: N802
        """Mock csv."""
        return self


class MockSpark:
    """Mock spark."""

    def __init__(self, output=None):
        """Mock constructor."""
        self.__output = output
        self.catalog = self
        self.read = self

    def currentDatabase(self):  # noqa: N802
        """Mock options."""
        return self

    def csv(self, *args, **kwargs):
        """Mock csv."""
        return MockDataFrame(self.__output)

    def parquet(self, *args, **kwargs):
        """Mock parquet."""
        return MockDataFrame(self.__output)

    def load(self, *args, **kwargs):
        """Mock load."""
        return MockDataFrame(self.__output)

    def format(self, *args, **kwargs):
        """Mock format."""
        return self

    def options(self, *args, **kwargs):
        """Mock options."""
        return self

    def sql(self, *args, **kwargs):
        """Mock sql."""
        return self

    def write(self, *args, **kwargs):
        """Mock write."""
        return MockDataFrame(self.__output)


class MockJob(UnifaiLegacyAdapterJob):
    """Mock job."""

    def __init__(self, spark, job, table_mappings, output=None):
        """Mock constructor."""
        self.__output = output
        super().__init__(spark, job, table_mappings)

    def load_table(self, spark, tablename: str):
        """Mock load_table."""
        return MockDataFrame(self.__output)

    def write_table(
        self, spark, df: DataFrame, tablename: str, mode: str = "overwrite", update_to_match_schema: bool = False
    ):
        """Mock write_table."""
        pass


def get_job(spark, table_mappings, output=None):
    job = JobConfiguration(
        application=ApplicationConfiguration(
            app_path="src/unifai_core_app",
            additional_config={},
            merge_config=True,
        ),
        job_name="mock_job",
        orchestration_id=str(uuid4()),
    )
    job.start_job("1234567890", "54321", "http://localhost:8080/", use_unifai=False)
    return MockJob(
        spark=spark,
        job=job,
        table_mappings=table_mappings,
        output=output,
    )


def get_dataio(table_mappings, output=None):
    spark = MockSpark(output)
    return DataIO(spark, table_mappings, get_job(spark, table_mappings, output))


@pytest.fixture(scope="session")
def table_mappings():
    with open("tests/configs/path_to_table_mapping.yaml") as f:
        yield yaml.safe_load(f)


@unit_test
def test_infer_filetype(table_mappings):
    dataio = get_dataio(table_mappings, None)
    assert "csv" == dataio.infer_filetype("tests/fixtures/planets.csv")
    assert "parquet" == dataio.infer_filetype("tests/fixtures/planets.parquet")
    assert "excel" == dataio.infer_filetype("tests/fixtures/planets.xls")
    assert "table" == dataio.infer_filetype("schema.table")
    # bad file reference
    failed = False
    try:
        dataio.infer_filetype("tests/fixtures/planets.bad")
    except ValueError:
        failed = True
    assert failed is True


@unit_test
def test_pandas_csv_read(table_mappings):
    dataio = get_dataio(table_mappings, None)
    fixture_df = dataio.read_csv("tests/fixtures/planets.csv")
    assert isinstance(fixture_df, PandasDataFrame)
    assert fixture_df.shape == (8, 2)


@unit_test
def test_pandas_parquet_read(table_mappings):
    dataio = get_dataio(table_mappings, None)
    fixture_df = dataio.read_parquet("tests/fixtures/planets.parquet")
    assert isinstance(fixture_df, PandasDataFrame)
    assert fixture_df.shape == (8, 2)


@unit_test
def test_spark_csv_read(table_mappings):
    sample_data = ["{x}" for x in range(1, 9)]
    dataio = get_dataio(table_mappings, sample_data)
    fixture_df = dataio.read.csv("tests/fixtures/planets.csv")
    assert isinstance(fixture_df, MockDataFrame)
    assert fixture_df.count() == 8


@unit_test
def test_spark_parquet_read(table_mappings):
    sample_data = ["{x}" for x in range(1, 9)]
    dataio = get_dataio(table_mappings, sample_data)
    fixture_df = dataio.read.parquet("tests/fixtures/planets.parquet")
    assert isinstance(fixture_df, MockDataFrame)
    assert fixture_df.count() == 8


@unit_test
def test_spark_table_read(table_mappings):
    sample_data = ["{x}" for x in range(1, 9)]
    dataio = get_dataio(table_mappings, sample_data)
    fixture_df = dataio.read.csv("tests/fixtures/features.csv")
    assert isinstance(fixture_df, MockDataFrame)
    assert fixture_df.count() == 8


@unit_test
def test_pandas_csv_write(mocker, table_mappings):
    dataio = get_dataio(table_mappings)
    fixture_df = dataio.read_csv("tests/fixtures/planets.csv")
    m = mocker.patch("pandas.core.frame.DataFrame.to_csv")
    dataio(fixture_df).to_csv("/dev/null")
    m.assert_called_once_with("/dev/null")


@unit_test
def test_job_get_data_adapter(table_mappings):
    sample_data = ["{x}" for x in range(1, 9)]
    job = get_job(MockSpark(sample_data), table_mappings, sample_data)
    dataio = job.data_adapter(input_schema="testing")
    assert isinstance(dataio, DataIO)
