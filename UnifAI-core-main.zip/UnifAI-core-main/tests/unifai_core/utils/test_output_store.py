"""Tests for unifai_core.utils."""

import pytest
from pyspark.sql import Row
from pyspark.sql.types import StringType
from pyspark.sql.types import StructField
from pyspark.sql.types import StructType

from tests.conftest import unit_test
from unifai_core.utils.output_store import _data_link_dynamic_split
from unifai_core.utils.output_store import _data_link_static_split
from unifai_core.utils.output_store import format_data
from unifai_core.utils.output_store import get_original_dtypes
from unifai_core.utils.output_store import pivot_columns
from unifai_core.utils.output_store import select_columns


@pytest.fixture()
def spark_session(setup_db_10_4):
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    yield spark
    spark.stop()


@unit_test
def test_data_link_dynamic_split(spark_session):
    # Create test DataFrame
    data = [Row(data_link_value="value1|value2", data_link_type="type1|type2")]
    df = spark_session.createDataFrame(data)

    # Test the function
    result_df = _data_link_dynamic_split(df, ["type1|type2"])
    result = result_df.collect()[0]

    assert result.type1 == "value1"
    assert result.type2 == "value2"


@unit_test
def test_data_link_static_split(spark_session):
    # Create test DataFrame
    data = [Row(data_link_value="value1|value2", data_link_type="type1|type2")]
    df = spark_session.createDataFrame(data)

    # Test the function
    result_df = _data_link_static_split(df, "type1|type2")
    result = result_df.collect()[0]

    assert result.type1 == "value1"
    assert result.type2 == "value2"


@unit_test
def test_get_original_dtypes(spark_session):
    # Create test DataFrame
    data = [Row(calculation_name="calc1", calculation_datatype="float")]
    df = spark_session.createDataFrame(data)

    # Test the function
    result = get_original_dtypes(df)

    assert result == {"calc1": "float"}


@unit_test
def test_pivot_columns(spark_session):
    # Create a DataFrame with some sample data
    data = [
        Row(id=1, group="A", calculation_name="calc1", calculation_datatype="float", calculation_value=str(1.0)),
        Row(id=1, group="A", calculation_name="calc2", calculation_datatype="int", calculation_value=str(2)),
        Row(id=2, group="B", calculation_name="calc1", calculation_datatype="float", calculation_value=str(3.0)),
        Row(id=2, group="B", calculation_name="calc2", calculation_datatype="int", calculation_value=str(4)),
    ]
    df = spark_session.createDataFrame(data)

    # Call the function
    target_columns = ["calc1", "calc2"]
    result_df = pivot_columns(df, target_columns)

    # Validate the output DataFrame structure
    expected_columns = ["id", "group", "calc1", "calc2"]
    assert result_df.columns == expected_columns

    # Validate the data in the DataFrame
    result_data = [(row.id, row.group, row.calc1, row.calc2) for row in result_df.collect()]
    expected_data = [(1, "A", 1.0, 2), (2, "B", 3.0, 4)]
    assert result_data == expected_data

    # Validate the data types
    original_dtypes = get_original_dtypes(df)
    for col_name, dtype in original_dtypes.items():
        assert dtype == str(dict(result_df.dtypes)[col_name])


@unit_test
def test_select_columns(spark_session):
    # Creating a DataFrame with some extra columns
    data = [
        Row(
            calculation_name="calc1",
            calculation_datatype="float",
            calculation_value=str(1.0),
            data_link_type="type1",
            data_link_value="value1",
            extra_col1="extra1",
            extra_col2="extra2",
        )
    ]
    df = spark_session.createDataFrame(data)

    # Dictionary of extra columns to include with SQL expressions
    extra_columns = {"extra_col1": "extra_col1", "extra_col2": "extra_col2"}

    # Call the function
    result_df = select_columns(df, extra_columns)

    # Check that the DataFrame has the expected columns
    expected_columns = [
        "calculation_name",
        "calculation_datatype",
        "calculation_value",
        "data_link_type",
        "data_link_value",
        "extra_col1",
        "extra_col2",
    ]
    assert result_df.columns == expected_columns

    # Check that the values in the DataFrame are as expected
    result_row = result_df.collect()[0]
    assert result_row.calculation_name == "calc1"
    assert result_row.calculation_datatype == "float"
    assert result_row.calculation_value == str(1.0)
    assert result_row.data_link_type == "type1"
    assert result_row.data_link_value == "value1"
    assert result_row.extra_col1 == "extra1"
    assert result_row.extra_col2 == "extra2"


#
@unit_test
def test_format_data(spark_session):
    # Create a schema for the test DataFrame
    schema = StructType(
        [
            StructField("calculation_name", StringType(), True),
            StructField("calculation_value", StringType(), True),
            StructField("data_link_type", StringType(), True),
            StructField("data_link_value", StringType(), True),
        ]
    )

    # Create a test DataFrame with some sample data
    data = [("calc1", "value1", "type1", "link1"), ("calc2", "value2", "type2", "link2")]
    df = spark_session.createDataFrame(data, schema=schema)

    # Define a mapping of calculation column names to new names
    calculation_column_mappings = {
        "calculation_name": "new_calculation_name",
        "calculation_value": "new_calculation_value",
    }

    # Call the format_data function
    formatted_df = format_data(df, calculation_column_mappings)

    # Assert that the returned DataFrame has the expected structure and values
    assert "new_calculation_name" in formatted_df.columns
    assert "new_calculation_value" in formatted_df.columns
