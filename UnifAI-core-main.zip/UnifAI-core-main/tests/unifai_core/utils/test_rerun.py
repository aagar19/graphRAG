from datetime import datetime
from typing import List
from uuid import uuid4

import pytest
from pyspark.sql import DataFrame

from tests.conftest import unit_test
from unifai_core.utils.rerun import generate_instructions
from unifai_core.utils.rerun import get_job_details_from_id
from unifai_core.utils.rerun import get_orchestration_details_from_id
from unifai_core.utils.rerun import load_from_current_version


def create_temporary_tables(spark):
    # temporary application data
    app_data = [("test_app_id", "test_app", "desc", "test_path", "ver", "test_config", "test_user", "test_date")]
    app_df = spark.createDataFrame(
        app_data,
        ["id", "name", "description", "path", "version", "configuration", "update_user_id", "update_date_time"],
    )
    app_df.createOrReplaceTempView("unifai_core_applications")

    # temporary orchestration data
    orchestration_data = [
        (
            "existing_id",
            "test_app",
            "test_run",
            "test_parent",
            '{"disease": "hf", "premade_cohort": true, "input_schema": "test_schema", "is_ckd7": false}',
            "test_url",
            "test_version",
            "test_user",
            "test_date",
        )
    ]
    orchestration_df = spark.createDataFrame(
        orchestration_data,
        [
            "id",
            "name",
            "run_id",
            "parent_id",
            "configuration",
            "link_url",
            "version",
            "update_user_id",
            "update_date_time",
        ],
    )
    orchestration_df.createOrReplaceTempView("unifai_core_orchestration")

    # temporary repository data
    repositories_data = [
        ("test_rep_id", "test_app_id", "test_path", "valid_git_url", "somehash", "test_user", "test_date")
    ]
    repositories_df = spark.createDataFrame(
        repositories_data, ["id", "application_id", "path", "url", "hash", "update_user_id", "update_date_time"]
    )
    repositories_df.createOrReplaceTempView("unifai_core_repositories")

    # temporary jobs data
    jobs_data = [
        (
            "test_jobid",
            "test_app_id",
            "test_job",
            "test_class",
            '{"disease": "hf", "premade_cohort": true, "input_schema": "test_schema", "is_ckd7": false}',
            0,
            "test_user",
            "test_date",
        )
    ]
    jobs_df = spark.createDataFrame(
        jobs_data,
        ["id", "application_id", "name", "class_name", "configuration", "status", "update_user_id", "update_date_time"],
    )
    jobs_df.createOrReplaceTempView("unifai_core_jobs")

    # temporary job runs data
    job_runs_data = [
        (
            "test_id",
            "test_app_id",
            "test_jobid",
            "test_dbid",
            "existing_id",
            "somestarttime",
            "someendtime",
            "test_run_date",
            "test_run",
            "test_user",
            '{"disease": "hf", "premade_cohort": true, "input_schema": "test_schema", "is_ckd7": false}',
            0,
            "",
            "test_hash",
            "0.3.7",
            "noone",
        )
    ]
    job_runs_df = spark.createDataFrame(
        job_runs_data,
        [
            "id",
            "application_id",
            "job_id",
            "databricks_id",
            "orchestration_id",
            "start_time",
            "end_time",
            "run_as_of",
            "run_type",
            "run_user_id",
            "configuration",
            "status",
            "status_message",
            "job_hash",
            "unifai_hash",
            "notification_list",
        ],
    )
    job_runs_df.createOrReplaceTempView("unifai_core_job_runs")


@pytest.fixture()
def spark_session(setup_db_10_4):
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    create_temporary_tables(spark)
    yield spark
    spark.stop()


@unit_test
def test_load_from_current_version():
    # check for current_date
    assert load_from_current_version(str(datetime.today().date())) is True
    # check for  past date
    assert load_from_current_version("2023-09-26") is False


@unit_test
def test_get_orchestration_details_from_id(spark_session):
    # test for an existing id
    result = get_orchestration_details_from_id(spark_session, "existing_id")
    # check if its a dataframe
    assert isinstance(result, DataFrame)
    # check that data is returned
    assert result.count() > 0

    # test for non existing id
    with pytest.raises(ValueError, match="No workflows found with the given id"):
        get_orchestration_details_from_id(spark_session, "non_existing_id")


@unit_test
def test_get_job_details_from_id(spark_session):
    ids = ["existing_id"]
    result = get_job_details_from_id(spark_session, ids)
    # check if its a dataframe
    assert isinstance(result, DataFrame)
    # check that data is returned
    assert result.count() > 0

    non_ids = ["non_existing_id"]
    # test for non existing id
    with pytest.raises(ValueError, match="No matching jobs found with the orchestration_id"):
        get_job_details_from_id(spark_session, non_ids)


@unit_test
def test_generate_instructions(spark_session):
    workflow_id = str(uuid4())
    orch_ids = ["existing_id"]
    data_as_of = "test_data_as_of"
    job_details = get_job_details_from_id(spark_session, orch_ids)
    result = generate_instructions(spark_session, workflow_id, orch_ids, data_as_of, job_details)
    assert isinstance(result, List)
    # check is there are instructions appended into the list
    assert len(result) > 0
