from unittest.mock import patch

import pytest

from tests.conftest import unit_test
from unifai_core.utils.parser import populate_run_args
from unifai_core.utils.parser import update_run_args


def test_populate_run_args_success():
    """Test case for successfully populating run arguments."""
    run_name = "sample_run"
    job_inputs = {
        "param1": {"required": True, "type": "string", "default": "default_value1"},
        "param2": {"required": False, "type": "integer", "default": 42},
        "param3": {"required": True, "type": "boolean", "default": True},
    }
    job_args = {"param1": "provided_value1"}
    sys_config = {}

    with patch("click.prompt") as mock_prompt, patch("click.confirm") as mock_confirm:

        def side_effect(prompt, type=None, default=None, show_default=True):
            # Specific handling for each parameter based on the prompt message or type
            if "param1" in prompt and type == str:
                return "provided_value2"
            elif "param2" in prompt and type == int:
                return 70
            return default

        mock_prompt.side_effect = side_effect
        mock_confirm.return_value = True
        result = populate_run_args(run_name, job_inputs, job_args, sys_config)

    expected_result = {
        "param1": "provided_value2",
        "param2": 70,
        "param3": True,
    }

    assert result == expected_result


@unit_test
def test_populate_run_args_required_param_missing():
    """Test case for missing required parameter causing ValueError."""
    run_name = "sample_run"
    job_inputs = {
        "param1": {"required": True, "type": "string", "default": None},
    }
    job_args = {}
    sys_config = {}

    with patch("click.prompt", return_value=None):
        with pytest.raises(ValueError) as error:
            populate_run_args(run_name, job_inputs, job_args, sys_config)
        assert str(error.value) == "Failed to start job sample_run as required input (param1) was not provided!"


@unit_test
def test_update_run_args_success():
    """Test case for successfully updating run arguments."""
    job_name = "sample_job"
    job_config = {"param1": "configured_value1", "param2": 42}
    inputs = {
        "param1": {"required": True, "type": "string", "default": "default_value1"},
        "param2": {"required": False, "type": "integer", "default": 42},
        "param3": {"required": True, "type": "boolean", "default": True},
    }
    kwargs = {"param1": "provided_value1", "param3": "True"}

    result = update_run_args(job_name, job_config, inputs, **kwargs)

    expected_result = {
        "param1": "provided_value1",
        "param2": 42,
        "param3": True,
    }

    assert result == expected_result


@unit_test
def test_update_run_args_required_param_missing():
    """Test case for missing required parameter causing ValueError."""
    job_name = "sample_job"
    job_config = {}
    inputs = {
        "param1": {"required": True, "type": "string", "default": None},
    }
    kwargs = {}

    with pytest.raises(ValueError) as error:
        update_run_args(job_name, job_config, inputs, **kwargs)
    assert str(error.value) == "Failed to parse required job (sample_job) input (param1), as it was not provided!"


@unit_test
def test_update_run_args_casting():
    """Test case for type casting in update_run_args."""
    job_name = "sample_job"
    job_config = {"param2": "42", "param3": "True"}
    inputs = {
        "param1": {"required": True, "type": "string", "default": "default_value1"},
        "param2": {"required": False, "type": "integer", "default": 42},
        "param3": {"required": True, "type": "boolean", "default": True},
    }
    kwargs = {"param2": "123", "param3": "false"}

    result = update_run_args(job_name, job_config, inputs, **kwargs)

    expected_result = {
        "param1": "default_value1",
        "param2": 123,
        "param3": False,
    }

    assert result == expected_result


@unit_test
def test_update_run_args_default_values():
    """Test case to ensure default values are used if not provided."""
    job_name = "sample_job"
    job_config = {}
    inputs = {
        "param1": {"required": True, "type": "string", "default": "default_value1"},
        "param2": {"required": False, "type": "integer", "default": 42},
    }
    kwargs = {}

    result = update_run_args(job_name, job_config, inputs, **kwargs)

    expected_result = {
        "param1": "default_value1",
        "param2": 42,
    }

    assert result == expected_result
