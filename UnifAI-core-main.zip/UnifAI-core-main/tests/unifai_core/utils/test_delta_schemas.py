"""Tests for unifai_core.utils."""

import pytest
from pyspark.sql.types import FloatType
from pyspark.sql.types import IntegerType
from pyspark.sql.types import StringType
from pyspark.sql.types import StructField
from pyspark.sql.types import StructType

from tests.conftest import unit_test
from unifai_core.utils.delta_schemas import can_convert
from unifai_core.utils.delta_schemas import get_missing_columns
from unifai_core.utils.delta_schemas import get_non_matching_dtypes
from unifai_core.utils.delta_schemas import update_dataframe_to_match_existing


@pytest.fixture()
def spark_session(setup_db_10_4):
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    yield spark
    spark.stop()


@unit_test
def test_can_convert(spark_session):
    # Test default conversions
    assert can_convert("int", "float") is True
    assert can_convert("int", "string") is True
    assert can_convert("void", "string") is True
    assert can_convert("string", "int") is False

    # Test custom conversions
    custom_conversions = {"int": {"string"}}
    assert can_convert("int", "string", custom_conversions) is True


@unit_test
def test_get_missing_columns(spark_session):
    schema1 = StructType([StructField("col1", IntegerType()), StructField("col2", StringType())])
    schema2 = StructType([StructField("col1", IntegerType())])

    df1 = spark_session.createDataFrame([(1, "a"), (2, "b")], schema=schema1)
    df2 = spark_session.createDataFrame([(1,), (2,)], schema=schema2)

    assert get_missing_columns(df2, df1) == {"col2"}
    assert get_missing_columns(df1, df2) == set()


@unit_test
def test_get_non_matching_dtypes(spark_session):
    schema1 = StructType([StructField("col1", IntegerType()), StructField("col2", StringType())])
    schema2 = StructType([StructField("col1", FloatType()), StructField("col2", StringType())])

    df1 = spark_session.createDataFrame([(1, "a"), (2, "b")], schema=schema1)
    df2 = spark_session.createDataFrame([(1.0, "a"), (2.0, "b")], schema=schema2)

    castable, not_castable = get_non_matching_dtypes(df1, df2)

    assert castable == {"col1": {"from": "int", "to": "float"}}
    assert not_castable == {}


@unit_test
def test_update_dataframe_to_match_existing(spark_session):
    schema1 = StructType([StructField("col1", IntegerType()), StructField("col2", StringType())])
    schema2 = StructType([StructField("col1", FloatType())])

    df1 = spark_session.createDataFrame([(1, "a"), (2, "b")], schema=schema1)
    df2 = spark_session.createDataFrame([(1.0,), (2.0,)], schema=schema2)

    updated_df = update_dataframe_to_match_existing(df2, df1)

    assert set(updated_df.columns) == {"col1", "col2"}
    assert dict(updated_df.dtypes) == {"col1": "float", "col2": "string"}
