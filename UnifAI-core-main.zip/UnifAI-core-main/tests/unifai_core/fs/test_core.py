import shutil
from tempfile import mkdtemp

from tests.conftest import unit_test
from unifai_core.fs.core import ls


# from pytest import fixture


@unit_test
def test_ls_dbfs(monkeypatch, setup_db_10_4) -> None:
    tempdir = mkdtemp()
    monkeypatch.setenv("HOME", tempdir)
    monkeypatch.setenv("_JAVA_OPTIONS", f"-Duser.home={tempdir}")

    contents = ls("dbfs:/")

    assert "dbfs:/databricks-results/" in contents
    shutil.rmtree(tempdir)


@unit_test
def test_ls_local() -> None:
    tempdir = mkdtemp()
    with open(f"{tempdir}/file", "w") as f:
        f.write("anything")

    content = ls(tempdir)

    assert len(content) == 1
    assert content[0] == "file"

    shutil.rmtree(tempdir)
