"""Tests for unifai.fs.utils."""

from pytest import raises

from tests.conftest import unit_test
from unifai_core.fs.utils import filesystem_function


@unit_test
def test_filesystems_function_dbfs():
    func = filesystem_function("dbfs:/mnt")

    assert func.__name__ == "db_ls_wrapper"


@unit_test
def test_filesystems_function_local():
    func = filesystem_function("/home")

    assert func.__name__ == "listdir"


@unit_test
def test_filesystems_function_other():
    with raises(NotImplementedError):
        _ = filesystem_function("hdfs://home")
