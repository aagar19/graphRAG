"""Tests for unifai_core.fs."""
