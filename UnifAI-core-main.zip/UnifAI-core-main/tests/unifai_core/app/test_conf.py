import os
import sys
from typing import Generator

from pytest import fixture

from tests.conftest import unit_test
from unifai_core.app.conf import ApplicationConfiguration
from unifai_core.app.conf import JobConfiguration


@fixture
def app_fixture(base_unifai_home, monkeypatch) -> Generator[str, None, None]:
    app_path = f"{base_unifai_home}/path_app_name"
    os.mkdir(app_path)
    existing_sys_path = sys.path
    new_sys_path = existing_sys_path.copy()
    new_sys_path.append(base_unifai_home)
    monkeypatch.setattr("sys.path", new_sys_path)

    yield app_path

    try:
        del sys.modules["path_app_name"]
    except KeyError:
        pass


@unit_test
def test_app_no_conf_file(app_fixture) -> None:
    result = False
    try:
        ApplicationConfiguration(app_path=app_fixture)
    except Exception:
        result = True
    assert result is True


@unit_test
def test_app_with_conf_file(app_fixture) -> None:
    with open(f"{app_fixture}/application.yaml", "w") as f:
        f.write("name: name_from_conf_file\n")
        f.write("description: 'blah blah blah'\n")
        f.write("configuration:\n")
        f.write("  sample_key: 'sample value'\n")

    application = ApplicationConfiguration(app_path=app_fixture)

    assert application.name == "name_from_conf_file"
    assert application.description == "blah blah blah"
    assert application.get("SAMPLE_KEY") == "sample value"


@unit_test
def test_app_with_bad_conf_file(app_fixture) -> None:
    with open(f"{app_fixture}/application.yaml", "w") as f:
        f.write("not_app_name: name_from_conf_file")

    assert ApplicationConfiguration(app_path=app_fixture).name == "path_app_name"


@unit_test
def test_end_job(app_fixture):
    with open(f"{app_fixture}/application.yaml", "w") as f:
        f.write("name: name_from_conf_file\n")
        f.write("description: 'blah blah blah'\n")
        f.write("configuration:\n")
        f.write("  sample_key: 'sample value'\n")
    app_conf = ApplicationConfiguration(app_path=app_fixture)

    job_conf = JobConfiguration(application=app_conf, job_name="test_end_job", orchestration_id="1234")
    status, message = job_conf.end_job()

    assert status == 0
    assert message is None
