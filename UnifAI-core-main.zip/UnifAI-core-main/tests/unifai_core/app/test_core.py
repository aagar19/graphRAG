import json
import os
from random import randint
from subprocess import run

import pytest
import yaml

from tests.conftest import unit_test
from unifai_core.app import core


def create_temporary_tables(spark):
    mock_app_table = [
        {
            "id": "app_id_1",
            "name": "App1",
            "version": "1.0",
            "url": "http://app1.url",
            "path": "/app1/path",
            "description": "App1 description",
        }
    ]

    mock_repo_table = [
        {
            "id": "id_1",
            "application_id": "app_id_1",
            "path": "/Workspace/Repos/schema/App1",
            "url": "https://old.url.com",
            "hash": "old_hash",
        }
    ]

    mock_jobs_table = [
        {
            "id": "jb_id1",
            "application_id": "app_id_1",
            "name": "some_job",
            "class_name": "SomeClass",
            "configuration": (
                '{"sys_paths": ["{REPO_PATH}/ml_pipeline/src"], "dependencies": [], '
                '"inputs": {"run_as_of": {"default": "{SYS_TODAY}", "description": "---", '
                '"required": true, "type": "STRING"}, "run_type": {"default": "MONTHLY", '
                '"description": "---", "required": false, "type": "STRING"}, '
                '"input_schema": {"default": null, "description": "---", "required": false, '
                '"type": "STRING"}, "lookback_months": {"default": 6, "description": "---", '
                '"required": true, "type": "INTEGER"}}, "cluster": {"runtime_version": '
                '"10.4.x-scala2.12", "node_type": "Standard_DS5_v2", "use_photon": false, '
                '"max_workers": 8, "min_workers": 4}}'
            ),
        }
    ]

    mock_job_runs_table = [
        {
            "id": "jr_id1",
            "application_id": "app_id_1",
            "job_id": "jb_id1",
            "databricks_id": "db_id",
            "orchestration_id": "orch_id1",
            "start_time": "2023-08-02T15:00:12.246+00:00",
            "end_time": "2023-08-02T15:19:04.574+00:00",
            "run_as_of": "2023-05-25",
            "run_type": "PROSPECTIVE",
            "run_user_id": "someone@optum.com",
            "status": 0,
            "status_message": "",
            "job_hash": "345262789",
            "unifai_hash": "0.3.13",
        }
    ]

    app_table_df = spark.createDataFrame(mock_app_table)
    repo_table_df = spark.createDataFrame(mock_repo_table)
    jobs_table_df = spark.createDataFrame(mock_jobs_table)
    job_runs_table_df = spark.createDataFrame(mock_job_runs_table)

    app_table_df.createOrReplaceTempView("unifai_core_applications")
    repo_table_df.createOrReplaceTempView("unifai_core_repositories")
    jobs_table_df.createOrReplaceTempView("unifai_core_jobs")
    job_runs_table_df.createOrReplaceTempView("unifai_core_job_runs")


@pytest.fixture()
def spark_session(setup_db_10_4):
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()
    create_temporary_tables(spark)
    yield spark
    spark.stop()


@unit_test
def test_list_apps(spark_session):
    result = core.list_apps()
    assert result

    assert any(r.name == "App1" for r in result)


@unit_test
def test_list_jobs(spark_session):
    result = core.list_jobs("App1")

    assert result

    assert any(r.name == "some_job" for r in result)


@unit_test
def test_list_runs(spark_session):
    result = core.list_runs("App1")

    assert result

    assert any(r.job_hash == "345262789" for r in result)


@unit_test
def test_list_params(spark_session):
    result = core.list_params("App1", "some_job")

    assert result

    assert len(result) > 0


@unit_test
def test_repo_exists_not_existing(monkeypatch_session):
    assert os.environ["DATABRICKS_TOKEN"] is not None
    assert core._does_repo_exists(f"/Repos/test/r{randint(100000, 999999)}") is False


@unit_test
def test_repo_exists(session_db_repo, monkeypatch_session) -> None:
    assert os.environ["DATABRICKS_TOKEN"] is not None

    api_out = run(["databricks", "repos", "list"], capture_output=True)  # noqa: S603, S607
    repos = None if api_out.returncode != 0 else json.loads(api_out.stdout).get("repos")

    assert repos is not None
    assert len(repos) > 0

    assert core._does_repo_exists(repos[0]["path"])


@unit_test
def test_load_artifacts_yaml_valid_file(tmp_path):
    # Create a valid yaml file
    data = {"key": "value"}
    file_path = tmp_path / "artifacts.yaml"
    file_path.write_text(yaml.dump(data))

    # Call the function
    result = core.load_artifacts_yaml(file_path)

    # Check the result
    assert isinstance(result, dict)
    assert result == data
