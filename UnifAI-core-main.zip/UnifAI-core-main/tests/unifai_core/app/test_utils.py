"""tests for unifai_core.app.utils module."""

import json
import os
import shutil
import subprocess
from pathlib import Path
from tempfile import mkdtemp
from unittest.mock import Mock
from unittest.mock import patch

import pytest
from pytest import raises

from tests.conftest import unit_test
from unifai_core.app.utils import clean_path
from unifai_core.app.utils import db_fs_ls
from unifai_core.app.utils import db_fs_mkdir
from unifai_core.app.utils import db_fs_remove
from unifai_core.app.utils import db_ws_ls
from unifai_core.app.utils import db_ws_mkdir
from unifai_core.app.utils import db_ws_remove
from unifai_core.app.utils import extract_job_info
from unifai_core.app.utils import find_repo
from unifai_core.app.utils import get_git_hash
from unifai_core.app.utils import give_users_view_permission
from unifai_core.app.utils import retry_spark_sql


@unit_test
def test_root() -> None:
    with raises(FileNotFoundError):
        find_repo("/")


@unit_test
def test_at_depth_1() -> None:
    temp_dir = mkdtemp()

    os.mkdir(temp_dir + "/.git")
    Path(temp_dir + "/file").touch()

    r, p = find_repo(temp_dir + "/file")

    assert r == temp_dir
    assert p == "file"

    shutil.rmtree(temp_dir)


@unit_test
def test_at_depth_2() -> None:
    temp_dir = mkdtemp()

    os.mkdir(temp_dir + "/.git")
    os.mkdir(temp_dir + "/d1")
    Path(temp_dir + "/d1/file").touch()

    r, p = find_repo(temp_dir + "/d1/file")

    assert r == temp_dir
    assert p == "d1/file"

    shutil.rmtree(temp_dir)


@unit_test
def test_file_at_depth_2_repo_at_depth_1() -> None:
    temp_dir = mkdtemp()

    os.mkdir(temp_dir + "/d1")
    os.mkdir(temp_dir + "/d1/.git")
    os.mkdir(temp_dir + "/d1/d2")
    Path(temp_dir + "/d1/file").touch()

    r, p = find_repo(temp_dir + "/d1/d2/file")

    assert r == temp_dir + "/d1"
    assert p == "d2/file"

    shutil.rmtree(temp_dir)


@unit_test
def test_retry_spark_sql_success(setup_db_10_4):
    # Initialize Spark session
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()

    # Create test dataframe
    df = spark.createDataFrame([(1, "John"), (2, "Jane")], ["id", "name"])
    df.createOrReplaceTempView("test_table")

    # Define SQL query
    sql = "SELECT * FROM test_table"

    # Call the function
    result = retry_spark_sql(spark, sql)

    # Assert the result
    assert result == [(1, "John"), (2, "Jane")]


@unit_test
def test_retry_spark_sql_exception(setup_db_10_4):
    # Initialize Spark session
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()

    # Define SQL query that will raise an exception
    sql = "SELECT * FROM non_existent_table"

    # Call the function and expect an exception to be raised
    with pytest.raises(RuntimeError):
        retry_spark_sql(spark, sql)


def test_db_ws_ls_success(mocker):
    # Prepare test data with a successful command execution
    path = "/path/to/workspace"
    expected_output = b"file1.txt\nfile2.txt\ndir1\n"

    # Patch the `subprocess.run` function to return the expected output
    mocker.patch.object(subprocess, "run", return_value=Mock(returncode=0, stdout=expected_output))

    # Call the function under test
    result = db_ws_ls(path)

    # Assert that the function returns a list of directory contents
    assert result == ["file1.txt", "file2.txt", "dir1", ""]


@unit_test
def test_db_ws_ls_failure():
    # Mocking the subprocess run functionality
    with patch("subprocess.run") as mock_run:
        mock_process = Mock(returncode=1, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Call the function
        result = db_ws_ls("/path/to/workspace")

        # Assert the result
        assert result is None
        mock_run.reset_mock()


@unit_test
def test_db_ws_mkdir_success():
    # Mocking the subprocess run functionality
    with patch("unifai_core.app.utils.subprocess.run") as mock_run:
        mock_process = Mock(returncode=0, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test a successful directory creation
        result = db_ws_mkdir("/path/to/directory")

        assert result is True
        mock_run.reset_mock()


@unit_test
def test_db_ws_mkdir_failure():
    # Mocking the subprocess run functionality
    with patch("subprocess.run") as mock_run:
        mock_process = Mock(returncode=1, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test a failed directory creation
        result = db_ws_mkdir("/path/to/nonexistent")

        assert result is False
        mock_run.reset_mock()


@unit_test
def test_db_ws_remove_non_recursive_success():
    # Mocking the subprocess run functionality
    with patch("subprocess.run") as mock_run:
        mock_process = Mock(returncode=0, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test removing a file without recursion
        result = db_ws_remove("/path/to/file")

        assert result is True
        mock_run.reset_mock()


@unit_test
def test_db_ws_remove_recursive_success():
    # Mocking the subprocess run functionality
    with patch("subprocess.run") as mock_run:
        mock_process = Mock(returncode=0, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test removing a file with recursion
        result = db_ws_remove("/path/to/directory", recursive=True)

        assert result is True
        mock_run.reset_mock()


@unit_test
def test_db_ws_remove_failure():
    # Mocking the subprocess run functionality
    with patch("subprocess.run") as mock_run:
        mock_process = Mock(returncode=1, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test a failed file removal
        result = db_ws_remove("/path/to/nonexistent")

        assert result is False
        mock_run.reset_mock()


@unit_test
def test_clean_path_with_prefix():
    # Test cleaning a path with a prefix
    result = clean_path("/dbfs/path/to/file", "prefix")

    assert result == "prefix/path/to/file"


@unit_test
def test_clean_path_without_prefix():
    # Test cleaning a path without a prefix
    result = clean_path("/dbfs/path/to/file")

    assert result == "/path/to/file"


@unit_test
def test_clean_path_with_workspace_prefix():
    # Test cleaning a path with the Workspace prefix
    result = clean_path("Workspace:/path/to/file")

    assert result == "/path/to/file"


@unit_test
def test_clean_path_with_dbfs_prefix():
    # Test cleaning a path with the dbfs prefix
    result = clean_path("dbfs:/path/to/file")

    assert result == "/path/to/file"


@unit_test
def test_get_git_hash_success():
    # Prepare test data with a successful command execution and valid JSON output
    repo_path = "/path/to/repo"
    expected_output = {"head_commit_id": "1234567890abcdef"}
    mock_run = Mock(spec=subprocess.CompletedProcess)
    mock_run.returncode = 0
    mock_run.stdout = json.dumps(expected_output).encode()

    # Patch the `run` function to return the expected output
    with patch("subprocess.run", return_value=mock_run) as mock_run:
        # Call the function under test
        result = get_git_hash(repo_path)

        # Assert that the function returns the correct git hash
        assert result == expected_output["head_commit_id"]

        # Assert that the `run` function is called with the correct arguments
        mock_run.assert_called_once_with(["databricks", "repos", "get", "--path", repo_path], capture_output=True)


@unit_test
def test_get_git_hash_failure():
    # Prepare test data with a failed command execution
    repo_path = "/path/to/repo"
    error_output = b"Error: Failed to fetch repo"

    # Patch the `run` function to return the expected error output
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = Mock(spec=subprocess.CompletedProcess)
        mock_run.return_value.returncode = 1
        mock_run.return_value.stdout = b""
        mock_run.return_value.stderr = error_output

        # Call the function under test and assert that it raises a `RuntimeError`
        with pytest.raises(RuntimeError) as exc_info:
            get_git_hash(repo_path)

            # Assert that the `RuntimeError` message contains the expected error message
        assert (
            str(exc_info.value)
            == f"Databricks failed to fetch repo {repo_path!r} with stdout: b'' and stderr: {error_output!r}"
        )


@unit_test
def test_extract_job_info_success():
    # Prepare test data with a successful command execution
    stdout = b'{"run_id": 1234, "logs": "log output", "metadata": {"job_id": 5678}}'
    expected_job_id = 5678
    expected_run_id = "1234"

    # Patch the necessary functions to return the expected values
    with patch("subprocess.run") as mock_run, patch("unifai_core.app.utils.print") as mock_print:  # noqa: F841
        mock_run.return_value = subprocess.CompletedProcess(args=[], returncode=0, stdout=stdout)

        # Call the function under test
        job_id, run_id = extract_job_info(stdout, debug=True, wait=False, job_run_info=None)

        # Assert that the function returns the expected job_id and run_id
        assert job_id == expected_job_id
        assert run_id == expected_run_id


@unit_test
def test_extract_job_info_exception():
    # Prepare test data with an exception
    stdout = b'{"run_id": 1234, "logs": "log output", "metadata": {"job_id": 5678}}'

    # Patch the necessary functions to raise an exception
    with patch("subprocess.run") as mock_run, patch("unifai_core.app.utils.print") as mock_print, patch(  # noqa: F841
        "unifai_core.cli.utils.insert_into_job_runs"
    ) as mock_insert:  # noqa: F841
        mock_run.side_effect = Exception("Some Exception")

        # Call the function under test
        job_id, run_id = extract_job_info(stdout, debug=True, wait=False, job_run_info=None)

        # Assert that the function returns None for job_id and run_id
        assert job_id is None
        assert run_id is None


@unit_test
def test_db_fs_ls_without_cli_failure():
    # Mocking the subprocess run functionality
    with patch("unifai_core.app.utils.subprocess.run") as mock_run:
        mock_process = Mock(returncode=1, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test a failed directory creation
        result = db_fs_ls("/path/to/nonexistent")

        assert result is None
        mock_run.reset_mock()


@unit_test
def test_db_fs_ls_with_cli_failure():
    # Mocking the subprocess run functionality
    with patch("unifai_core.app.utils.subprocess.run") as mock_run:
        mock_process = Mock(returncode=1, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test a failed directory creation
        result = db_fs_ls("/path/to/nonexistent", True)

        assert result is None
        mock_run.reset_mock()


@unit_test
def test_db_fs_mkdir_with_cli_success(mocker):
    # Mocking the subprocess run functionality
    with patch("unifai_core.app.utils.subprocess.run") as mock_run:
        mock_process = Mock(returncode=0, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test a successful directory creation
        result = db_fs_mkdir("/path/to/directory", True)

        assert result is True
        mock_run.reset_mock()


@unit_test
def test_db_fs_mkdir_without_cli_success(mocker):
    # Mocking the subprocess run functionality
    with patch("unifai_core.app.utils.subprocess.run") as mock_run:
        mock_process = Mock(returncode=0, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test a successful directory creation
        result = db_fs_mkdir("/path/to/directory")

        assert result is True
        mock_run.reset_mock()


@unit_test
def test_db_fs_mkdir_failure():
    # Mocking the subprocess run functionality
    with patch("unifai_core.app.utils.subprocess.run") as mock_run:
        mock_process = Mock(returncode=1, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test a failed directory creation
        result = db_fs_mkdir("/path/to/nonexistent")

        assert result is True
        mock_run.reset_mock()


@unit_test
def test_db_fs_remove_without_cli_non_recursive_success():
    # Mocking the subprocess run functionality
    with patch("unifai_core.app.utils.subprocess.run") as mock_run:
        mock_process = Mock(returncode=0, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test removing a file without recursion
        result = db_fs_remove("/path/to/file")

        assert result is False
        mock_run.reset_mock()


@unit_test
def test_db_fs_remove_with_cli_non_recursive_success():
    # Mocking the subprocess run functionality
    with patch("unifai_core.app.utils.subprocess.run") as mock_run:
        mock_process = Mock(returncode=0, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test removing a file without recursion
        result = db_fs_remove("/path/to/file", recursive=False, use_cli=True)

        assert result is True
        mock_run.reset_mock()


@unit_test
def test_db_fs_remove_with_cli_recursive_success():
    # Mocking the subprocess run functionality
    with patch("subprocess.run") as mock_run:
        mock_process = Mock(returncode=0, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test removing a file with recursion
        result = db_fs_remove("/path/to/directory", recursive=True, use_cli=True)

        assert result is True
        mock_run.reset_mock()


@unit_test
def test_db_fs_remove_failure():
    # Mocking the subprocess run functionality
    with patch("subprocess.run") as mock_run:
        mock_process = Mock(returncode=1, stdout=b"", stderr=b"")
        mock_run.return_value = mock_process

        # Test a failed file removal
        result = db_fs_remove("/path/to/nonexistent")

        assert result is True
        mock_run.reset_mock()


@unit_test
def test_give_users_view_permission_without_users():
    submit_body = {"access_control_list": [{"group_name": "non-users"}]}
    result = give_users_view_permission(submit_body)

    resp_body = [d for d in result["access_control_list"] if d.get("group_name") == "users"]

    assert resp_body[0] == {"group_name": "users", "permission_level": "CAN_VIEW"}


@unit_test
def test_give_users_view_permission_with_users():
    submit_body = {"access_control_list": [{"group_name": "users", "permission_level": "CAN_VIEW"}]}
    result = give_users_view_permission(submit_body)

    assert result == submit_body
