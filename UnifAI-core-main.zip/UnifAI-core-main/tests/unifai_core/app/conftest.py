import os
from random import randint
from subprocess import run  # noqa: S404
from typing import Generator

import github  # type: ignore
from pytest import fixture

from unifai_core.app import core


@fixture(scope="session")
def gh_api_client() -> github.Github:
    return github.Github(os.environ["CI_CD_GITHUB_USER"], password=os.environ["CI_CD_GITHUB_PAT"])


@fixture(scope="session")
def session_git_repo(gh_api_client) -> Generator[str, None, None]:
    """Creates a new session scoped repo in Github."""
    repo = gh_api_client.get_user().create_repo(
        f"testing-session-{randint(100000, 999999)}", private=True, auto_init=True
    )
    yield repo.html_url
    repo.delete()


@fixture(scope="session")
def session_db_repo(session_git_repo, monkeypatch_session) -> Generator[str, None, None]:
    repo_name = f"r{randint(100000, 999999)}"
    yield core._update_db_repo(session_git_repo, "/Repos/test", repo_name)
    run(["databricks", "repos", "delete", "--path", f"/Repos/test/{repo_name}"])  # noqa: S607,S603
