from unittest.mock import MagicMock
from unittest.mock import patch

import pytest

from unifai_core.data_quality.utils import _update_ai_check_summary
from unifai_core.data_quality.utils import _update_bad_records
from unifai_core.data_quality.utils import _update_dataset_summary
from unifai_core.data_quality.utils import _update_results
from unifai_core.data_quality.utils import _update_runs
from unifai_core.data_quality.utils import _update_summary


@pytest.fixture
def mock_spark():
    return MagicMock()


@patch("unifai_core.data_quality.utils.retry_spark_sql")
def test_update_runs(mock_retry_spark_sql, mock_spark):
    run_id = "test_run_id"
    runs_dict = {
        "application_id": "app_id",
        "databricks_id": "db_id",
        "orchestration_id": "orch_id",
        "start_time": MagicMock(),
        "end_time": MagicMock(),
        "configuration": "config",
        "job_status": "status",
        "jobs_status_message": "message",
        "checks_passed": "passed",
        "app_hash": "hash1",
        "unifai_hash": "hash2",
    }
    runs_dict["start_time"].timestamp.return_value = 1625097600
    runs_dict["end_time"].timestamp.return_value = 1625097700

    _update_runs(mock_spark, run_id, runs_dict)
    mock_retry_spark_sql.assert_called_once()


@patch("unifai_core.data_quality.utils.retry_spark_sql")
def test_update_results(mock_retry_spark_sql, mock_spark):
    run_id = "test_run_id"
    results_dict = {
        "result1": {
            "application_id": "app_id",
            "orchestration_id": "orch_id",
            "view_name": "view1",
            "accept": "accepted",
        }
    }
    layer = "test_layer"

    _update_results(mock_spark, run_id, results_dict, layer)
    mock_retry_spark_sql.assert_called_once()


@patch("unifai_core.data_quality.utils.retry_spark_sql")
def test_update_summary(mock_retry_spark_sql, mock_spark):
    run_id = "test_run_id"
    summary_dicts = {
        "summary1": {
            "application_id": "app_id",
            "orchestration_id": "orch_id",
            "view_name": "view1",
            "check_name": "check1",
            "actual_rows": 100,
            "total_joined_rows": 200,
            "eligible_rows": 150,
            "bad_rows": 50,
            "clean_rows": 100,
        }
    }

    _update_summary(mock_spark, run_id, summary_dicts)
    mock_retry_spark_sql.assert_called_once()


@patch("unifai_core.data_quality.utils.retry_spark_sql")
def test_update_dataset_summary(mock_retry_spark_sql, mock_spark):
    run_id = "test_run_id"
    dataset_summary_dicts = {
        "summary1": {
            "application_id": "app_id",
            "orchestration_id": "orch_id",
            "view_name": "view1",
            "total_rows": 100,
            "bad_rows": 20,
            "clean_rows": 80,
            "bad_row_percent": 20.0,
            "accept": True,
        }
    }

    _update_dataset_summary(mock_spark, run_id, dataset_summary_dicts)
    mock_retry_spark_sql.assert_called_once()


@patch("unifai_core.data_quality.utils.retry_spark_sql")
def test_update_bad_records(mock_retry_spark_sql, mock_spark):
    run_id = "test_run_id"
    bad_records_dict = {
        "application_id": "app_id",
        "orchestration_id": "orch_id",
        "input_table": "table1",
        "check": "check1",
        "record_id": "rec1",
        "SEVERITY": "high",
        "ERROR_CODE": "E001",
        "FAILURE_REASON": "Test failure",
    }

    _update_bad_records(mock_spark, run_id, bad_records_dict)
    mock_retry_spark_sql.assert_called_once()


@patch("unifai_core.data_quality.utils.retry_spark_sql")
def test_update_ai_check_summary(mock_retry_spark_sql, mock_spark):
    run_id = "test_run_id"
    dataset_summary_dicts = {
        "summary1": {
            "application_id": "app_id",
            "orchestration_id": "orch_id",
            "model_name": "model1",
            "Total Tests Ran": 100,
            "Total Tests Failed": 20,
            "Total Tests Passed": 80,
            "Test Fail Percentage": 20.0,
        }
    }

    _update_ai_check_summary(mock_spark, run_id, dataset_summary_dicts)
    mock_retry_spark_sql.assert_called_once()
