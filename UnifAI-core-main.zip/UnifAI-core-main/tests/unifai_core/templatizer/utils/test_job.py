import unifai_core.templatizer.utils.job as common
from tests.conftest import unit_test


@unit_test
def test__add_imports() -> None:
    content = [
        '"""',
        "from unifai_core.jobs.base import UnifaiJob",
        "from pathlib import Path",
        "",
        "__ADD_CUSTOM_IMPORTS__",
        "",
    ]
    imports = {
        "imports": ["import pandas as pd"],
        "source_code": [
            {"class": "CreateFeatures", "import_path": "ml_pipeline.src.model.feature_creation", "returns": "features"}
        ],
    }
    new_content = common._add_imports(content, imports)
    print(new_content)
    assert new_content[4] == "import pandas as pd"
    assert new_content[5] == "from ml_pipeline.src.model.feature_creation import CreateFeatures"


@unit_test
def test__job_input_args() -> None:
    content = {
        "cdo_list": {"type": "list", "required": False, "default": None},
        "lookback_months": {"type": "int", "required": False, "default": 12},
    }
    new_content = common._job_input_args(content)
    assert new_content == "cdo_list, lookback_months, input_schema, run_as_of"


@unit_test
def test__add_data_load() -> None:
    content = [
        "class FeatureCreationUnifaiJob(UnifaiJob):",
        "    def execute(self, spark, cdo_list, lookback_months, input_schema, run_as_of, **kwargs):",
        '        """',
        "        Entry point for feature_creation UnifAI Job.",
        '        """',
        "",
        "        # ------ Load data",
        "        # TODO: review/update data load step",
        "        __ADD_DATA_LOAD__",
        "",
    ]
    job_defn = {
        "data": {
            "inputs": [
                {"variable": "cohort", "table": "falls_cohort"},
                {"variable": "cdf_codes", "table": "{input_schema}.cdf_codes"},
                {"variable": "cdf_members", "table": "{input_schema}.cdf_members"},
            ],
            "outputs": [{"variable": "features", "table": "falls_features"}],
        }
    }
    new_content = common._add_data_load(content, job_defn)
    print(new_content)
    assert new_content[8] == "        cohort = self.load_table(spark, f'falls_cohort')"
    assert new_content[9] == "        cdf_codes = self.load_table(spark, f'{input_schema}.cdf_codes')"
    assert new_content[10] == "        cdf_members = self.load_table(spark, f'{input_schema}.cdf_members')"


@unit_test
def test__add_data_write() -> None:
    content = [
        "        # ----- Write data",
        "        # TODO: review/update data write step",
        "        __ADD_DATA_WRITE__",
    ]
    job_defn = {
        "data": {
            "inputs": [
                {"variable": "cohort", "table": "falls_cohort"},
                {"variable": "cdf_codes", "table": "{input_schema}.cdf_codes"},
                {"variable": "cdf_members", "table": "{input_schema}.cdf_members"},
            ],
            "outputs": [{"variable": "features", "table": "model_features"}],
        }
    }
    new_content = common._add_data_write(content, job_defn)
    print(new_content)
    assert new_content[2] == "        self.write_table(spark, features, tablename='model_features')"
