import unifai_core.templatizer.utils.application as common
from tests.conftest import unit_test


@unit_test
def test_get_file_content() -> None:
    content = {
        "application": {
            "overview": {
                "model_name": "model_name",
                "model_suffix": "model",
                "run_type": "monthly",
                "description": "Model does predictions",
            },
            "application_variables": {"MAPPING_FILES_DIR": "/my/path/to/mapping_files"},
            "environment": {
                "create_cluster": False,
                "databricks_runtime_version": "10.4.x-cpu-ml-scala2.12",
                "node_type": "Standard_DS5_v2",
                "min_workers": 4,
                "max_workers": 4,
            },
        },
        "jobs": [
            {
                "name": "cohort",
                "environment": {"node_type": "Standard_DS5_v2", "min_workers": 2, "max_workers": 2},
                "user_inputs": {
                    "cdo_list": {"type": "list", "required": False, "default": []},
                    "lookback_months": {"type": "int", "required": False, "default": None},
                },
                "source_code": [
                    {
                        "class": "CreateCohort",
                        "import_path": "ml_pipeline.src.falls.cohort_creation",
                        "returns": "cohort",
                    }
                ],
                "data": {
                    "inputs": [{"variable": "elig_risk", "table": "{input_schema}.eods_elig_risk"}],
                    "outputs": [{"variable": "cohort", "table": "falls_cohort"}],
                },
            }
        ],
        "orchestration": {
            "git": {"repo_url": "https://github.com", "default_model_version": {"branch": "main"}},
            "dag": {
                "owner": "admin",
                "tags": ["monthly", "unifai"],
                "email": {"address_list": ["my.email@optum.com"], "email_on_retry": False, "email_on_failure": True},
                "retries": 0,
                "default_connection_id": "unifai-dev",
            },
            "job_order": ["cohort_creation", "feature_creation", "scoring", "labels"],
        },
    }
    repo_dir = "/path/to/repo"
    file_content = common.get_file_content(content, repo_dir)
    assert len(file_content) == 5
    assert len(file_content["application_yaml"]) == 4
    assert len(file_content["jobs"]) == 1
    assert len(file_content["dags"]) == 2
    assert len(file_content["README"]) == 1
    assert len(file_content["schema_names"]) == 1


@unit_test
def test_build_app_yaml() -> None:
    content = {
        "overview": {
            "model_name": "model_name",
            "model_suffix": "model",
            "run_type": "monthly",
            "description": "Model does predictions",
        },
        "application_variables": {"MAPPING_FILES_DIR": "/my/path/to/mapping_files"},
        "environment": {
            "create_cluster": False,
            "databricks_runtime_version": "10.4.x-cpu-ml-scala2.12",
            "node_type": "Standard_DS5_v2",
            "min_workers": 4,
            "max_workers": 4,
        },
    }
    app_yaml = common.build_app_yaml(content)
    assert app_yaml["name"] == "model_name_model"
    assert app_yaml["description"] == "Model does predictions"
    assert app_yaml["configuration"] == {"MAPPING_FILES_DIR": "/my/path/to/mapping_files"}
    assert app_yaml["cluster"] == {
        "create_cluster": False,
        "databricks_runtime_version": "10.4.x-cpu-ml-scala2.12",
        "node_type": "Standard_DS5_v2",
        "min_workers": 4,
        "max_workers": 4,
    }
