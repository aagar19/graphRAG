import unifai_core.templatizer.utils.common as common
from tests.conftest import unit_test


@unit_test
def test_load_template(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/template.txt", "w") as f:
        f.write(
            """
        TODO: add file-level docstring.
        from unifai_core.jobs.base import UnifaiJob
        from pathlib import Path
            """
        )

    content = common.load_template(f"{base_unifai_home}/template.txt")
    assert len(content) == 138


@unit_test
def test_load_yaml(base_unifai_home) -> None:
    with open(f"{base_unifai_home}/template.yaml", "w") as f:
        f.write(
            """
            application : falls_model
            """
        )

    content = common.load_yaml(f"{base_unifai_home}/template.yaml")
    assert len(content) == 1

    name = content["application"]
    assert name == "falls_model"


@unit_test
def test_tunderscore_to_camel_case() -> None:
    string = "snake_case"
    camel_case = common.underscore_to_camel_case(string)
    assert camel_case == "SnakeCase"
    assert camel_case != "snake_case"


@unit_test
def test_underscore_to_capitalized() -> None:
    string = "underscore_to_capitalized"
    capitalized = common.underscore_to_capitalized(string)
    assert capitalized == "Underscore To Capitalized"


@unit_test
def test_split_lines() -> None:
    string = "This is a string\nwith multiple lines."
    lines = common.split_lines(string)
    assert len(lines) == 2
    assert lines[0] == "This is a string"
    assert lines[1] == "with multiple lines."


@unit_test
def test_add_custom_lines() -> None:
    lines = ["This is a string", "with multiple lines."]
    custom_lines = ["This is a custom line", "with multiple lines."]
    break_line = "with multiple lines."
    new_lines = common.add_custom_lines(lines, break_line, custom_lines)
    assert len(new_lines) == 3
    assert new_lines[0] == "This is a string"
    assert new_lines[1] == "This is a custom line"
    assert new_lines[2] == "with multiple lines."


@unit_test
def test_write_file(base_unifai_home) -> None:
    content = ["This is a string", "with multiple lines."]
    filepath = f"{base_unifai_home}/test_file.txt"
    common.write_file(content, filepath)
    with open(filepath) as f:
        lines = f.readlines()
        assert len(lines) == 2
        assert lines[0] == "This is a string\n"
        assert lines[1] == "with multiple lines."
