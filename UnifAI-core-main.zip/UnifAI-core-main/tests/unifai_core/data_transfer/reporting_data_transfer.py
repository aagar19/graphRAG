import sys
import tempfile
import traceback

import pytest

from tests.conftest import unit_test
from unifai_core.data_management.utils import change_db
from unifai_core.data_management.utils import execute_query
from unifai_core.data_transfer.reporting_data_transfer import extract_orchestration_ids
from unifai_core.data_transfer.reporting_data_transfer import validate_orchestration_id
from unifai_core.data_transfer.reporting_data_transfer import validate_parent_id
from unifai_core.data_transfer.reporting_data_transfer import validate_schema
from unifai_core.data_transfer.reporting_data_transfer import validate_table_name


@pytest.fixture()
def create_test_data(setup_db_10_4):
    """Fixture to create test data dynamically."""
    from pyspark.sql import SparkSession  # type: ignore

    spark = SparkSession.builder.getOrCreate()

    # Creating a temp db to execute test cases
    db_name = "test_schema"  # noqa: S311
    create_qry = f"create database {db_name}"
    execute_query(create_qry)

    # Changing the new db in config
    old_db = change_db(db_name)

    try:
        # Creating temp directories
        dir_path = tempfile.mkdtemp()
        student = spark.createDataFrame(
            [(1, 234, "Bob", 2), (2, 345, "Rock", 3)], ["id", "parent_id", "Name", "application_id"]
        )
        df = spark.createDataFrame([(1, 234, "Bob", 2)], ["id", "parent_id", "Name", "application_id"])
        student.createOrReplaceTempView("orches_table")
        execute_query(f"create table {db_name}.unifai_core_orchestration as select * from orches_table")
        execute_query(f"create table {db_name}.unifai_core_jobs as select * from orches_table")
        execute_query(f"create table {db_name}.unifai_core_applications as select * from orches_table")
        execute_query(f"create table {db_name}.admits as select * from orches_table")

        yield dir_path, db_name, df, spark

        # Changing the db back to default in config
        change_db(old_db)

        # Dropping the database
        drop_qry = f"drop database {db_name} cascade"
        execute_query(drop_qry)

    except Exception:
        print(traceback.format_exc())
        change_db(old_db)
        sys.exit(2)


@pytest.fixture(scope="function", name="database_name")
def database_name(create_test_data):
    return create_test_data[1]


@pytest.fixture(scope="function", name="dataframe_test")
def dataframe_test(create_test_data):
    return create_test_data[2]


@pytest.fixture(scope="function", name="fixture_load_config")
def fixture_load_config():
    path_value = {"unifai_core_jobs": {"input_key": "job_id", "output_key": "id"}}
    return path_value


@unit_test
def test_validate_schema_pass(create_test_data, database_name):
    assert validate_schema(create_test_data[3], database_name) == "test_schema"


@unit_test
def test_validate_schema_fail(create_test_data):
    db_name = "abc"
    with pytest.raises(SystemExit) as error:
        validate_schema(create_test_data[3], db_name)
    assert error.value.code == 1


@unit_test
def test_validate_table_pass(create_test_data, database_name):
    """Function to test for passed table validation."""
    assert validate_table_name(create_test_data[3], database_name, ["admits"]) == ["admits"]


@unit_test
def test_validate_table_fail(create_test_data, database_name):
    """Function to test for failed table validation."""
    with pytest.raises(ValueError) as error:
        validate_table_name(create_test_data[3], database_name, ["random"])
    assert str(error.value) == "Invalid table names: random. Please provide correct table name."


@unit_test
def test_validate_orchestration_pass(create_test_data, database_name):
    """Function to test for orchestration table validation."""
    assert validate_orchestration_id(create_test_data[3], database_name, 1) == 1


@unit_test
def test_validate_orchestration_fail(create_test_data, database_name):
    """Function to test for orchestration table validation."""
    with pytest.raises(ValueError) as error:
        validate_orchestration_id(create_test_data[3], database_name, 8)
    assert str(error.value) == "Orchestration id 8 is invalid. Check your orchestration id."


@unit_test
def test_validate_parent_id_pass(create_test_data, database_name):
    assert validate_parent_id(create_test_data[3], database_name, 234)


@unit_test
def test_validare_parent_id_fail(create_test_data, database_name):
    with pytest.raises(ValueError) as error:
        validate_parent_id(create_test_data[3], database_name, 789)
    assert str(error.value) == "Parent id 789 is invalid. Check your parent id."


@unit_test
def test_extract_orch_id(create_test_data, database_name):
    result = extract_orchestration_ids(create_test_data[3], database_name, 234)
    assert result == [1]
