import os
from random import randint
from subprocess import run

from click.testing import CliRunner
from pytest import fixture

from tests.conftest import smoke_test
from unifai_core import __main__


@fixture
def runner(setup_db_10_4, monkeypatch) -> CliRunner:
    """Fixture for invoking command-line interfaces."""
    return CliRunner()


@smoke_test
def test_run_smoke_tests(setup_db_10_4, monkeypatch, runner: CliRunner) -> None:
    """Full testing of UnifAI core."""
    github_url = os.environ["CI_CD_CORE_GITHUB"]
    github_branch = os.environ["CI_CD_BRANCH_NAME"]
    schema_name = f"smoke_test_{randint(100000,999999)}"
    monkeypatch.setenv("SCHEMA_NAME", schema_name)

    print("*** create repos folder")
    api_out = run(  # noqa: S603, S607
        ["databricks", "workspace", "mkdirs", f"/Repos/{schema_name}"], capture_output=True
    )
    if api_out.returncode != 0:
        print(api_out.stdout)
        raise Exception("Failed to create a new repo directory")

    print("*** bootstrap unifai")
    result1 = runner.invoke(
        __main__.main,
        ["--profile", "test-run", "bootstrap", github_url, schema_name, "--branch", github_branch],
        env=os.environ,
    )

    if result1.exit_code == 0:
        print("*** deploy unifai sample-app")
        result1 = runner.invoke(
            __main__.main,
            ["--profile", "test-run", "apps", "publish", github_url, "sample-app", "--branch", github_branch],
            env=os.environ,
        )

    if result1.exit_code == 0:
        print("*** run unifai job pull-tables")
        result1 = runner.invoke(
            __main__.main,
            ["--profile", "test-run", "jobs", "run", "sample-app.pull_tables", "--use-shared-cluster"],
            env=os.environ,
        )

    if result1.exit_code == 0:
        print("*** run unifai job n-day-mva")
        result1 = runner.invoke(
            __main__.main,
            ["--profile", "test-run", "jobs", "run", "sample-app.n_day_mva", "n=10", "--use-shared-cluster"],
            env=os.environ,
        )

    if result1.exit_code == 0:
        print("*** remove sample-app")
        result1 = runner.invoke(
            __main__.main,
            ["--profile", "test-run", "apps", "remove", "sample-app"],
            env=os.environ,
            input="y\n",
        )

    print("*** remove unifai core")
    result2 = runner.invoke(
        __main__.main,
        ["--profile", "test-run", "remove", "--delete-data"],
        env=os.environ,
        input="y\n",
    )

    assert result1.exit_code == 0
    assert result2.exit_code == 0
